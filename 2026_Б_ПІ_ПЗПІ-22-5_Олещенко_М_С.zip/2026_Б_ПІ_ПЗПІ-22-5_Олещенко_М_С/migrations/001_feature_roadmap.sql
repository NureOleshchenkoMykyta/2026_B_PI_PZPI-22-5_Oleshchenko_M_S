-- Feature roadmap migration (run manually or via Alembic)
-- Safe to run multiple times with IF NOT EXISTS

ALTER TABLE users ADD COLUMN IF NOT EXISTS music_preferences JSONB DEFAULT '{}'::jsonb;
ALTER TABLE users ADD COLUMN IF NOT EXISTS onboarding_completed BOOLEAN DEFAULT false;
ALTER TABLE users ADD COLUMN IF NOT EXISTS filter_explicit BOOLEAN DEFAULT false;

ALTER TABLE listening_history ADD COLUMN IF NOT EXISTS playback_position DOUBLE PRECISION DEFAULT 0;

CREATE TABLE IF NOT EXISTS playlist_collaborators (
    playlist_id INTEGER NOT NULL REFERENCES playlists(id) ON DELETE CASCADE,
    user_id BIGINT NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
    role VARCHAR(20) DEFAULT 'editor',
    invited_at TIMESTAMPTZ DEFAULT now(),
    PRIMARY KEY (playlist_id, user_id)
);
CREATE INDEX IF NOT EXISTS idx_playlist_collab_user ON playlist_collaborators(user_id);

CREATE TABLE IF NOT EXISTS user_follows (
    follower_id BIGINT NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
    following_id BIGINT NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
    created_at TIMESTAMPTZ DEFAULT now(),
    PRIMARY KEY (follower_id, following_id)
);
CREATE INDEX IF NOT EXISTS idx_user_follows_following ON user_follows(following_id);

CREATE INDEX IF NOT EXISTS idx_listening_user_track ON listening_history(user_id, track_source_id);
