import json
import logging

from aiogram import Bot, F, Router
from aiogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup
from aiogram.utils.keyboard import InlineKeyboardBuilder
from sqlalchemy import func, select

from common.config import settings
from common.database import AsyncSessionLocal
from common.models import Track, UserPlaylist
from common.redis_client import redis_client
from common.texts import get_text

router = Router()
ITEMS_PER_PAGE = 10

BOT_PLAYER_PREFIX = "bot_player:"


async def _get_user_lang(user_id: int) -> str:
    async with AsyncSessionLocal() as session:
        from common.models import User
        user = await session.scalar(select(User).where(User.user_id == user_id))
        if user and user.language:
            lang = user.language
            return "uk" if lang == "ru" else lang
    return "en"


async def _get_player_session(chat_id: int) -> dict:
    raw = await redis_client.redis.get(f"{BOT_PLAYER_PREFIX}{chat_id}")
    if raw:
        return json.loads(raw)
    return {"queue": [], "index": 0, "is_playing": True, "track_source_id": None, "track_id": None}


async def _save_player_session(chat_id: int, session: dict) -> None:
    await redis_client.redis.set(f"{BOT_PLAYER_PREFIX}{chat_id}", json.dumps(session), ex=86400)


async def _get_track_by_source(session_db, source_id: str):
    return await session_db.scalar(select(Track).where(Track.source_id == source_id))

def truncate(text, length=50):
    if not text:
        return ""
    return text[: length - 3] + "..." if len(text) > length else text

async def get_search_keyboard(query: str, page: int):
    builder = InlineKeyboardBuilder()
    offset = page * ITEMS_PER_PAGE

    async with AsyncSessionLocal() as session:
        # Шукаємо на 1 більше, щоб знати чи є наступна сторінка
        stmt = (
            select(Track)
            .where((Track.title.ilike(f"%{query}%")) | (Track.artist.ilike(f"%{query}%")))
            .limit(ITEMS_PER_PAGE + 1)
            .offset(offset)
        )
        result = await session.execute(stmt)
        tracks = result.scalars().all()

    # Додаємо кнопки треків (тільки перші 10)
    current_tracks = tracks[:ITEMS_PER_PAGE]
    for track in current_tracks:
        label = f"{track.artist} - {track.title}"
        builder.row(InlineKeyboardButton(text=f"🔍 {truncate(label)}", callback_data=f"play_track:{track.track_id}"))

    # Навігація по сторінках
    show_footer = len(current_tracks) > 0 or page > 0
    
    if show_footer:
        nav_buttons = []
        safe_query = query[:20]

        # Кнопка "Назад" тільки якщо не 0 сторінка
        if page > 0:
            nav_buttons.append(InlineKeyboardButton(text="⬅️", callback_data=f"search_page:{page-1}:{safe_query}"))
        
        nav_buttons.append(InlineKeyboardButton(text=f"📄 {page + 1}", callback_data="ignore"))

        # Кнопка "Вперед" тільки якщо треків більше ніж ліміт
        if len(tracks) > ITEMS_PER_PAGE:
            nav_buttons.append(InlineKeyboardButton(text="➡️", callback_data=f"search_page:{page+1}:{safe_query}"))
        
        builder.row(*nav_buttons)

    # Кнопка пошуку в інтернеті ЗАВЖДИ внизу
    safe_query_search = query[:20]
    builder.row(InlineKeyboardButton(text="🌍 Знайти в інтернеті (YouTube)", callback_data=f"force_search:{safe_query_search}"))

    return builder.as_markup()



@router.callback_query(F.data == "ignore")
async def ignore_callback(c: CallbackQuery):
    """Просто прибирає годинничок завантаження при натисканні на номер сторінки"""
    await c.answer()


# Текстовий пошук обробляється в bot/main.py (handle_text); дублікат тут давав би друге повідомлення.

@router.callback_query(F.data.startswith("search_page:"))
async def pagination_handler(c: CallbackQuery):
    """Гортання сторінок без відправки нового повідомлення."""
    parts = c.data.split(":")
    page = int(parts[1])
    query = parts[2]

    kb = await get_search_keyboard(query, page)
    if kb:
        await c.message.edit_reply_markup(reply_markup=kb)
    await c.answer()

@router.callback_query(F.data.startswith("play_track:"))
async def play_track_handler(c: CallbackQuery, bot: Bot):
    
    """Відправляє трек при натисканні на кнопку."""
    track_id = int(c.data.split(":")[1])
    
    async with AsyncSessionLocal() as session:
        track = await session.get(Track, track_id)
    keyboard = get_player_keyboard("uk", track.source_id, False, True)

    caption = f"🎶 **{track.artist}**\n💿 *{track.title}*\n\n👉 {settings.BOT_LINK}"
    
    await bot.send_audio(
        chat_id=c.message.chat.id,
        audio=track.telegram_file_id,
        caption=caption,
        reply_markup=keyboard,
        parse_mode="Markdown"
    )
    await c.answer()
    
def get_player_keyboard(lang: str, track_source_id: str, is_liked: bool, is_playing: bool = True):
    """
    Основна клавіатура плеєра.
    Використовує track_source_id (YouTube ID) для колбеків.
    """
    # Рядок 1: Навігація
    play_pause_icon = get_text(lang, 'btn_pause') if is_playing else get_text(lang, 'btn_play')
    play_callback = "pl_pause" if is_playing else "pl_resume"
    
    row1 = [
        InlineKeyboardButton(text=get_text(lang, 'btn_prev'), callback_data="pl_prev"),
        InlineKeyboardButton(text=play_pause_icon, callback_data=play_callback),
        InlineKeyboardButton(text=get_text(lang, 'btn_next'), callback_data="pl_next")
    ]

    # Рядок 2: Дії (Лайк використовує source_id)
    like_icon = get_text(lang, 'btn_like') if is_liked else get_text(lang, 'btn_dislike')
    like_cb = f"pl_rem:{track_source_id}" if is_liked else f"pl_add:{track_source_id}"

    row2 = [
        InlineKeyboardButton(text=like_icon, callback_data=like_cb),
        InlineKeyboardButton(text=get_text(lang, 'btn_loop'), callback_data="pl_loop"),
        InlineKeyboardButton(text=get_text(lang, 'btn_shuffle'), callback_data="pl_shuffle")
    ]

    # Рядок 3: Меню черги
    row3 = [
        InlineKeyboardButton(text=get_text(lang, 'btn_queue'), callback_data="pl_show_queue")
    ]
    
    return InlineKeyboardMarkup(inline_keyboard=[row1, row2, row3])


async def get_track_kb(track_id_int: int, user_id: int, lang: str):
    """
    Генерує клавіатуру для повідомлення з треком (наприклад, після скачування).
    Містить кнопку 'Додати в плейліст' / 'Лайк'.
    """
    async with AsyncSessionLocal() as session:
        # 1. Знаходимо трек, щоб отримати source_id (рядок)
        track = await session.scalar(select(Track).where(Track.track_id == track_id_int))
        
        if not track:
            # Фолбек, якщо трек не знайдено (рідкісний кейс)
            return InlineKeyboardMarkup(inline_keyboard=[])

        source_id = track.source_id

        # 2. Перевіряємо, чи є він у лайках (по source_id)
        playlist_entry = await session.scalar(
            select(UserPlaylist).where(
                UserPlaylist.user_id == user_id, 
                UserPlaylist.track_id == source_id
            )
        )
        is_liked = playlist_entry is not None

    # 3. Формуємо кнопку
    icon = get_text(lang, 'btn_like') if is_liked else get_text(lang, 'btn_add')
    callback = f"pl_rem:{source_id}" if is_liked else f"pl_add:{source_id}"

    return InlineKeyboardMarkup(inline_keyboard=[[
        InlineKeyboardButton(text=icon, callback_data=callback)
    ]])


def get_queue_keyboard(lang: str):
    """Клавіатура для режиму перегляду списку."""
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=get_text(lang, 'btn_back'), callback_data="pl_back_to_player")]
    ])


async def send_player_ui(bot: Bot, chat_id: int, lang: str):
    """
    Відправляє або оновлює плеєр. 
    """
    async with AsyncSessionLocal() as session:
        # 1. Беремо випадковий трек для демо (пізніше замінити на чергу)
        track = await session.scalar(select(Track).order_by(func.random()).limit(1))
        
        if not track:
            return await bot.send_message(chat_id, get_text(lang, 'player_empty'))

        # 2. Перевіряємо лайк (використовуючи source_id)
        user_id = chat_id 
        is_liked = False
        playlist_entry = await session.scalar(
            select(UserPlaylist).where(
                UserPlaylist.user_id == user_id, 
                UserPlaylist.track_id == track.source_id
            )
        )
        if playlist_entry:
            is_liked = True

    # 3. Формуємо текст і клавіатуру
    duration_str = f"{track.duration // 60}:{track.duration % 60:02d}" if track.duration else "--:--"
    caption = get_text(lang, 'player_caption', 
                       artist=track.artist or "Unknown Artist", 
                       title=track.title or "Unknown Track", 
                       duration=duration_str)

    pl_session = {
        "queue": [{"id": track.source_id, "source_id": track.source_id, "title": track.title, "artist": track.artist}],
        "index": 0,
        "is_playing": True,
        "track_source_id": track.source_id,
        "track_id": track.track_id,
    }
    await _save_player_session(chat_id, pl_session)

    # Використовуємо source_id для кнопок
    keyboard = get_player_keyboard(lang, track.source_id, is_liked, is_playing=True)

    # 4. Відправка
    try:
        msg = await bot.send_audio(
            chat_id=chat_id,
            audio=track.telegram_file_id,
            caption=caption,
            reply_markup=keyboard,
            parse_mode="Markdown"
        )
        return msg
    except Exception as e:
        logging.error(f"UI Error: {e}")
        return await bot.send_message(chat_id, f"❌ Error loading track: {track.title}")


@router.callback_query(F.data == "pl_show_queue")
async def show_queue_handler(c: CallbackQuery):
    lang = await _get_user_lang(c.from_user.id)
    pl_session = await _get_player_session(c.message.chat.id)
    queue = pl_session.get("queue") or []

    queue_text = get_text(lang, 'queue_header')
    if queue and pl_session.get("index", 0) < len(queue):
        cur = queue[pl_session["index"]]
        queue_text += get_text(lang, 'queue_current', title=f"{cur.get('artist', '?')} - {cur.get('title', '?')}")
    else:
        queue_text += get_text(lang, 'queue_current', title="—")

    for i, t in enumerate(queue[:10], 1):
        queue_text += get_text(lang, 'queue_item', i=i, title=f"{t.get('artist', '?')} - {t.get('title', '?')}")

    try:
        await c.message.edit_caption(
            caption=queue_text,
            reply_markup=get_queue_keyboard(lang),
            parse_mode="Markdown"
        )
    except Exception:
        await c.answer("Error showing queue")

@router.callback_query(F.data == "pl_back_to_player")
async def back_to_player_handler(c: CallbackQuery):
    lang = await _get_user_lang(c.from_user.id)
    pl_session = await _get_player_session(c.message.chat.id)
    source_id = pl_session.get("track_source_id") or "0"
    is_playing = pl_session.get("is_playing", True)

    async with AsyncSessionLocal() as session:
        track = await _get_track_by_source(session, source_id) if source_id != "0" else None

    if track:
        duration_str = f"{track.duration // 60}:{track.duration % 60:02d}" if track.duration else "--:--"
        caption = get_text(lang, 'player_caption', artist=track.artist or "?", title=track.title or "?", duration=duration_str)
    else:
        caption = "🎶 **Player**\n💿 *No track*"

    await c.message.edit_caption(
        caption=caption,
        reply_markup=get_player_keyboard(lang, source_id, False, is_playing=is_playing),
        parse_mode="Markdown"
    )
    await c.answer()

@router.callback_query(F.data.in_({"pl_pause", "pl_resume"}))
async def play_pause_handler(c: CallbackQuery):
    lang = await _get_user_lang(c.from_user.id)
    pl_session = await _get_player_session(c.message.chat.id)
    is_playing = c.data == "pl_resume"
    pl_session["is_playing"] = is_playing
    await _save_player_session(c.message.chat.id, pl_session)

    source_id = pl_session.get("track_source_id") or "0"
    new_kb = get_player_keyboard(lang, source_id, False, is_playing=is_playing)
    await c.message.edit_reply_markup(reply_markup=new_kb)
    status = "▶️ Resumed" if is_playing else "⏸ Paused"
    await c.answer(status)

@router.callback_query(F.data.in_({"pl_prev", "pl_next", "pl_shuffle", "pl_loop"}))
async def navigation_handler(c: CallbackQuery):
    lang = await _get_user_lang(c.from_user.id)
    action = c.data.split('_')[1]
    pl_session = await _get_player_session(c.message.chat.id)
    queue = pl_session.get("queue") or []
    idx = pl_session.get("index", 0)

    if action in ("prev", "next") and queue:
        if action == "next":
            idx = (idx + 1) % len(queue)
        else:
            idx = (idx - 1) % len(queue)
        pl_session["index"] = idx
        item = queue[idx]
        pl_session["track_source_id"] = item.get("source_id") or item.get("id")
        await _save_player_session(c.message.chat.id, pl_session)
        await c.answer(f"Track {idx + 1}/{len(queue)}")
    else:
        await c.answer(f"Action: {action}")

@router.callback_query(F.data.startswith("web_page:"))
async def web_search_pagination(c: CallbackQuery):
    """
    Обробляє гортання результатів інтернет-пошуку.
    Бере дані з Redis, які туди поклав Worker.
    """
    page = int(c.data.split(":")[1])
    chat_id = c.message.chat.id
    ITEMS_PER_PAGE = 10
    
    # Дістаємо кешовані результати
    redis_key = f"web_search:{chat_id}"
    cached_data = await redis_client.redis.get(redis_key)
    
    if not cached_data:
        return await c.answer("⚠️ Результати застаріли. Зробіть новий пошук.", show_alert=True)
    
    results = json.loads(cached_data)
    
    # Вираховуємо зріз
    start = page * ITEMS_PER_PAGE
    end = start + ITEMS_PER_PAGE
    current_items = results[start:end]
    
    if not current_items:
        return await c.answer("Більше нічого немає.")

    # Будуємо клавіатуру
    builder = InlineKeyboardBuilder()
    for item in current_items:
        icon = "⚡" if item.get('cached') else "🎵"
        label = item['title']
        if len(label) > 50:
            label = label[:47] + "..."
        
        builder.row(InlineKeyboardButton(text=f"{icon} {label}", callback_data=f"dl_id:{item['id']}"))
        builder.row(InlineKeyboardButton(
            text=f"🎵 {label}", 
            callback_data=f"dl_id:{item['id']}" # Це викличе стандартне завантаження
        ))

    # Навігація
    nav_buttons = []
    if page > 0:
        nav_buttons.append(InlineKeyboardButton(text="⬅️ Назад", callback_data=f"web_page:{page-1}"))
    
    nav_buttons.append(InlineKeyboardButton(text=f"📄 {page + 1}", callback_data="ignore"))

    if end < len(results):
        nav_buttons.append(InlineKeyboardButton(text="Вперед ➡️", callback_data=f"web_page:{page+1}"))

    builder.row(*nav_buttons)

    try:
        await c.message.edit_reply_markup(reply_markup=builder.as_markup())
    except Exception:
        await c.answer()