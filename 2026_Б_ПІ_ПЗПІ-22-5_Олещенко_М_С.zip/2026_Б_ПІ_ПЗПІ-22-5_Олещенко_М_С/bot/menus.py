"""Меню та inline-клавіатури без Bot/Dispatcher — імпорт без Telegram-сесії."""

from __future__ import annotations

from typing import Optional

from aiogram.types import (
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    KeyboardButton,
    ReplyKeyboardMarkup,
    WebAppInfo,
)

from common.config import settings
from common.texts import get_text


def _telegram_webapp_url() -> Optional[str]:
    u = (getattr(settings, "TELEGRAM_WEBAPP_URL", "") or "").strip().rstrip("/")
    return u or None


def get_light_menu(lang: str) -> ReplyKeyboardMarkup:
    """Light-меню (постійні кнопки під чатом)."""
    menu = [
        [KeyboardButton(text=get_text(lang, "menu_playlist")), KeyboardButton(text=get_text(lang, "menu_random"))],
        [KeyboardButton(text=get_text(lang, "menu_settings"))],
    ]
    web_url = _telegram_webapp_url()
    if web_url:
        menu.append(
            [KeyboardButton(text=get_text(lang, "menu_webapp"), web_app=WebAppInfo(url=web_url))]
        )
    return ReplyKeyboardMarkup(keyboard=menu, resize_keyboard=True, is_persistent=True)


def get_interface_menu(lang: str) -> ReplyKeyboardMarkup:
    """ReplyKeyboard для режиму interface (те ж меню, що light, включно з Mini App)."""
    return get_light_menu(lang)


def get_main_menu(lang: str) -> ReplyKeyboardMarkup:
    """Заглушка: зараз еквівалентна light-меню."""
    return get_light_menu(lang)


def get_player_keyboard(track_id: int, _user_id: int, lang: str, is_liked: bool) -> InlineKeyboardMarkup:
    """Inline-клавіатура плеєра (варіант з numeric track_id у колбеках)."""
    controls = [
        InlineKeyboardButton(text=get_text(lang, "btn_prev"), callback_data="pl_prev:"),
        InlineKeyboardButton(text=get_text(lang, "btn_play"), callback_data="pl_play:"),
        InlineKeyboardButton(text=get_text(lang, "btn_next"), callback_data="pl_next:"),
    ]
    like_btn_text = get_text(lang, "btn_remove") if is_liked else get_text(lang, "btn_add")
    like_btn_data = f"pl_rem:{track_id}" if is_liked else f"pl_add:{track_id}"
    actions = [
        InlineKeyboardButton(text=like_btn_text, callback_data=like_btn_data),
        InlineKeyboardButton(text=get_text(lang, "btn_search_inline"), callback_data="open_search"),
    ]
    return InlineKeyboardMarkup(inline_keyboard=[controls, actions])
