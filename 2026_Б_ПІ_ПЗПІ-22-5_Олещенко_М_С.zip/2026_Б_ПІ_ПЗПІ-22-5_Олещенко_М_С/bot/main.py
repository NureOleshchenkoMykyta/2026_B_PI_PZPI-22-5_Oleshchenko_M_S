import asyncio
import logging
import os
import yt_dlp
from common.analytics import analytics
from common.texts import get_text
from aiogram import Bot, Dispatcher, F, types
from aiogram.types import Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton, ReplyKeyboardMarkup, KeyboardButton
from aiogram.filters import CommandStart, Command
from shazamio import Shazam
from sqlalchemy import select, or_, func, update, delete, and_
from aiogram.client.session.aiohttp import AiohttpSession
from aiogram.client.telegram import TelegramAPIServer
import json

from aiogram.types import URLInputFile
from common.config import settings
from common.database import AsyncSessionLocal
from common.models import User, Track, UserPlaylist, PlaylistQueue 
from common.redis_client import redis_client
from common.schemas import DownloadTask

# from bot.player_interface import get_interface_menu, send_interface_player, router as player_router, get_user_lang,send_player_ui

from bot.menus import get_interface_menu, get_light_menu, get_main_menu
from bot.player_interface import router as player_router, send_player_ui

logging.basicConfig(level=logging.INFO)

session = None
if settings.TELEGRAM_API_SERVER_URL:
    session = AiohttpSession(
        api=TelegramAPIServer.from_base(settings.TELEGRAM_API_SERVER_URL)
    )

bot = Bot(token=settings.BOT_TOKEN.get_secret_value(), session=session)
dp = Dispatcher()
dp.include_router(player_router)
shazam = Shazam()

async def get_user_lang(user_id: int) -> str:
    """Отримує мову користувача з бази даних."""
    async with AsyncSessionLocal() as session:
        lang = await session.scalar(select(User.language).where(User.user_id == user_id))
    code = lang or "en"
    return "uk" if code == "ru" else code

async def get_user_silent_mode(user_id: int) -> bool:
    """Перевіряє, чи увімкнено тихий режим у користувача."""
    async with AsyncSessionLocal() as session:
        result = await session.execute(select(User).where(User.user_id == user_id))

        
        user = result.scalar_one_or_none()
        if user:
            # Повертаємо True, якщо silent_mode увімкнено
            # (Використовуємо getattr про всяк випадок, якщо колонка ще не створена)
            return getattr(user, 'silent_mode', False)
    return False

async def get_user_mode_and_menu(user_id: int):
    """Повертає поточний режим та відповідне меню."""
    async with AsyncSessionLocal() as session:
        user = await session.scalar(select(User).where(User.user_id == user_id))
    
    if not user:
        return 'light', get_light_menu('en'), 'en'

    lang_raw = user.language or "en"
    lang = "uk" if lang_raw == "ru" else lang_raw
    mode = user.mode if user.mode else 'light' 

    if mode == 'interface':
        return mode, get_interface_menu(lang), lang 
    else:
        return 'light', get_light_menu(lang), lang

async def show_main_menu(message: Message, lang: str):
    """Показує меню згідно з поточним режимом користувача."""
    mode, menu, _ = await get_user_mode_and_menu(message.from_user.id)
    msg = await message.answer(get_text(lang, 'welcome'), reply_markup=menu)
    await refresh_interface(message.chat.id, msg.message_id)

async def show_mode_menu(message: Message):
    """Показує меню вибору режиму (Inline)."""
    lang = await get_user_lang(message.from_user.id)
    await smart_clean_chat(message.chat.id, message.message_id)
    
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=get_text(lang, 'mode_light'), callback_data="set_mode:light")],
        [InlineKeyboardButton(text=get_text(lang, 'mode_interface'), callback_data="set_mode:interface")]
    ])
    msg = await message.answer(get_text(lang, 'menu_mode_select'), reply_markup=kb, parse_mode="Markdown")
    await refresh_interface(message.chat.id, msg.message_id)

async def smart_clean_chat(chat_id: int, current_msg_id: int):
    """Видаляє старі повідомлення (історію) у фоні."""
    # Видаляємо 5 попередніх повідомлень
    for i in range(10, 100): 
        # create_task запускає це паралельно, не блокуючи бота
        asyncio.create_task(safe_delete(chat_id, current_msg_id - i))

async def safe_delete(chat_id: int, message_id: int):
    try: await bot.delete_message(chat_id, message_id)
    except: pass 

async def refresh_interface(chat_id: int, message_id: int):
    await smart_clean_chat(chat_id, message_id)

async def check_access(message: Message) -> bool:
    user_id = message.from_user.id
    if user_id == bot.id: return True
    
    async with AsyncSessionLocal() as session:
        user = await session.scalar(select(User).where(User.user_id == user_id))
        
        # 1. Якщо користувача немає - реєструємо з language=None
        if not user: 
            session.add(User(user_id=user_id, username=message.from_user.username, language=None, mode='light'))
            await session.commit()
            return True # Пропускаємо до /start

        # 2. Якщо мова не обрана (None)
        if user.language is None:
            if message.text == '/start': return True
            await show_lang_menu(message)
            return False

        # 3. Перевірка доступу (код)
        # if not user.is_approved:
        #     if message.text and message.text.startswith('/code'): return True
            
        #     await smart_clean_chat(message.chat.id, message.message_id)
        #     msg = await message.answer(get_text(user.language, 'enter_code'), parse_mode="Markdown")
        #     await refresh_interface(message.chat.id, msg.message_id)
        #     return False
        
        # 4. Перевірка режиму
        if user.mode is None:
            await show_mode_menu(message)
            return False
            
    return True
dp.message.filter(check_access)

@dp.message(CommandStart())
async def start(m: Message):
    async with AsyncSessionLocal() as session:
        user = await session.scalar(select(User).where(User.user_id == m.from_user.id))
    
    await smart_clean_chat(m.chat.id, m.message_id)
    
    if user.language is None:
        await show_lang_menu(m)
        return

    if user.is_approved:
        if user.mode is None: # Тільки якщо режим не був встановлений
            await show_mode_menu(m)
        else:
            await show_main_menu(m, user.language)
    else:
        # Доступу немає -> Просимо код
        msg = await m.answer(get_text(user.language, 'enter_code'), reply_markup=None, parse_mode="Markdown")
        await refresh_interface(m.chat.id, msg.message_id)

async def start(m: Message):
    # Цей хендлер спрацює тільки якщо check_access повернув True
    # або якщо ми пропустили його для вибору мови
    
    # Перевіримо мову ще раз
    lang = await get_user_lang(m.from_user.id)
    
    # Якщо мова досі не вибрана (наприклад, auto-reg без вибору) - показуємо вибір
    # (Але за логікою check_access, якщо language=None, ми вже мали показати меню. 
    #  Тут ми показуємо меню, якщо це перший старт)
    async with AsyncSessionLocal() as session:
        user = await session.scalar(select(User).where(User.user_id == m.from_user.id))
        if not user.language:
             await show_lang_menu(m)
             return

    await smart_clean_chat(m.chat.id, m.message_id)
    msg = await m.answer(get_text(lang, 'welcome'), reply_markup=get_main_menu(lang))
    await refresh_interface(m.chat.id, msg.message_id)

async def show_lang_menu(message: Message):
    await smart_clean_chat(message.chat.id, message.message_id)
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="🇺🇦 Українська", callback_data="lang:uk"),
            InlineKeyboardButton(text="🇺🇸 English", callback_data="lang:en"),
        ],
        [InlineKeyboardButton(text="🇩🇪 Deutsch", callback_data="lang:de")],
    ])
    msg = await message.answer("🌍 Choose Language:", reply_markup=kb)
    await refresh_interface(message.chat.id, msg.message_id)

@dp.callback_query(F.data.startswith('lang:'))
async def set_language(callback: CallbackQuery):
    raw = callback.data.split(':')[1]
    if raw == "ru":
        raw = "uk"
    if raw not in ("uk", "en", "de"):
        await callback.answer("Unknown language", show_alert=True)
        return
    lang = raw
    async with AsyncSessionLocal() as session:
        await session.execute(update(User).where(User.user_id == callback.from_user.id).values(language=lang))
        user = await session.scalar(select(User).where(User.user_id == callback.from_user.id))
        await session.commit()
    
    # Видаляємо меню вибору
    await callback.message.delete()
    
    # 1. Повідомлення про встановлену мову
    await callback.message.answer(get_text(lang, 'lang_set'))
    
    # 2. Далі логіка входу
    if user.is_approved:
        msg = await callback.message.answer(get_text(lang, 'welcome'), reply_markup=get_main_menu(lang))
    else:
        msg = await callback.message.answer(get_text(lang, 'enter_code'), parse_mode="Markdown")
    
    await refresh_interface(callback.message.chat.id, msg.message_id)

@dp.message(Command("code"))
async def cmd_code(message: Message):
    await smart_clean_chat(message.chat.id, message.message_id)
    parts = message.text.split()
    lang = await get_user_lang(message.from_user.id)
    
    if len(parts) < 2 or parts[1].strip() != settings.ACCESS_CODE:
        msg = await message.answer("❌")
        await asyncio.sleep(2); await msg.delete()
        return

    async with AsyncSessionLocal() as session:
        await session.execute(update(User).where(User.user_id == message.from_user.id).values(is_approved=True))
        await session.commit()
    
    msg = await message.answer(get_text(lang, 'access_granted'), parse_mode="Markdown", reply_markup=get_main_menu(lang))
    await refresh_interface(message.chat.id, msg.message_id)

@dp.message(F.text.regexp(r'^(https?://)?(www\.|music\.)?(youtube\.com|youtu\.be)/.+$'))
async def admin_add_playlist(message: Message):
    # Admin-only handler
    if not await is_user_admin(message.from_user.id):
        # Якщо не адмін - просто ігноруємо (щоб працював звичайний пошук) або робимо return
        return

    url = message.text.strip()
    status_msg = await message.reply("🕵️‍♂️ **Адмін-запит:** Аналізую посилання...", parse_mode="Markdown")

    try:
        # 2. Отримуємо інфо про плейлист (швидко, без скачування)
        loop = asyncio.get_event_loop()
        with yt_dlp.YoutubeDL({'quiet': True, 'extract_flat': True}) as ydl:
            info = await loop.run_in_executor(None, lambda: ydl.extract_info(url, download=False))

        if not info:
            await status_msg.edit_text("❌ Не вдалося прочитати посилання.")
            return

        # 3. Перевіряємо, чи це список
        is_playlist = info.get('_type') == 'playlist' or 'entries' in info
        title = info.get('title', 'Unknown Playlist')
        count = len(info.get('entries', []))

        if not is_playlist:
            await status_msg.edit_text(f"⚠️ Це **одиночне відео** ({title}), а не альбом.\nВоно буде завантажене як звичайний пошук.")
            # Можна викликати логіку скачування тут, або просто зупинитися
            return

        # 4. Зберігаємо в БД
        async with AsyncSessionLocal() as session:
            # Перевірка дублікатів
            exists = await session.scalar(select(PlaylistQueue).where(PlaylistQueue.url == url))
            if exists:
                status = "✅ Скачано" if exists.is_downloaded else "⏳ В черзі"
                await status_msg.edit_text(f"ℹ️ Цей альбом вже є в базі:\n**{exists.title}**\nСтатус: {status}", parse_mode="Markdown")
                return

            # Додавання
            new_pl = PlaylistQueue(
                url=url,
                title=title,
                is_downloaded=False 
            )
            session.add(new_pl)
            await session.commit()

        await status_msg.edit_text(
            f"✅ **Альбом додано в чергу!**\n"
            f"📂 `{title}`\n"
            f"🔢 Треків: {count}\n"
            f"🚀 Traffic Manager скоро почне роботу.",
            parse_mode="Markdown"
        )

    except Exception as e:
        logging.error(f"Playlist Add Error: {e}")
        await status_msg.edit_text(f"❌ Помилка: {str(e)[:100]}")


@dp.message(F.text)
async def handle_text(message: Message):
    uid = message.from_user.id
    try:
        mode, _, lang = await get_user_mode_and_menu(uid)
    except:
        lang = 'en'

    text = message.text

    # 1. Перевірка меню
    if text == get_text(lang, 'menu_playlist'): await send_playlist(message, 0); return
    elif text == get_text(lang, 'menu_settings'): await show_settings(message); return
    elif text == get_text(lang, 'menu_random'): await send_random(message); return
    
    # 2. Логування
    await smart_clean_chat(message.chat.id, message.message_id)
    await analytics.log_search(message.from_user.id, text)
    
    safe_text = text.replace('_', '\\_').replace('*', '\\*').replace('`', '\\`')

    # 3. Завжди реальний пошук на YouTube через воркер (search_tracks).
    # Локальний ILIKE по БД давав випадкові збіги за підрядком і блокував автопошук.
    status_msg = await message.answer(
        get_text(lang, "searching", query=safe_text),
        parse_mode="Markdown",
    )
    task = DownloadTask(
        chat_id=message.chat.id,
        user_id=message.from_user.id,
        query=text.strip(),
        message_id=0,
        status_message_id=status_msg.message_id,
    )
    await redis_client.push_task(task)
    await refresh_interface(message.chat.id, status_msg.message_id)

async def get_track_kb(track_id: int, user_id: int, lang: str):
    from common.models import UserPlaylist
    async with AsyncSessionLocal() as session:
        exists = await session.scalar(select(UserPlaylist).where(and_(UserPlaylist.user_id==user_id, UserPlaylist.track_id==str(track_id))))
    
    btn_text = get_text(lang, 'btn_remove') if exists else get_text(lang, 'btn_add')
    callback_data = f"pl_rem:{track_id}" if exists else f"pl_add:{track_id}"
    return types.InlineKeyboardMarkup(inline_keyboard=[[types.InlineKeyboardButton(text=btn_text, callback_data=callback_data)]])

@dp.callback_query(F.data.startswith('dl_id:'))
async def dl_btn(callback: CallbackQuery):
    lang = await get_user_lang(callback.from_user.id)
    yt_id = callback.data.split(':')[1]
    
    # Перевірка кешу за YouTube ID
    async with AsyncSessionLocal() as session:
        t = await session.scalar(select(Track).where(Track.source_id == yt_id))
    
    if t:
        kb = await get_track_kb(t.track_id, callback.from_user.id, lang)
        try:
            await callback.message.delete() # Видаляємо меню
            msg = await bot.send_audio(callback.message.chat.id, t.telegram_file_id, caption=get_text(lang, 'cached'), reply_markup=kb,disable_notification=is_silent)
            await refresh_interface(callback.message.chat.id, msg.message_id)
            await analytics.log_download(callback.from_user.id, t.track_id, True, 'btn_cache')
            return
        except: pass

    # Search menu is text; prefer edit_text over edit_caption
    try:
        await callback.message.edit_text(get_text(lang, 'downloading'), reply_markup=None)
    except Exception:
        # Якщо раптом це було медіа (малоймовірно), пробуємо edit_caption
        try: await callback.message.edit_caption(caption=get_text(lang, 'downloading'), reply_markup=None)
        except: pass

    task = DownloadTask(
        chat_id=callback.message.chat.id, 
        user_id=callback.from_user.id, 
        query=callback.data, 
        message_id=0, 
        status_message_id=callback.message.message_id
    )
    await redis_client.push_task(task)

@dp.callback_query(F.data.startswith('pl_add:'))
async def add_pl(c: CallbackQuery):
    try:
        tid = int(c.data.split(':')[1])
        uid = c.from_user.id
        lang = await get_user_lang(uid)

        async with AsyncSessionLocal() as session:
            exists = await session.scalar(select(UserPlaylist).where(and_(UserPlaylist.user_id==uid, UserPlaylist.track_id==str(tid))))
            if not exists:
                session.add(UserPlaylist(user_id=uid, track_id=str(tid)))
                await session.commit()
        
        await c.message.edit_reply_markup(reply_markup=await get_track_kb(tid, uid, lang))
        await c.answer(get_text(lang, 'added'))
    except Exception as e:
        logging.error(f"Add Playlist Error: {e}")

@dp.callback_query(F.data.startswith('pl_rem:'))
async def rem_pl(c: CallbackQuery):
    try:
        tid = int(c.data.split(':')[1])
        uid = c.from_user.id
        lang = await get_user_lang(uid)
        
        async with AsyncSessionLocal() as session:
            await session.execute(delete(UserPlaylist).where(and_(UserPlaylist.user_id==uid, UserPlaylist.track_id==str(tid))))
            await session.commit()
            
        await c.message.edit_reply_markup(reply_markup=await get_track_kb(tid, uid, lang))
        await c.answer(get_text(lang, 'removed'))
    except Exception as e:
        logging.error(f"Remove Playlist Error: {e}")

async def send_playlist(message: Message, offset: int, is_new=True):
    uid = message.chat.id
    lang = await get_user_lang(uid)
    if is_new: await smart_clean_chat(uid, message.message_id)
    
    async with AsyncSessionLocal() as session:
        user = await session.scalar(select(User).where(User.user_id == uid))
        batch = user.batch_size or 3
        total = await session.scalar(select(func.count(UserPlaylist.track_id)).where(UserPlaylist.user_id == uid))
        
        if total == 0:
            msg = await message.answer(get_text(lang, 'playlist_empty'))
            if is_new: await refresh_interface(uid, msg.message_id)
            return

        tracks = await session.scalars(
            select(Track).join(UserPlaylist, Track.track_id == UserPlaylist.track_id)
            .where(UserPlaylist.user_id == uid)
            .order_by(UserPlaylist.added_at.desc()).limit(batch).offset(offset)
        )
        tracks = tracks.all()

    if not tracks: return
    
    if is_new:
        header = await message.answer(get_text(lang, 'playlist_header', total=total))
        await refresh_interface(uid, header.message_id)

    for t in tracks:
        kb = await get_track_kb(t.track_id, uid, lang)
        try: await message.answer_audio(t.telegram_file_id, caption=f"🎧 {t.artist} - {t.title}", reply_markup=kb,disable_notification=is_silent); await asyncio.sleep(0.2)
        except: pass
    
    if offset + batch < total:
        kb = InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text=get_text(lang, 'btn_load_more', count=batch), callback_data=f"pl_next:{offset + batch}")]])
        await message.answer("👇", reply_markup=kb)

@dp.callback_query(F.data.startswith('pl_next:'))
async def pl_next(c: CallbackQuery):
    await c.message.delete()
    await send_playlist(c.message, int(c.data.split(':')[1]), is_new=False)

async def show_settings(m: Message):
    await smart_clean_chat(m.chat.id, m.message_id)
    lang = await get_user_lang(m.from_user.id)
    
    kb = InlineKeyboardMarkup(inline_keyboard=[
        # Кнопки кількості треків
        [InlineKeyboardButton(text="3", callback_data="set_batch:3"), 
         InlineKeyboardButton(text="5", callback_data="set_batch:5"), 
         InlineKeyboardButton(text="10", callback_data="set_batch:10")],
        # Зміна мови
        [InlineKeyboardButton(text="🌍 Language", callback_data="open_lang_menu")],
        # Mode switch
        [InlineKeyboardButton(text=get_text(lang, 'menu_mode_change'), callback_data="open_mode_menu")] 
    ])
    
    msg = await m.answer(get_text(lang, 'settings_title'), reply_markup=kb)
    await refresh_interface(m.chat.id, msg.message_id)
@dp.callback_query(F.data == "open_mode_menu")
async def open_mode_menu_handler(callback: CallbackQuery):
    await callback.message.delete()
    await show_mode_menu(callback.message)
    await callback.answer()

# Обробник для вибору режиму
@dp.callback_query(F.data.startswith('set_mode:'))
async def set_mode(callback: CallbackQuery):
    mode = callback.data.split(':')[1]
    uid = callback.from_user.id
    lang = await get_user_lang(uid)
    
    async with AsyncSessionLocal() as session:
        await session.execute(update(User).where(User.user_id == uid).values(mode=mode))
        await session.commit()
    
    mode_text = get_text(lang, 'mode_light') if mode == 'light' else get_text(lang, 'mode_interface')
    
    await callback.message.delete()
    await callback.message.answer(get_text(lang, 'mode_set_to', mode=mode_text), parse_mode="Markdown")
    
    # Показуємо оновлене головне меню
    await show_main_menu(callback.message, lang)
    await callback.answer()

# Обробка натискання на кнопку "Змінити мову"
@dp.callback_query(F.data == "open_lang_menu")
async def open_lang_menu_handler(callback: CallbackQuery):
    await callback.message.delete()
    await show_lang_menu(callback.message)
@dp.callback_query(F.data.startswith('set_batch:'))
async def set_batch(c: CallbackQuery):
    cnt, lang = int(c.data.split(':')[1]), await get_user_lang(c.from_user.id)
    async with AsyncSessionLocal() as session:
        await session.execute(update(User).where(User.user_id == c.from_user.id).values(batch_size=cnt)); await session.commit()
    await c.message.edit_text(get_text(lang, 'settings_saved', count=cnt))

async def send_random(m: Message):
    await smart_clean_chat(m.chat.id, m.message_id)
    lang = await get_user_lang(m.from_user.id)
    async with AsyncSessionLocal() as session:
        track = await session.scalar(select(Track).order_by(func.random()).limit(1))
    if track:
        kb = await get_track_kb(track.track_id, m.from_user.id, lang)
        msg = await m.answer_audio(track.telegram_file_id, caption=get_text(lang, 'random_caption', id=track.track_id), reply_markup=kb)
        await refresh_interface(m.chat.id, msg.message_id)
        await analytics.log_download(m.from_user.id, track.track_id, True, 'random_cmd')
    else: 
        msg = await m.answer(get_text(lang, 'nothing_found'))
        await refresh_interface(m.chat.id, msg.message_id)

# SHAZAM
@dp.message(F.voice | F.audio)
async def handle_audio_recognition(message: Message):
    lang = await get_user_lang(message.from_user.id)
    status = await message.reply("🎤 " + get_text(lang, 'shazam_listening'))
    await smart_clean_chat(message.chat.id, message.message_id)
    
    try:
        # 1. Визначаємо об'єкт файлу (Голосове або Аудіо)
        voice_obj = message.voice or message.audio
        
        # 2. Формуємо шлях для збереження
        # Воно збережеться в папку downloads проекту (/home/hydra_project/downloads)
        if not os.path.exists("downloads"):
            os.makedirs("downloads")
            
        local_filename = f"downloads/{voice_obj.file_id}.ogg"

        await bot.download(voice_obj, destination=local_filename)
        
        logging.info(f"✅ Audio downloaded to: {local_filename}")

        # 4. Відправляємо в Shazam
        logging.info(f"🔍 Analyzing audio...")
        out = await shazam.recognize(local_filename)
        
        # 5. Видаляємо файл після аналізу
        if os.path.exists(local_filename):
            os.remove(local_filename)
            
        # 6. Обробка результату
        track = out.get('track')
        if track:
            # Формат: Виконавець - Назва
            artist = track.get('subtitle', 'Unknown')
            title = track.get('title', 'Unknown')
            q = f"{artist} {title}"
            
            logging.info(f"✅ Shazam found: {q}")
            
            await status.edit_text(get_text(lang, 'shazam_result', title=q), parse_mode="Markdown")
            
            # Ставимо задачу на пошук треку
            task = DownloadTask(
                chat_id=message.chat.id, 
                user_id=message.from_user.id, 
                query=q, 
                message_id=0, 
                status_message_id=status.message_id
            )
            await redis_client.push_task(task)
        else:
            logging.info("❌ Shazam found nothing")
            await status.edit_text(get_text(lang, 'nothing_found'))
            await refresh_interface(message.chat.id, status.message_id)
            
    except Exception as e:
        logging.error(f"❌ Shazam Error: {e}", exc_info=True)
        try: await status.edit_text(f"⚠️ Error: {str(e)[:50]}")
        except: pass


@dp.message(Command("stats"))
async def cmd_stats(message: Message):
    # Перевірка через базу
    if not await is_user_admin(message.from_user.id): 
        return
        
    stats = await analytics.get_stats()
    text = f"📊 Stats:\nUsers: {stats['users']}\nTracks: {stats['tracks']}\nDownloads: {stats['downloads']}"
    await message.reply(text)

@dp.callback_query(F.data.startswith('force_search:'))
async def handle_force_search(callback: CallbackQuery):
    # З кнопки — до 20 символів; для повного запиту вже спрацьовує auto YouTube при порожньому каталозі
    query = callback.data.split(':', 1)[1]
    lang = await get_user_lang(callback.from_user.id)
    chat_id = callback.message.chat.id

    try:
        await callback.message.delete()
    except Exception:
        pass

    safe_q = (
        query.replace("_", "\\_").replace("*", "\\*").replace("`", "\\`")
        if query
        else ""
    )
    status_msg = await bot.send_message(
        chat_id,
        get_text(lang, "searching", query=safe_q or query),
        parse_mode="Markdown",
    )
    
    # Створюємо задачу для Worker-а (шукати в YouTube)
    task = DownloadTask(
        chat_id=callback.message.chat.id, 
        user_id=callback.from_user.id, 
        query=query, 
        message_id=0, 
        status_message_id=status_msg.message_id
    )
    await redis_client.push_task(task)
    await callback.answer()

@dp.message(Command("player"))
async def test_player(message: Message):
    lang = await get_user_lang(message.from_user.id)
    await smart_clean_chat(message.chat.id, message.message_id)
    
    # Викликаємо нашу нову функцію
    await send_player_ui(bot, message.chat.id, lang)

async def sending_worker(bot: Bot):
    """Слухає Redis і миттєво відправляє треки в чат"""
    print("🚀 Sending Worker started")
    
    while True:
        try:
            result = await redis_client.redis.brpop("tg_send_queue", timeout=5)
            
            if result:
                _, data_raw = result
                task = json.loads(data_raw)
                
                user_id = task["user_id"]
                is_silent = await get_user_silent_mode(user_id)
                track_id = task["track_id"]
                file_id = task.get("file_id")
                r2_url = task.get("r2_url")
                
                # Отримуємо налаштування сповіщення (за замовчуванням False - тобто зі звуком)
                disable_notification = task.get("disable_notification", False) 
                
                

                try:
                    # Telegram file_id available
                    caption = f"🎧 {task['artist']} - {task['title']}\n\n👉 {settings.BOT_LINK}"
                
                    if task.get("file_id") and task.get("file_id") != "pending":
                        await bot.send_audio(task["user_id"], task["file_id"], caption=caption)
                    
                    # Fallback: stream from URL
                    elif r2_url:
                        # Повідомлення про завантаження теж можна зробити тихим або прибрати
                        if not is_silent: 
                             await bot.send_message(user_id, "⏳ Завантажую трек в чат...")
                            
                        msg = await bot.send_audio(
                            chat_id=user_id, 
                            audio=URLInputFile(r2_url), 
                            caption=caption,
                            disable_notification=is_silent
                        )
                        
                        if msg.audio:
                            async with AsyncSessionLocal() as db:
                                await db.execute(
                                    update(Track)
                                    .where(Track.source_id == track_id)
                                    .values(telegram_file_id=msg.audio.file_id)
                                )
                                await db.commit()
                    
                    else:
                        if not disable_notification:
                            await bot.send_message(user_id, "⚠️ Файл ще не готовий, спробуйте пізніше.")

                except Exception as e:
                    logging.error(f"Failed to send to {user_id}: {e}")

        except Exception as e:
            logging.error(f"Worker Loop Error: {e}")
            await asyncio.sleep(5)

async def main():
    print("Hydra v13 (Crash Fix) starting...")
    
    asyncio.create_task(sending_worker(bot))
    
    try: 
        await dp.start_polling(bot)
    finally: 
        await redis_client.close()

if __name__ == "__main__":
    asyncio.run(main())

