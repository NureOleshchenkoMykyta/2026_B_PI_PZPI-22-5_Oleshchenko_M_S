from sqlalchemy import select, func, text
from common.database import AsyncSessionLocal
from common.models import SearchHistory, DownloadHistory, User, Track, PlaylistQueue

class AnalyticsService:
    
    async def log_search(self, user_id: int, query: str):
        """Записує пошуковий запит користувача."""
        async with AsyncSessionLocal() as session:
            try:
                # Обрізаємо дуже довгі запити
                clean_query = query.strip()[:200]
                entry = SearchHistory(user_id=user_id, query=clean_query)
                session.add(entry)
                await session.commit()
            except Exception as e:
                print(f"Analytics Error (Search): {e}")

    async def log_download(self, user_id: int, track_id: int, is_cached: bool, source: str):
        """Записує факт отримання треку (скачування або кеш)."""
        async with AsyncSessionLocal() as session:
            try:
                entry = DownloadHistory(
                    user_id=user_id, 
                    track_id=track_id, 
                    is_cached=is_cached, 
                    source_type=source
                )
                session.add(entry)
                await session.commit()
            except Exception as e:
                print(f"Analytics Error (Download): {e}")

    async def get_stats(self):
        """Збирає загальну статистику для адміна."""
        async with AsyncSessionLocal() as session:
            # 1. Загальна кількість користувачів
            total_users = await session.scalar(select(func.count(User.user_id)))
            
            # 2. Загальна кількість треків у базі
            total_tracks = await session.scalar(select(func.count(Track.track_id)))
            
            # 3. Всього скачувань (історія)
            total_downloads = await session.scalar(select(func.count(DownloadHistory.id)))
            
            # 4. Ефективність Кешу (скільки % видали без YouTube)
            cache_hits = await session.scalar(select(func.count(DownloadHistory.id)).where(DownloadHistory.is_cached == True))
            cache_rate = int((cache_hits / total_downloads * 100)) if total_downloads > 0 else 0

            # 5. Черга плейлистів (статус)
            active_playlists = await session.scalar(select(func.count(PlaylistQueue.id)).where(PlaylistQueue.is_downloaded == False))

            return {
                "users": total_users,
                "tracks": total_tracks,
                "downloads": total_downloads,
                "cache_hits": cache_hits,
                "cache_rate": cache_rate,
                "active_playlists": active_playlists
            }

analytics = AnalyticsService()