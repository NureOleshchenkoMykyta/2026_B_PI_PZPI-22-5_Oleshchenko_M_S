from pydantic import BaseModel, HttpUrl
from typing import Optional, List
from datetime import datetime

# --- User Schemas ---
class UserCreate(BaseModel):
    user_id: int
    username: str | None = None
    full_name: str | None = None
    language: str = "en"

# --- Search Schemas ---

class SearchResult(BaseModel):
    id: str
    title: str
    artist: str
    duration: int
    cover: str
    source: str

class TrackSearchResult(BaseModel):
    id: str
    title: str
    artist: str
    duration: int
    cover: str
    source: str

# --- Track Info Schemas ---

class TrackInfo(BaseModel):
    id: str
    title: str
    artist: str
    duration: int
    cover: str
    source: str = "youtube"

class TrackSchema(BaseModel):
    source_id: str
    title: str
    artist: str
    duration: int
    cover: str
    stream_url: str
    status: str

class TrackDetails(BaseModel):
    id: str
    title: str
    artist: str
    r2_url: str
    cover: Optional[str] = None

# --- Playlist Schemas ---

class PlaylistSchema(BaseModel):
    id: int
    title: str
    description: str | None
    cover: str | None
    is_pinned: bool
    track_count: int = 0

class CreatePlaylist(BaseModel):
    title: str
    description: Optional[str] = None

# --- Worker Schemas ---

class DownloadTask(BaseModel):
    chat_id: int
    user_id: int
    query: str
    message_id: Optional[int] = None # Зробили Optional для сумісності
    
    # Поля для роботи нової логіки воркера та API
    is_interface: bool = False 
    retry_count: int = 0
    status_message_id: Optional[int] = None
    pre_downloaded_path: Optional[str] = None

class PlaylistBase(BaseModel):
    title: str
    description: Optional[str] = None
    cover: Optional[str] = None
    is_public: bool = False
    tags: List[str] = []

class PlaylistCreate(PlaylistBase):
    pass

class PlaylistUpdate(BaseModel):
    title: Optional[str] = None
    description: Optional[str] = None
    cover: Optional[str] = None
    is_pinned: Optional[bool] = None
    is_public: Optional[bool] = None
    tags: Optional[List[str]] = None

class PlaylistResponse(PlaylistBase):
    id: int
    user_id: int
    is_pinned: bool
    likes_count: int = 0
    created_at: datetime
    track_count: Optional[int] = 0

    class Config:
        from_attributes = True