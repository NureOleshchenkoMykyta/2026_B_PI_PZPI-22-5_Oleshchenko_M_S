import json
import asyncio
import logging
import os
from ytmusicapi import YTMusic
from common.redis_client import redis_client

logger = logging.getLogger("explore_service")

YT_PARAMS_MAP = {
    # Українська: рідна мова інтерфейсу та локальний контент (тренди України)
    'uk': {'lang': 'uk', 'loc': 'UA'}, 

    # Російська: рідна мова та регіон (якщо потрібен контент з РФ)
    'ru': {'lang': 'ru', 'loc': 'RU'}, 
    
    # Англійська (США)
    'en': {'lang': 'en', 'loc': 'US'},
    
    # Німецька (Німеччина)
    'de': {'lang': 'de', 'loc': 'DE'}
}

OFFICIAL_CATEGORY_MAP = {
    # Moods
    'cat_party': 'Party', 'cat_relax': 'Relax', 'cat_energy': 'Energize',
    'cat_focus': 'Focus', 'cat_sleep': 'Sleep', 'cat_romance': 'Romance',
    'cat_sad': 'Sad', 'cat_workout': 'Workout', 'cat_on_road': 'Commute',
    'cat_good_mood': 'Feel Good',
    
    # Genres
    'cat_rock': 'Rock', 'cat_pop': 'Pop', 'cat_hiphop': 'Hip-Hop',
    'cat_jazz': 'Jazz', 'cat_classic': 'Classical', 'cat_metal': 'Metal',
    'cat_kpop': 'K-Pop', 'cat_latin': 'Latin', 'cat_indie_alt': 'Indie & Alternative',
    'cat_dance_electronic': 'Dance & Electronic', 'cat_rnb_soul': 'R&B',
    'cat_country_americana': 'Country & Americana', 'cat_reggae': 'Reggae & Caribbean',
    'cat_blues': 'Blues', 'cat_folk': 'Folk & Acoustic',
}

# Пошукові запити для тих категорій, яких немає в меню (Fallback)
SEARCH_FALLBACK_MAP = {
    'cat_jap_rap': 'Japanese Rap Hiphop Top',
    'cat_desi_hiphop': 'Desi Hip Hop Hits',
    'cat_cpop': 'Chinese Pop Hits',
    'cat_brazil_hiphop': 'Brazilian Hip Hop',
    'cat_german_hiphop': 'Deutschrap Hits',
    'cat_bollywood': 'Bollywood Hits',
    'cat_soundtracks': 'Best Movie Soundtracks',
    'cat_lofi': 'Lofi Hip Hop Chill',
    'cat_phonk': 'Best Phonk Playlist',
    'cat_techno': 'Techno Bunker',
}


SECTION_TITLES = {
    'new_releases': {'uk': 'Нові релізи', 'en': 'New Releases', 'de': 'Neuerscheinungen', 'ru': 'Новые релизы'},
    'charts': {'uk': 'Чарти', 'en': 'Charts', 'de': 'Charts', 'ru': 'Чарты'},
    'moods': {'uk': 'Настрій та жанри', 'en': 'Moods & Genres', 'de': 'Stimmung & Genre', 'ru': 'Настроение и жанры'}
}
def fetch_smart_genre_tracks_sync(category_key: str):
    """
    Розумна стратегія:
    1. Пробуємо знайти офіційну категорію (Explore Params).
    2. Якщо це ніша - шукаємо найкращий плейлист (Search).
    3. Повертаємо треки з знайденого плейлиста.
    """
    logger.info(f"🧠 Smart Genre Fetch: {category_key}")
    
    # Ініціалізуємо клієнт (англійська, щоб збігалися назви категорій)
    yt = YTMusic(language='en', location='US')
    
    playlist_id = None
    target_title = OFFICIAL_CATEGORY_MAP.get(category_key)

    # Офіційні категорії (Params)
    if target_title:
        try:
            logger.info(f"📍 Looking for official category: {target_title}")
            categories = yt.get_mood_categories()
            
            target_params = None
            # Шукаємо params для нашої категорії
            for section in categories.values():
                for item in section:
                    if item['title'].lower() == target_title.lower():
                        target_params = item['params']
                        break
                if target_params: break
            
            if target_params:
                # Отримуємо сторінку категорії
                logger.info(f"✅ Params found. Fetching playlists...")
                mood_page = yt.get_mood_playlists(target_params)
                
                # Шукаємо перший валідний плейлист у секціях
                # YTM повертає список секцій: [{'title': 'Highlights', 'playlists': [...]}, ...]
                for section in mood_page:
                    if 'playlists' in section and section['playlists']:
                        # Беремо перший плейлист з першої секції (зазвичай це Топ/Highlights)
                        playlist_id = section['playlists'][0].get('browseId')
                        logger.info(f"🎯 Selected Playlist: {section['playlists'][0].get('title')}")
                        break
        except Exception as e:
            logger.error(f"❌ Params strategy failed: {e}")

    # Пошук плейлиста (fallback)
    if not playlist_id:
        search_query = SEARCH_FALLBACK_MAP.get(category_key, target_title or category_key.replace("cat_", "").replace("_", " ")) + " playlist"
        logger.info(f"🔍 Fallback to Search: '{search_query}'")
        try:
            # Шукаємо саме ПЛЕЙЛИСТИ (filter='playlists')
            search_results = yt.search(search_query, filter='playlists', limit=3)
            if search_results:
                playlist_id = search_results[0]['browseId']
                logger.info(f"🎯 Found via Search: {search_results[0]['title']}")
        except Exception as e:
            logger.error(f"❌ Search strategy failed: {e}")

    # Отримання треків
    if not playlist_id:
        return []

    try:
        logger.info(f"📥 Extracting tracks from {playlist_id}...")
        playlist_data = yt.get_playlist(playlist_id, limit=50) # Беремо топ-50
        
        tracks = []
        for item in playlist_data.get('tracks', []):
            parsed = parse_item(item)
            if parsed: tracks.append(parsed)
            
        return tracks
    except Exception as e:
        logger.error(f"❌ Track extraction failed: {e}")
        return []




def fetch_new_releases_sync():
    """Отримує нові альбоми/сингли через Explore (Dict Support)"""
    logger.info(f"🆕 Fetching New Releases via Explore...")
    yt = YTMusic(language='en') 
    try:
        explore_data = yt.get_explore()
        
        raw_items = []

        # Dict response (current YTMusic format)
        if isinstance(explore_data, dict):
            # Логуємо ключі для налагодження
            # logger.info(f"🔍 Explore keys: {list(explore_data.keys())}")
            
            # Шукаємо ключ 'new_releases'
            if 'new_releases' in explore_data:
                section_content = explore_data['new_releases']
                
                # Іноді це список треків
                if isinstance(section_content, list):
                    raw_items = section_content
                # Іноді це словник з ключем 'items' або 'contents'
                elif isinstance(section_content, dict):
                    raw_items = section_content.get('items', []) or section_content.get('contents', [])
            else:
                logger.warning("⚠️ Key 'new_releases' not found in Explore dict")

        # List response (legacy format)
        elif isinstance(explore_data, list):
            for section in explore_data:
                if not isinstance(section, dict): continue
                title = section.get('title', '')
                if 'New releases' in title or 'Released' in title:
                    raw_items = section.get('contents', [])
                    break
        
        parsed_items = []
        for item in raw_items:
            if not isinstance(item, dict): continue

            title = item.get('title')
            browse_id = item.get('browseId')
            
            # Якщо немає ID або назви — це сміття
            if not title or not browse_id: continue

            # Витягуємо артиста (буває в різних полях)
            artist = "Unknown"
            subtitle = item.get('subtitle')
            if isinstance(subtitle, str):
                artist = subtitle
            elif isinstance(subtitle, list) and subtitle:
                artist = subtitle[0].get('text', 'Unknown')
            elif 'artists' in item and item['artists']:
                artist = item['artists'][0].get('name', 'Unknown')

            # Обкладинка
            thumbnails = item.get('thumbnails', [])
            cover = thumbnails[-1]['url'] if thumbnails else ""

            parsed_items.append({
                "id": browse_id,
                "title": title,
                "artist": artist,
                "cover": cover,
                "type": "album", # Новинки зазвичай альбоми/сингли
                "source": "youtube"
            })

        logger.info(f"✅ Found {len(parsed_items)} new releases")
        return parsed_items

    except Exception as e:
        logger.error(f"❌ New Releases fetch failed: {e}")
        return []
     
def get_auth_headers():
    """Шукає та парсить cookies воркерів."""
    auth_file = 'browser.json'
    if os.path.exists(auth_file): return auth_file

    cookie_source = None
    for i in range(1, 10):
        fname = f'worker{i}_cookies.txt'
        if os.path.exists(fname):
            cookie_source = fname
            break
            
    if not cookie_source: return None

    try:
        cookies = []
        with open(cookie_source, 'r', encoding='utf-8') as f:
            for line in f:
                if not line.startswith('#') and line.strip():
                    parts = line.strip().split('\t')
                    if len(parts) >= 7:
                        cookies.append(f"{parts[5]}={parts[6]}")
        
        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
            "Accept": "*/*",
            "Accept-Language": "en-US,en;q=0.9",
            "Content-Type": "application/json",
            "Cookie": "; ".join(cookies),
            "x-origin": "https://music.youtube.com"
        }
        
        with open(auth_file, 'w') as f: json.dump(headers, f)
        return auth_file
    except: return None

def parse_item(item):
    """
    Витягує дані з елемента, навіть якщо поля відсутні або структура змінилась.
    """
    try:
        title = item.get("title", "Unknown Track")
        
        # Артист (обробка різних варіантів відповіді)
        artist = "Unknown"
        if "artists" in item and isinstance(item["artists"], list) and item["artists"]:
            artist = item["artists"][0].get("name", "Unknown")
        elif "runs" in item: # Для деяких старих форматів
             artist = "Unknown Artist"

        # Картинка
        cover = "https://via.placeholder.com/150"
        if "thumbnails" in item and isinstance(item["thumbnails"], list) and item["thumbnails"]:
            cover = item["thumbnails"][-1].get("url", "")
        
        # ID
        video_id = item.get("videoId")
        browse_id = item.get("browseId")
        
        if not video_id and not browse_id: return None

        return {
            "title": title,
            "artist": artist,
            "cover": cover,
            "id": video_id or browse_id,
            "type": "video" if video_id else "album"
        }
    except: return None

def fetch_explore_data_sync(user_lang: str):
    params = YT_PARAMS_MAP.get(user_lang, {'lang': 'en', 'loc': 'US'})
    auth_file = get_auth_headers()
    
    logger.info(f"🎧 [Worker] Fetching Explore for {user_lang}")

    try:
        yt = YTMusic(language='en', location=params['loc'])
        yt.language = params['lang']
        
        # 3. Додатково прописуємо заголовки для надійності
        yt.headers["Accept-Language"] = f"{params['lang']}-{params['loc']},{params['lang']};q=0.9,en;q=0.8"
        yt.headers["Content-Language"] = params['lang']
        
    except Exception as e:
        logger.error(f"YTMusic Init Error: {e}")
        yt = YTMusic()

    data = { "new_releases": [], "charts": [], "moods": [] }

    # 1. Charts (Основне джерело)
    try:
        charts_raw = yt.get_charts(country=params['loc'])
        
        # Спроба дістати Trending
        if 'trending' in charts_raw and 'items' in charts_raw['trending']:
             for item in charts_raw['trending']['items'][:12]:
                 parsed = parse_item(item)
                 if parsed: data["new_releases"].append(parsed)

        # Спроба дістати Top Songs
        if 'songs' in charts_raw and 'items' in charts_raw['songs']:
            for item in charts_raw['songs']['items'][:12]:
                parsed = parse_item(item)
                if parsed: data["charts"].append(parsed)
                
        # Fallback: Videos
        elif 'videos' in charts_raw and 'items' in charts_raw['videos']:
            for item in charts_raw['videos']['items'][:12]:
                parsed = parse_item(item)
                if parsed: data["charts"].append(parsed)

    except Exception as e: 
        logger.error(f"Charts Error: {e}")

    # 2. Moods
    try:
        if hasattr(yt, 'get_mood_categories'):
            moods_raw = yt.get_mood_categories()
            count = 0
            for _, cats in moods_raw.items():
                for c in cats[:4]:
                    data["moods"].append({"title": c["title"], "params": c["params"], "type": "mood"})
                    count += 1
                if count > 12: break
    except: pass
    
    if not data["new_releases"] and data["charts"]:
        logger.info("⚠️ New Releases empty, filling from Charts")
        data["new_releases"] = data["charts"][:10]

    if not data["charts"]:
        try:
            search_res = yt.search("Top Hits 2024", filter="songs", limit=15)
            for item in search_res:
                parsed = parse_item(item)
                if parsed: data["charts"].append(parsed)
            # І дублюємо в New
            if not data["new_releases"]:
                data["new_releases"] = data["charts"][:10]
        except: pass

    logger.info(f"✅ Fetched: New={len(data['new_releases'])}, Charts={len(data['charts'])}, Moods={len(data['moods'])}")
    return data

async def get_cached_explore(lang: str = 'en'):
    redis_key = f"explore_page_v8:{lang}"
    
    cached = await redis_client.redis.get(redis_key)
    if cached: return json.loads(cached)

    logger.info(f"⚡ Cache miss for {lang}. Queueing task...")
    task = json.dumps({"lang": lang})
    await redis_client.redis.lpush("explore_queue", task)
    
    return { "sections": [], "status": "loading" }

def fetch_album_details_sync(album_id):
    """Отримує деталі альбому та список треків"""
    logger.info(f"💿 Fetching Album: {album_id}")
    yt = YTMusic(language='en')
    try:
        album = yt.get_album(album_id)
        tracks = []
        
        # Обкладинка альбому (найбільша)
        album_cover = album.get('thumbnails', [{}])[-1].get('url', '')

        for t in album.get('tracks', []):
            tracks.append({
                "id": t.get('videoId'),
                "title": t.get('title'),
                "artist": t.get('artists', [{}])[0].get('name', 'Unknown'),
                "duration": t.get('duration_seconds'),
                "cover": album_cover, # У пісень альбому зазвичай спільна обкладинка
                "type": "song",
                "source": "youtube",
                "album": album.get('title')
            })
        
        return {
            "id": album_id,
            "title": album.get('title'),
            "description": album.get('description'),
            "cover": album_cover,
            "items": tracks
        }
    except Exception as e:
        logger.error(f"❌ Failed to fetch album {album_id}: {e}")
        return None

def fetch_playlist_details_sync(playlist_id):
    """Отримує деталі плейлиста (наприклад, Charts)"""
    logger.info(f"📜 Fetching Playlist: {playlist_id}")
    yt = YTMusic(language='en')
    try:
        # limit=100 щоб не вантажити занадто багато
        playlist = yt.get_playlist(playlist_id, limit=100)
        tracks = []
        
        playlist_cover = playlist.get('thumbnails', [{}])[-1].get('url', '')

        for t in playlist.get('tracks', []):
            if not t.get('videoId'): continue # Пропускаємо треки без ID
            
            # Обкладинка треку або плейлиста
            thumbnails = t.get('thumbnails', [])
            cover = thumbnails[-1].get('url') if thumbnails else playlist_cover

            tracks.append({
                "id": t.get('videoId'),
                "title": t.get('title'),
                "artist": t.get('artists', [{}])[0].get('name', 'Unknown'),
                "duration": t.get('duration_seconds'),
                "cover": cover,
                "type": "song",
                "source": "youtube",
                "album": t.get('album', {}).get('name') if t.get('album') else ""
            })
            
        return {
            "id": playlist_id,
            "title": playlist.get('title'),
            "description": playlist.get('description'),
            "cover": playlist_cover,
            "items": tracks
        }
    except Exception as e:
        logger.error(f"❌ Failed to fetch playlist {playlist_id}: {e}")
        return None


def fetch_artist_details_sync(artist_id: str):
    """Отримує профіль артиста: топ-треки, альбоми, схожі."""
    logger.info(f"🎤 Fetching Artist: {artist_id}")
    yt = YTMusic(language='en')
    try:
        browse_id = artist_id
        if not browse_id.startswith('UC') and not browse_id.startswith('MPRE'):
            search_results = yt.search(artist_id, filter='artists', limit=1)
            if not search_results:
                return None
            browse_id = search_results[0].get('browseId') or search_results[0].get('channelId')
            if not browse_id:
                return None

        artist = yt.get_artist(browse_id)
        if not artist:
            return None

        thumbnails = artist.get('thumbnails', [])
        cover = thumbnails[-1].get('url', '') if thumbnails else ''

        top_tracks = []
        songs_section = artist.get('songs', {}) or {}
        for t in (songs_section.get('results') or [])[:20]:
            vid = t.get('videoId')
            if not vid:
                continue
            thumbs = t.get('thumbnails', [])
            track_cover = thumbs[-1].get('url') if thumbs else cover
            top_tracks.append({
                "id": vid,
                "title": t.get('title', 'Unknown'),
                "artist": artist.get('name') or artist_id,
                "duration": t.get('duration_seconds'),
                "cover": track_cover,
                "type": "song",
                "source": "youtube",
            })

        albums = []
        albums_section = artist.get('albums', {}) or {}
        for a in (albums_section.get('results') or [])[:12]:
            album_id = a.get('browseId')
            if not album_id:
                continue
            a_thumbs = a.get('thumbnails', [])
            albums.append({
                "id": album_id,
                "title": a.get('title', 'Album'),
                "cover": a_thumbs[-1].get('url') if a_thumbs else cover,
                "type": "album",
                "year": a.get('year'),
            })

        similar = []
        related = artist.get('related') or artist.get('similar') or {}
        for s in (related.get('results') if isinstance(related, dict) else related or [])[:8]:
            if not isinstance(s, dict):
                continue
            s_id = s.get('browseId') or s.get('channelId')
            if not s_id:
                continue
            s_thumbs = s.get('thumbnails', [])
            similar.append({
                "id": s_id,
                "title": s.get('title') or s.get('name', 'Artist'),
                "cover": s_thumbs[-1].get('url') if s_thumbs else '',
                "type": "artist",
            })

        return {
            "id": browse_id,
            "title": artist.get('name') or artist_id,
            "description": artist.get('description', ''),
            "cover": cover,
            "items": top_tracks,
            "albums": albums,
            "similar_artists": similar,
            "type": "artist",
        }
    except Exception as e:
        logger.error(f"❌ Failed to fetch artist {artist_id}: {e}")
        return None