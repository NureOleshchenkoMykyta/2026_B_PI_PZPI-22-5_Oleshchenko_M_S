from sqlalchemy import Column, Integer, String, Boolean, DateTime, BigInteger, Enum, ForeignKey, Text, Date, Index, UniqueConstraint, text, Numeric, Float
from sqlalchemy.orm import relationship, declarative_base
from sqlalchemy.sql import func
import enum
from sqlalchemy.dialects.postgresql import JSONB


Base = declarative_base()

# Визначаємо ENUM для Python
# Важливо: значення мають точно відповідати тому, що в базі ('free', 'plus', 'premium')
class AccountTier(str, enum.Enum):
    FREE = "free"
    PLUS = "plus"
    PREMIUM = "premium"


class CachedContent(Base):
    """
    Кеш для зовнішніх колекцій (Альбоми, Плейлисти, Чарти).
    Зберігає структуру, щоб не робити запити до YouTube API щоразу.
    """
    __tablename__ = 'cached_content'

    source_id = Column(String, primary_key=True)  # YouTube BrowseID (MPREb..., VL...)
    type = Column(String, nullable=False)         # 'album', 'playlist'
    
    title = Column(String)
    artist = Column(String)       # Для альбому - виконавець, для плейлиста - автор
    description = Column(Text)
    cover = Column(String)        # Картинка альбому
    
    # Тут зберігаємо "легкий" список треків:
    # [{"id": "...", "title": "...", "artist": "...", "duration": 123}, ...]
    items_data = Column(JSONB) 
    
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

    __table_args__ = (
        Index('idx_cached_content_updated_at', 'updated_at'),
    )
    
class User(Base):
    __tablename__ = "users"

    user_id = Column(BigInteger, primary_key=True, index=True)
    username = Column(String(255), nullable=True)
    full_name = Column(String(255), nullable=True)
    language = Column(String(5), default='en')
    
    tier = Column(
        Enum(AccountTier, name="account_tier", native_enum=True, values_callable=lambda x: [e.value for e in x]),
        default=AccountTier.FREE,
        server_default="free"
    )
    
    @property
    def is_premium(self):
        return self.tier == AccountTier.PREMIUM

    subscription_type = Column(String(50), default="free")
    subscription_expires_at = Column(DateTime(timezone=True), nullable=True)
    
    mode = Column(String(20), default='light')
    
    silent_mode = Column(Boolean, default=False)

    music_preferences = Column(JSONB, default=dict, server_default=text("'{}'::jsonb"))
    onboarding_completed = Column(Boolean, default=False, server_default=text("false"))
    filter_explicit = Column(Boolean, default=False, server_default=text("false"))
    
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    last_activity_date = Column(Date, default=func.current_date())
    fast_downloads_today = Column(Integer, default=0)

    playlists = relationship("Playlist", back_populates="user", cascade="all, delete-orphan")
    listening_history = relationship("ListeningHistory", back_populates="user", cascade="all, delete-orphan")
class Track(Base):
    __tablename__ = "tracks"

    track_id = Column(Integer, primary_key=True, index=True)
    source_id = Column(String(255), unique=True, index=True, nullable=False)
    
    title = Column(String(255))
    artist = Column(String(255))
    duration = Column(Integer)
    source_url = Column(String(512))
    
    telegram_file_id = Column(String(512), index=True)
    
    # R2
    r2_key = Column(String(255), nullable=True)
    r2_url = Column(String(512), nullable=True) 
    
    cover_small = Column(String)
    cover_big = Column(String)
    
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    __table_args__ = (
        Index('idx_tracks_title_trgm', 'title', postgresql_using='gin', postgresql_ops={'title': 'gin_trgm_ops'}),
        Index('idx_tracks_artist_trgm', 'artist', postgresql_using='gin', postgresql_ops={'artist': 'gin_trgm_ops'}),
    )

class SystemSetting(Base):
    __tablename__ = "system_settings"
    key = Column(String(50), primary_key=True)
    value = Column(String(255), nullable=False)

class PlaylistQueue(Base):
    __tablename__ = "playlist_queue"
    id = Column(Integer, primary_key=True, autoincrement=True)
    url = Column(String(512), unique=True, nullable=False)
    title = Column(String(255), nullable=True)
    is_downloaded = Column(Boolean, default=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    __table_args__ = (
        Index('idx_playlist_queue_pending', 'is_downloaded', postgresql_where=(is_downloaded == False)),
    )

class SearchHistory(Base):
    __tablename__ = "search_history"
    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(BigInteger, ForeignKey("users.user_id"), index=True)
    query = Column(String, nullable=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

class DownloadHistory(Base):
    __tablename__ = "download_history"
    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(BigInteger, ForeignKey("users.user_id"), index=True)
    track_id = Column(Integer, ForeignKey("tracks.track_id"), index=True)
    is_cached = Column(Boolean, default=False)
    source_type = Column(String(50))
    created_at = Column(DateTime(timezone=True), server_default=func.now())

class UserPlaylist(Base):
    __tablename__ = "user_playlists"
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(BigInteger, index=True)
    track_id = Column(String(255), index=True)
    added_at = Column(DateTime(timezone=True), server_default=func.now())

    __table_args__ = (
        Index('idx_userplaylist_user_added', 'user_id', 'added_at'),
        UniqueConstraint('user_id', 'track_id', name='uq_user_track_like'),
    )
class GoogleAccount(Base):
    __tablename__ = "google_accounts"
    
    id = Column(Integer, primary_key=True)
    email = Column(String(255), unique=True)
    # Поля збігаються зі схемою БД (імпорт/сесії куків їх не обов’язково читають)
    password = Column(String(255), nullable=True)
    two_fa_secret = Column(String(255), nullable=True)
    recovery_email = Column(String(255), nullable=True)
    cookie_content = Column(Text, nullable=False)
    user_agent = Column(String(512), nullable=True)
    assigned_worker_id = Column(Integer, default=1)
    proxy_label = Column(String(255), nullable=True)

    is_active = Column(Boolean, default=True)
    error_count = Column(Integer, default=0)
    last_used_at = Column(DateTime(timezone=True), server_default=func.now())

class NetworkNode(Base):
    __tablename__ = "network_nodes"
    id = Column(Integer, primary_key=True, autoincrement=True)
    worker_id = Column(Integer, unique=True, nullable=False)
    name = Column(String(255))
    connection_type = Column(String(50), default="vpn_container")
    host = Column(String(255))
    port = Column(Integer)
    auth_login = Column(String(255), nullable=True)
    auth_password = Column(String(255), nullable=True)
    is_ipv6 = Column(Boolean, default=False)

class PlaylistLike(Base):
    __tablename__ = "playlist_likes"
    user_id = Column(BigInteger, ForeignKey('users.user_id', ondelete='CASCADE'), primary_key=True)
    playlist_id = Column(Integer, ForeignKey('playlists.id', ondelete='CASCADE'), primary_key=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    
class Playlist(Base):
    __tablename__ = "playlists"
    
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(BigInteger, ForeignKey('users.user_id', ondelete='CASCADE'))
    title = Column(String(255))
    description = Column(String(512), nullable=True)
    cover = Column(String(512), nullable=True)
    is_pinned = Column(Boolean, default=False)
    
    is_public = Column(Boolean, default=False, index=True)
    tags = Column(JSONB, default=[]) 
    likes_count = Column(Integer, default=0)
    
    track_count = Column(Integer, default=0)
    liked_by_users = relationship("PlaylistLike", cascade="all, delete-orphan")
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    user = relationship("User", back_populates="playlists")
    tracks = relationship("PlaylistTrack", back_populates="playlist", cascade="all, delete-orphan")

    __table_args__ = (
        Index('idx_playlists_sort', 'user_id', 'is_pinned', 'created_at'),
        Index('idx_playlists_public', 'is_public', 'likes_count'),
    )


        
class PlaylistTrack(Base):
    __tablename__ = "playlist_tracks"
    
    id = Column(Integer, primary_key=True, index=True)
    playlist_id = Column(Integer, ForeignKey("playlists.id", ondelete="CASCADE"))
    track_source_id = Column(String(255)) 
    position = Column(Integer, default=0)
    added_at = Column(DateTime(timezone=True), server_default=func.now())
    
    playlist = relationship("Playlist", back_populates="tracks")

    __table_args__ = (
        Index('idx_playlist_tracks_playlist_position', 'playlist_id', 'position'),
        Index('idx_playlist_tracks_playlist_added', 'playlist_id', 'added_at'),
        Index('idx_playlist_tracks_track_source_id', 'track_source_id'),
    )

class ListeningHistory(Base):
    __tablename__ = "listening_history"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(BigInteger, ForeignKey('users.user_id', ondelete='CASCADE'))
    track_id = Column(Integer, ForeignKey('tracks.track_id', ondelete='CASCADE'), nullable=False)
    track_source_id = Column(String(255)) 
    listened_at = Column(DateTime(timezone=True), server_default=func.now())
    playback_position = Column(Float, default=0.0, server_default=text("0"))

    user = relationship("User", back_populates="listening_history")
    track = relationship("Track")

    __table_args__ = (
        Index('idx_listening_user_date', 'user_id', 'listened_at'),
        Index('idx_listening_track_source_id', 'track_source_id'),
        Index('idx_listening_user_track', 'user_id', 'track_source_id'),
    )


class SubscriptionPayment(Base):
    __tablename__ = "subscription_payments"

    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(BigInteger, ForeignKey("users.user_id", ondelete="CASCADE"), index=True)
    amount = Column(Numeric(10, 2), nullable=False)
    currency = Column(String(3), default="UAH")
    plan_type = Column(String(50), nullable=False)
    payment_provider = Column(String(50), nullable=True)
    transaction_id = Column(String(255), nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())


class PlaylistCollaborator(Base):
    __tablename__ = "playlist_collaborators"

    playlist_id = Column(Integer, ForeignKey("playlists.id", ondelete="CASCADE"), primary_key=True)
    user_id = Column(BigInteger, ForeignKey("users.user_id", ondelete="CASCADE"), primary_key=True)
    role = Column(String(20), default="editor")
    invited_at = Column(DateTime(timezone=True), server_default=func.now())

    __table_args__ = (
        Index('idx_playlist_collab_user', 'user_id'),
    )


class UserFollow(Base):
    __tablename__ = "user_follows"

    follower_id = Column(BigInteger, ForeignKey("users.user_id", ondelete="CASCADE"), primary_key=True)
    following_id = Column(BigInteger, ForeignKey("users.user_id", ondelete="CASCADE"), primary_key=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    __table_args__ = (
        Index('idx_user_follows_following', 'following_id'),
    )


class TrackLyrics(Base):
    """Persistent lyrics cache keyed by track source_id (e.g. YouTube video id)."""
    __tablename__ = "track_lyrics"

    source_id = Column(String(255), primary_key=True)
    title = Column(String(255), nullable=True)
    artist = Column(String(255), nullable=True)
    lyrics = Column(Text, nullable=False)
    synced = Column(Boolean, default=False, server_default=text("false"))
    source = Column(String(64), nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

    __table_args__ = (
        Index('idx_track_lyrics_title_trgm', 'title', postgresql_using='gin', postgresql_ops={'title': 'gin_trgm_ops'}),
        Index('idx_track_lyrics_artist_trgm', 'artist', postgresql_using='gin', postgresql_ops={'artist': 'gin_trgm_ops'}),
    )