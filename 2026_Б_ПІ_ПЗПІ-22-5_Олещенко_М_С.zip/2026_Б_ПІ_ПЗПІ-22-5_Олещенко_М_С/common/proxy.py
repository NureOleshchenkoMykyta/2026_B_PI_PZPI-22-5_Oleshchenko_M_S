"""Outbound proxy list from PROXY_URL (comma- or newline-separated)."""

from __future__ import annotations

import os
import random
from typing import List, Optional


def proxy_urls_from_env() -> List[str]:
    raw = (os.getenv("PROXY_URL") or "").strip()
    if not raw:
        return []
    out: List[str] = []
    for chunk in raw.replace("\n", ",").split(","):
        c = chunk.strip()
        if c:
            out.append(c)
    return out


def pick_proxy_url() -> Optional[str]:
    urls = proxy_urls_from_env()
    return random.choice(urls) if urls else None


def has_proxy_configured() -> bool:
    return bool(proxy_urls_from_env())
