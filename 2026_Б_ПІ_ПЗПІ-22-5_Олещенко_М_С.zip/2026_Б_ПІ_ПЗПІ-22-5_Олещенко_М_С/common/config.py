import os
from pydantic_settings import BaseSettings, SettingsConfigDict
from pydantic import SecretStr
from urllib.parse import quote_plus
from typing import Optional

class Settings(BaseSettings):
    BOT_TOKEN: SecretStr
    R2_PUBLIC_URL: str = ""
    DB_USER: str = "postgres"
    DB_PASSWORD: SecretStr = SecretStr("password")
    DB_NAME: str = "hydra"
    DB_HOST: str = "db"
    DB_PORT: int = 5432
    DB_SSLMODE: str = "disable"
    DB_ECHO: bool = False
    API_URL: str = ""
    REDIS_URL: str = "redis://redis"
    AUTH_DEBUG: bool = False
    # Comma-separated Host values (no port) allowed for debug auth when AUTH_DEBUG=true.
    # Example: nikkme.online,www.nikkme.online — browser testing on prod domain without Telegram initData.
    AUTH_DEBUG_HOSTS: str = ""
    CORS_ORIGINS: str = (
        "http://localhost:5173,http://127.0.0.1:5173,"
        "http://localhost:5174,http://127.0.0.1:5174,"
        "http://localhost:8080,http://127.0.0.1:8080,"
        "http://localhost:8005,http://127.0.0.1:8005,"
        "https://nikkme.online,https://www.nikkme.online,"
        "https://admin.nikkme.online"
    )
    # Optional: set in `.env` to require `X-Admin-Key` on `/api/admin/*`. Empty = no key required (local dev).
    ADMIN_API_KEY: Optional[SecretStr] = None
    SEARCH_API_SECRET: Optional[SecretStr] = None
    RECOGNIZE_MAX_BYTES: int = 10 * 1024 * 1024
    RECOGNIZE_TIMEOUT_SEC: float = 60.0
    RECOGNIZE_RATE_LIMIT_PER_MINUTE: int = 10
    ACCESS_CODE: str = "1234"
    BOT_LINK: str = os.getenv("BOT_LINK", "@hydra_music_bot")
    CF_WORKER_URL: Optional[str] = None 
    CF_WORKER_SECRET: Optional[SecretStr] = None
    ARCHIVE_CHANNEL_ID: int = 0 
    
    API_ID: int = 12345
    API_HASH: str = "hash"
    TELEGRAM_API_SERVER_URL: Optional[str] = None
    # Публічний URL Mini App (HTTPS), напр. https://nikkme.online — кнопка в Reply-меню бота.
    TELEGRAM_WEBAPP_URL: str = ""

    ADMIN_ID: int = 871451920

    @property
    def DATABASE_URL(self):
        # Отримуємо значення пароля з SecretStr
        password = self.DB_PASSWORD.get_secret_value() if self.DB_PASSWORD else ""
        encoded_pass = quote_plus(password)
        
        url = f"postgresql+asyncpg://{self.DB_USER}:{encoded_pass}@{self.DB_HOST}:{self.DB_PORT}/{self.DB_NAME}"
        
        if self.DB_SSLMODE != "disable":
            url += f"?ssl={self.DB_SSLMODE}"
        return url

    model_config = SettingsConfigDict(
        env_file=".env", 
        env_file_encoding="utf-8",
        extra="ignore"
    )

# Ініціалізація налаштувань
# Якщо змінні не знайдені в .env, будуть використані значення за замовчуванням
try:
    settings = Settings()
except Exception as e:
    print(f"Failed to load settings: {e}")
    # Фолбек для запобігання падінню при імпорті (для дебагу)
    class MockSettings:
        API_ID = 0
        API_HASH = ""
        BOT_TOKEN = SecretStr("")
        DATABASE_URL = ""
        REDIS_URL = ""
        R2_PUBLIC_URL = ""
        API_URL = ""
        DB_ECHO = False
        ADMIN_ID = 0
        AUTH_DEBUG = False
        CORS_ORIGINS = (
            "http://localhost:5173,http://127.0.0.1:5173,"
            "http://localhost:5174,http://127.0.0.1:5174,"
            "http://localhost:8080,http://127.0.0.1:8080,"
            "http://localhost:8005,http://127.0.0.1:8005,"
            "https://nikkme.online,https://www.nikkme.online,"
            "https://admin.nikkme.online"
        )
        ADMIN_API_KEY = None
        SEARCH_API_SECRET = None
        RECOGNIZE_MAX_BYTES = 10 * 1024 * 1024
        RECOGNIZE_TIMEOUT_SEC = 60.0
        RECOGNIZE_RATE_LIMIT_PER_MINUTE = 10
        TELEGRAM_WEBAPP_URL = ""
    settings = MockSettings()

# Експорт змінних для зручності імпорту в інших файлах
API_ID = settings.API_ID
API_HASH = settings.API_HASH
# Перетворюємо SecretStr в str для використання в коді
BOT_TOKEN = settings.BOT_TOKEN.get_secret_value() if isinstance(settings.BOT_TOKEN, SecretStr) else str(settings.BOT_TOKEN)
DATABASE_URL = settings.DATABASE_URL
REDIS_URL = settings.REDIS_URL
ADMIN_ID = settings.ADMIN_ID