--
-- PostgreSQL database dump
--

\restrict 8B8qeimStdpUo4TKh8V6JJLMg4fSYljeZTTJvTrOQhHIgwh4QJagrwEQ4IaI3jG

-- Dumped from database version 18.1 (Ubuntu 18.1-1.pgdg24.04+2)
-- Dumped by pg_dump version 18.1 (Ubuntu 18.1-1.pgdg24.04+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pg_trgm; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_trgm WITH SCHEMA public;


--
-- Name: EXTENSION pg_trgm; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_trgm IS 'text similarity measurement and index searching based on trigrams';


--
-- Name: account_tier; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.account_tier AS ENUM (
    'free',
    'plus',
    'premium'
);


ALTER TYPE public.account_tier OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: cached_content; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cached_content (
    source_id character varying NOT NULL,
    type character varying NOT NULL,
    title character varying,
    artist character varying,
    description text,
    cover character varying,
    items_data jsonb,
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.cached_content OWNER TO postgres;

--
-- Name: download_history; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.download_history (
    id integer NOT NULL,
    user_id bigint NOT NULL,
    track_id integer NOT NULL,
    is_cached boolean DEFAULT false,
    source_type character varying(50),
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.download_history OWNER TO postgres;

--
-- Name: download_history_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.download_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.download_history_id_seq OWNER TO postgres;

--
-- Name: download_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.download_history_id_seq OWNED BY public.download_history.id;


--
-- Name: google_accounts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.google_accounts (
    id integer NOT NULL,
    email character varying(255) NOT NULL,
    password character varying(255),
    two_fa_secret character varying(255),
    recovery_email character varying(255),
    cookie_content text NOT NULL,
    user_agent character varying(512),
    assigned_worker_id integer NOT NULL,
    proxy_label character varying(255),
    is_active boolean,
    last_used timestamp with time zone DEFAULT now(),
    error_count integer DEFAULT 0,
    last_used_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.google_accounts OWNER TO postgres;

--
-- Name: google_accounts_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.google_accounts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.google_accounts_id_seq OWNER TO postgres;

--
-- Name: google_accounts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.google_accounts_id_seq OWNED BY public.google_accounts.id;


--
-- Name: listening_history; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.listening_history (
    id integer NOT NULL,
    user_id bigint NOT NULL,
    track_source_id character varying(255) NOT NULL,
    listened_at timestamp with time zone DEFAULT now(),
    track_id integer NOT NULL
);


ALTER TABLE public.listening_history OWNER TO postgres;

--
-- Name: listening_history_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.listening_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.listening_history_id_seq OWNER TO postgres;

--
-- Name: listening_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.listening_history_id_seq OWNED BY public.listening_history.id;


--
-- Name: network_nodes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.network_nodes (
    id integer NOT NULL,
    worker_id integer NOT NULL,
    name character varying(255),
    connection_type character varying(50),
    host character varying(255),
    port integer,
    auth_login character varying(255),
    auth_password character varying(255),
    is_ipv6 boolean
);


ALTER TABLE public.network_nodes OWNER TO postgres;

--
-- Name: network_nodes_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.network_nodes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.network_nodes_id_seq OWNER TO postgres;

--
-- Name: network_nodes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.network_nodes_id_seq OWNED BY public.network_nodes.id;


--
-- Name: playlist_likes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.playlist_likes (
    user_id bigint NOT NULL,
    playlist_id integer NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.playlist_likes OWNER TO postgres;

--
-- Name: playlist_queue; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.playlist_queue (
    id integer NOT NULL,
    url character varying(512) NOT NULL,
    title character varying(255),
    is_downloaded boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.playlist_queue OWNER TO postgres;

--
-- Name: playlist_queue_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.playlist_queue_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.playlist_queue_id_seq OWNER TO postgres;

--
-- Name: playlist_queue_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.playlist_queue_id_seq OWNED BY public.playlist_queue.id;


--
-- Name: playlist_tracks; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.playlist_tracks (
    id integer NOT NULL,
    playlist_id integer NOT NULL,
    track_source_id character varying(255) NOT NULL,
    "position" integer DEFAULT 0,
    added_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.playlist_tracks OWNER TO postgres;

--
-- Name: playlist_tracks_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.playlist_tracks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.playlist_tracks_id_seq OWNER TO postgres;

--
-- Name: playlist_tracks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.playlist_tracks_id_seq OWNED BY public.playlist_tracks.id;


--
-- Name: playlists; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.playlists (
    id integer NOT NULL,
    user_id bigint NOT NULL,
    title character varying(255) NOT NULL,
    description character varying(512),
    cover character varying(512),
    is_pinned boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT now(),
    is_public boolean DEFAULT false,
    tags jsonb DEFAULT '[]'::jsonb,
    likes_count integer DEFAULT 0,
    track_count integer DEFAULT 0
);


ALTER TABLE public.playlists OWNER TO postgres;

--
-- Name: playlists_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.playlists_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.playlists_id_seq OWNER TO postgres;

--
-- Name: playlists_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.playlists_id_seq OWNED BY public.playlists.id;


--
-- Name: search_history; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.search_history (
    id integer NOT NULL,
    user_id bigint NOT NULL,
    query text NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.search_history OWNER TO postgres;

--
-- Name: search_history_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.search_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.search_history_id_seq OWNER TO postgres;

--
-- Name: search_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.search_history_id_seq OWNED BY public.search_history.id;


--
-- Name: subscription_payments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.subscription_payments (
    id integer NOT NULL,
    user_id bigint NOT NULL,
    amount numeric(10,2) NOT NULL,
    currency character varying(3) DEFAULT 'UAH'::character varying,
    plan_type character varying(50) NOT NULL,
    payment_provider character varying(50),
    transaction_id character varying(255),
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.subscription_payments OWNER TO postgres;

--
-- Name: subscription_payments_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.subscription_payments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.subscription_payments_id_seq OWNER TO postgres;

--
-- Name: subscription_payments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.subscription_payments_id_seq OWNED BY public.subscription_payments.id;


--
-- Name: system_settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.system_settings (
    key character varying(50) NOT NULL,
    value character varying(255) NOT NULL
);


ALTER TABLE public.system_settings OWNER TO postgres;

--
-- Name: tracks; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tracks (
    track_id integer NOT NULL,
    title character varying(255) NOT NULL,
    artist character varying(255),
    duration integer,
    source_url character varying(512),
    source_id character varying(255),
    telegram_file_id character varying(512) NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    r2_url character varying(512),
    cover_small character varying(512),
    cover_big character varying(512),
    r2_key character varying(255)
);


ALTER TABLE public.tracks OWNER TO postgres;

--
-- Name: tracks_track_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tracks_track_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.tracks_track_id_seq OWNER TO postgres;

--
-- Name: tracks_track_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tracks_track_id_seq OWNED BY public.tracks.track_id;


--
-- Name: user_playlists; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_playlists (
    id integer NOT NULL,
    user_id bigint NOT NULL,
    track_id character varying(255) NOT NULL,
    added_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.user_playlists OWNER TO postgres;

--
-- Name: user_playlists_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.user_playlists_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_playlists_id_seq OWNER TO postgres;

--
-- Name: user_playlists_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.user_playlists_id_seq OWNED BY public.user_playlists.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    user_id bigint NOT NULL,
    username character varying(255),
    full_name character varying(255),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    is_admin boolean DEFAULT false,
    is_approved boolean DEFAULT false,
    language character varying(5) DEFAULT NULL::character varying,
    batch_size integer DEFAULT 3,
    mode character varying(50) DEFAULT 'light'::character varying,
    silent_mode boolean DEFAULT false,
    subscription_tier character varying(50) DEFAULT 'free'::character varying NOT NULL,
    subscription_expires_at timestamp with time zone,
    fast_downloads_today integer DEFAULT 0,
    last_download_date date DEFAULT CURRENT_DATE,
    subscription_type character varying DEFAULT 'free'::character varying,
    last_activity_date date DEFAULT CURRENT_DATE,
    tier public.account_tier DEFAULT 'free'::public.account_tier
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: download_history id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.download_history ALTER COLUMN id SET DEFAULT nextval('public.download_history_id_seq'::regclass);


--
-- Name: google_accounts id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.google_accounts ALTER COLUMN id SET DEFAULT nextval('public.google_accounts_id_seq'::regclass);


--
-- Name: listening_history id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.listening_history ALTER COLUMN id SET DEFAULT nextval('public.listening_history_id_seq'::regclass);


--
-- Name: network_nodes id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.network_nodes ALTER COLUMN id SET DEFAULT nextval('public.network_nodes_id_seq'::regclass);


--
-- Name: playlist_queue id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.playlist_queue ALTER COLUMN id SET DEFAULT nextval('public.playlist_queue_id_seq'::regclass);


--
-- Name: playlist_tracks id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.playlist_tracks ALTER COLUMN id SET DEFAULT nextval('public.playlist_tracks_id_seq'::regclass);


--
-- Name: playlists id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.playlists ALTER COLUMN id SET DEFAULT nextval('public.playlists_id_seq'::regclass);


--
-- Name: search_history id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.search_history ALTER COLUMN id SET DEFAULT nextval('public.search_history_id_seq'::regclass);


--
-- Name: subscription_payments id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subscription_payments ALTER COLUMN id SET DEFAULT nextval('public.subscription_payments_id_seq'::regclass);


--
-- Name: tracks track_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tracks ALTER COLUMN track_id SET DEFAULT nextval('public.tracks_track_id_seq'::regclass);


--
-- Name: user_playlists id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_playlists ALTER COLUMN id SET DEFAULT nextval('public.user_playlists_id_seq'::regclass);


--
-- Name: cached_content cached_content_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cached_content
    ADD CONSTRAINT cached_content_pkey PRIMARY KEY (source_id);


--
-- Name: download_history download_history_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.download_history
    ADD CONSTRAINT download_history_pkey PRIMARY KEY (id);


--
-- Name: google_accounts google_accounts_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.google_accounts
    ADD CONSTRAINT google_accounts_email_key UNIQUE (email);


--
-- Name: google_accounts google_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.google_accounts
    ADD CONSTRAINT google_accounts_pkey PRIMARY KEY (id);


--
-- Name: listening_history listening_history_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.listening_history
    ADD CONSTRAINT listening_history_pkey PRIMARY KEY (id);


--
-- Name: network_nodes network_nodes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.network_nodes
    ADD CONSTRAINT network_nodes_pkey PRIMARY KEY (id);


--
-- Name: network_nodes network_nodes_worker_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.network_nodes
    ADD CONSTRAINT network_nodes_worker_id_key UNIQUE (worker_id);


--
-- Name: playlist_likes playlist_likes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.playlist_likes
    ADD CONSTRAINT playlist_likes_pkey PRIMARY KEY (user_id, playlist_id);


--
-- Name: playlist_queue playlist_queue_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.playlist_queue
    ADD CONSTRAINT playlist_queue_pkey PRIMARY KEY (id);


--
-- Name: playlist_queue playlist_queue_url_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.playlist_queue
    ADD CONSTRAINT playlist_queue_url_key UNIQUE (url);


--
-- Name: playlist_tracks playlist_tracks_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.playlist_tracks
    ADD CONSTRAINT playlist_tracks_pkey PRIMARY KEY (id);


--
-- Name: playlists playlists_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.playlists
    ADD CONSTRAINT playlists_pkey PRIMARY KEY (id);


--
-- Name: search_history search_history_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.search_history
    ADD CONSTRAINT search_history_pkey PRIMARY KEY (id);


--
-- Name: subscription_payments subscription_payments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subscription_payments
    ADD CONSTRAINT subscription_payments_pkey PRIMARY KEY (id);


--
-- Name: system_settings system_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_settings
    ADD CONSTRAINT system_settings_pkey PRIMARY KEY (key);


--
-- Name: tracks tracks_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tracks
    ADD CONSTRAINT tracks_pkey PRIMARY KEY (track_id);


--
-- Name: tracks tracks_source_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tracks
    ADD CONSTRAINT tracks_source_id_key UNIQUE (source_id);


--
-- Name: tracks tracks_source_id_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tracks
    ADD CONSTRAINT tracks_source_id_unique UNIQUE (source_id);


--
-- Name: user_playlists user_playlists_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_playlists
    ADD CONSTRAINT user_playlists_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (user_id);


--
-- Name: idx_accounts_usage; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_accounts_usage ON public.google_accounts USING btree (is_active, last_used_at);


--
-- Name: idx_cached_content_updated_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_cached_content_updated_at ON public.cached_content USING btree (updated_at);


--
-- Name: idx_download_track; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_download_track ON public.download_history USING btree (track_id);


--
-- Name: idx_download_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_download_user ON public.download_history USING btree (user_id);


--
-- Name: idx_google_accounts_rotation; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_google_accounts_rotation ON public.google_accounts USING btree (is_active, last_used_at);


--
-- Name: idx_history_user_recent; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_history_user_recent ON public.listening_history USING btree (user_id, listened_at DESC);


--
-- Name: idx_listening_history_user_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_listening_history_user_date ON public.listening_history USING btree (user_id, listened_at DESC);


--
-- Name: idx_payments_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_payments_user_id ON public.subscription_payments USING btree (user_id);


--
-- Name: idx_playlist_likes_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_playlist_likes_user ON public.playlist_likes USING btree (user_id);


--
-- Name: idx_playlist_queue_pending; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_playlist_queue_pending ON public.playlist_queue USING btree (is_downloaded) WHERE (is_downloaded = false);


--
-- Name: idx_playlists_public; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_playlists_public ON public.playlists USING btree (is_public, likes_count DESC);


--
-- Name: idx_search_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_search_user ON public.search_history USING btree (user_id);


--
-- Name: idx_tracks_artist_trgm; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tracks_artist_trgm ON public.tracks USING gin (artist public.gin_trgm_ops);


--
-- Name: idx_tracks_source_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tracks_source_id ON public.tracks USING btree (source_id);


--
-- Name: idx_tracks_source_id_hash; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tracks_source_id_hash ON public.tracks USING hash (source_id);


--
-- Name: idx_tracks_telegram_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tracks_telegram_id ON public.tracks USING btree (telegram_file_id) WHERE (telegram_file_id IS NOT NULL);


--
-- Name: idx_tracks_title_artist; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tracks_title_artist ON public.tracks USING btree (title, artist);


--
-- Name: idx_tracks_title_trgm; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tracks_title_trgm ON public.tracks USING gin (title public.gin_trgm_ops);


--
-- Name: idx_user_playlists_track_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_playlists_track_id ON public.user_playlists USING btree (track_id);


--
-- Name: idx_user_playlists_unique_track; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX idx_user_playlists_unique_track ON public.user_playlists USING btree (user_id, track_id);


--
-- Name: idx_user_playlists_user_added; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_playlists_user_added ON public.user_playlists USING btree (user_id, added_at DESC);


--
-- Name: idx_user_playlists_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_playlists_user_id ON public.user_playlists USING btree (user_id);


--
-- Name: idx_users_subscription; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_users_subscription ON public.users USING btree (subscription_tier, subscription_expires_at);


--
-- Name: ix_google_accounts_assigned_worker_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_google_accounts_assigned_worker_id ON public.google_accounts USING btree (assigned_worker_id);


--
-- Name: ix_listening_history_track_source_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_listening_history_track_source_id ON public.listening_history USING btree (track_source_id);


--
-- Name: ix_listening_history_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_listening_history_user_id ON public.listening_history USING btree (user_id);


--
-- Name: ix_playlist_tracks_playlist_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_playlist_tracks_playlist_id ON public.playlist_tracks USING btree (playlist_id);


--
-- Name: ix_playlist_tracks_track_source_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_playlist_tracks_track_source_id ON public.playlist_tracks USING btree (track_source_id);


--
-- Name: ix_playlists_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_playlists_user_id ON public.playlists USING btree (user_id);


--
-- Name: listening_history fk_history_user; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.listening_history
    ADD CONSTRAINT fk_history_user FOREIGN KEY (user_id) REFERENCES public.users(user_id) ON DELETE CASCADE;


--
-- Name: playlist_tracks fk_playlist; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.playlist_tracks
    ADD CONSTRAINT fk_playlist FOREIGN KEY (playlist_id) REFERENCES public.playlists(id) ON DELETE CASCADE;


--
-- Name: playlist_tracks fk_track; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.playlist_tracks
    ADD CONSTRAINT fk_track FOREIGN KEY (track_source_id) REFERENCES public.tracks(source_id) ON DELETE CASCADE;


--
-- Name: listening_history fk_track_history; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.listening_history
    ADD CONSTRAINT fk_track_history FOREIGN KEY (track_source_id) REFERENCES public.tracks(source_id) ON DELETE CASCADE;


--
-- Name: playlists fk_user; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.playlists
    ADD CONSTRAINT fk_user FOREIGN KEY (user_id) REFERENCES public.users(user_id) ON DELETE CASCADE;


--
-- Name: listening_history listening_history_track_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.listening_history
    ADD CONSTRAINT listening_history_track_id_fkey FOREIGN KEY (track_id) REFERENCES public.tracks(track_id) ON DELETE CASCADE;


--
-- Name: playlist_likes playlist_likes_playlist_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.playlist_likes
    ADD CONSTRAINT playlist_likes_playlist_id_fkey FOREIGN KEY (playlist_id) REFERENCES public.playlists(id) ON DELETE CASCADE;


--
-- Name: playlist_likes playlist_likes_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.playlist_likes
    ADD CONSTRAINT playlist_likes_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(user_id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict 8B8qeimStdpUo4TKh8V6JJLMg4fSYljeZTTJvTrOQhHIgwh4QJagrwEQ4IaI3jG

