/// <reference types="vitest/config" />
import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import path from 'path'

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [react()],
  test: {
    globals: true,
    environment: 'jsdom',
    setupFiles: ['./src/setupTests.js'],
    css: true,
    exclude: ['**/node_modules/**', '**/dist/**', '**/e2e/**'],
  },
  resolve: {
    alias: {
      '@': path.resolve(__dirname, './src'),
    },
  },
  server: {
    host: true,
    port: parseInt(process.env.VITE_PORT || '5173', 10),
    // When VITE_API_URL is empty, axios uses relative `/api/...`; proxy to local API.
    proxy: {
      '/api': {
        target: process.env.VITE_DEV_PROXY_TARGET || 'http://127.0.0.1:8005',
        // false: залишити Host від браузера (localhost:8080), інакше API з AUTH_DEBUG не впізнає «локальний» хост.
        changeOrigin: false,
      },
    },
  },
  // `npm run start` / vite preview on :8080 — same /api proxy (Docker: VITE_DEV_PROXY_TARGET=http://api:8000)
  preview: {
    host: '0.0.0.0',
    port: parseInt(process.env.VITE_PREVIEW_PORT || '8080', 10),
    // За reverse proxy (Caddy) Host = nikkme.online — дефолт Vite блокує «чужі» хости.
    allowedHosts: [
      'nikkme.online',
      'www.nikkme.online',
      'localhost',
      '.localhost',
      '127.0.0.1',
    ],
    proxy: {
      '/api': {
        target: process.env.VITE_DEV_PROXY_TARGET || 'http://127.0.0.1:8005',
        changeOrigin: false,
      },
    },
  },
})