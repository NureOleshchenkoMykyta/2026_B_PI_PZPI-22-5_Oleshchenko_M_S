import React, { useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Loader2, Play } from 'lucide-react';
import { useSearch } from '../../context/SearchContext';
import { useLanguage } from '../../context/LanguageContext';
import LikeButton from '../Shared/LikeButton'; 

const formatDuration = (seconds) => {
    if (isNaN(seconds) || seconds === null) return "--:--";
    const min = Math.floor(seconds / 60);
    const sec = Math.floor(seconds % 60);
    return `${min}:${sec < 10 ? '0' : ''}${sec}`;
};

const SearchResultItem = ({ track, onResultClick }) => {
    const navigate = useNavigate();
    return (
        <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="flex items-center p-3 rounded-xl my-2 transition hover:bg-white/10 cursor-pointer group"
            onClick={() => onResultClick(track)}
        >
            <div className="relative w-14 h-14 min-w-[3.5rem] rounded-lg overflow-hidden bg-gray-800 shadow-lg mr-4">
                <img src={track.cover} alt={track.title} loading="lazy" className="w-full h-full object-cover" />
                <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                    <Play size={24} className="text-white fill-white" />
                </div>
            </div>
            
            <div className="flex-1 min-w-0">
                <p className="font-semibold text-sm truncate text-white">{track.title}</p>
                <p
                    className="text-xs text-gray-400 truncate hover:text-purple-400"
                    onClick={(e) => { e.stopPropagation(); if (track.artist) navigate(`/artist/${encodeURIComponent(track.artist)}`); }}
                >
                    {track.artist}
                </p>
            </div>

            <div className="text-gray-500 text-xs font-medium pl-2">
                {formatDuration(track.duration)}
            </div>
        </motion.div>
    );
};

const SearchResults = ({ onResultClick }) => {
    const { 
        searchResults, searchQuery, isLoadingSearch, 
        hasSearched, loadMoreResults, isLoadingMore 
    } = useSearch(); 
    
    const { t } = useLanguage();
    const observerTarget = useRef(null);

    useEffect(() => {
        const el = observerTarget.current;
        const observer = new IntersectionObserver(
            (entries) => {
                if (entries[0].isIntersecting && !isLoadingMore && !isLoadingSearch) {
                    loadMoreResults();
                }
            },
            { threshold: 1.0 }
        );

        if (el) {
            observer.observe(el);
        }

        return () => {
            if (el) {
                observer.unobserve(el);
            }
        };
    }, [loadMoreResults, isLoadingMore, isLoadingSearch]);

    if (isLoadingSearch) {
        return (
            <div className="flex flex-col items-center justify-center py-20 text-gray-400">
                <Loader2 size={32} className="animate-spin mb-4 text-purple-500" />
                <p>{t('searching_for')} "{searchQuery}"...</p>
            </div>
        );
    }
    
    if (!hasSearched) {
         return (
            <div className="text-center text-gray-500 pt-10">
                ⌨️ {t('type_to_search')}
            </div>
        );
    }
    
    if (searchResults.length === 0) {
        return (
            <div className="text-center text-gray-400 pt-10">
                {t('nothing_found')}
            </div>
        );
    }
    
    return (
        <div className="pb-32"> 
            <h3 className="text-lg font-bold mb-4 px-1 text-white">{t('search_results_header')}</h3>
            
            {searchResults.map((track, index) => (
                <SearchResultItem 
                    key={`${track.id}-${index}`} 
                    track={track} 
                    onResultClick={onResultClick} 
                />
            ))}

            <div ref={observerTarget} className="h-10 flex justify-center items-center mt-4">
                {isLoadingMore && <Loader2 size={24} className="animate-spin text-purple-500" />}
            </div>
        </div>
    );
};

export default SearchResults;