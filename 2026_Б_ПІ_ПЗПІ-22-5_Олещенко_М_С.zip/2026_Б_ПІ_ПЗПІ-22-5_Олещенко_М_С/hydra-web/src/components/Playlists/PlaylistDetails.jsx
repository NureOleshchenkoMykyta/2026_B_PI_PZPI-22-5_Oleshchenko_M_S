import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
    ChevronLeft, MoreHorizontal, Play, Pause, Clock, Heart, 
    CheckCircle2, Circle, SlidersHorizontal, X, 
    ArrowUp, ArrowDown, Send, Check, AlertCircle, CheckSquare,
    Share2, Copy, Trash2, Edit3, Loader2, Shuffle
} from 'lucide-react';
import { useLanguage } from '../../context/LanguageContext';
import { apiClient } from '../../config';
import { fetchWithAsyncContract } from '../../utils/asyncApi';

// --- ДОПОМІЖНІ КОМПОНЕНТИ ---
const MenuRow = ({ icon: Icon, label, onClick, isSuccess, successLabel, className = "" }) => (
    <button onClick={onClick} className={`w-full flex items-center gap-4 p-4 hover:bg-white/5 transition active:bg-white/10 text-left ${className}`}>
        {isSuccess ? <Check size={20} className="text-green-500" /> : <Icon size={20} className="text-gray-400" />}
        <span className={`font-medium flex-1 ${isSuccess ? 'text-green-500' : 'text-white'}`}>
            {isSuccess ? successLabel : label}
        </span>
    </button>
);

const SortButton = ({ label, active, direction, onClick }) => (
    <button onClick={onClick} className={`flex items-center justify-center gap-1.5 py-3 rounded-xl text-xs sm:text-sm font-medium transition active:scale-95 ${active ? 'bg-white text-black' : 'bg-white/5 text-gray-400 hover:bg-white/10'}`}>
        {label}
        {active && (direction === 'asc' ? <ArrowUp size={14} strokeWidth={3}/> : <ArrowDown size={14} strokeWidth={3}/>)}
    </button>
);

export default function PlaylistDetails({ playlist, onBack, onPlayTrack }) {
  const { t } = useLanguage();
  const scrollRef = useRef(null);
  
  // Data State
  const [details, setDetails] = useState(playlist);
  const [tracks, setTracks] = useState([]);
  const [loading, setLoading] = useState(true);

  // UI State
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isSelectionMode, setIsSelectionMode] = useState(false);
  const [selectedTrackIds, setSelectedTrackIds] = useState(new Set());
  const [headerOpacity, setHeaderOpacity] = useState(0); // Прозорість хедера
  
  // Actions State
  const [isCopied, setIsCopied] = useState(false);
  const [isConfirmingSend, setIsConfirmingSend] = useState(false);
  const [isSent, setIsSent] = useState(false);
  const [isConfirmingDelete, setIsConfirmingDelete] = useState(false);

  // Sorting
  const [sortOrder, setSortOrder] = useState('date'); 
  const [sortDirection, setSortDirection] = useState('desc');

  // Ефект скролу для красивого хедера
  const handleScroll = (e) => {
    const scrollTop = e.target.scrollTop;
    // Чим нижче скролимо, тим темнішим стає хедер
    const opacity = Math.min(scrollTop / 250, 1); 
    setHeaderOpacity(opacity);
  };

  // --- ЗАВАНТАЖЕННЯ ДАНИХ ---
  useEffect(() => {
    const loadContent = async () => {
        setLoading(true);
        try {
            if (playlist.items && playlist.items.length > 0 && !playlist.id?.startsWith('MP') && !playlist.id?.startsWith('PL') && !playlist.id?.startsWith('VL')) {
                setTracks(playlist.items);
                setLoading(false);
                return;
            }

            let endpoint = '';
            if (playlist.type === 'album' || (typeof playlist.id === 'string' && playlist.id.startsWith('MP'))) {
                 endpoint = `/api/album/${playlist.id}`;
            } else if (playlist.type === 'playlist' && (playlist.id?.startsWith('PL') || playlist.id?.startsWith('VL'))) {
                 endpoint = `/api/playlist_info/${playlist.id}`;
            } else {
                 endpoint = `/api/library/playlists/${playlist.id}/tracks`;
            }

            const isAsyncEndpoint =
              endpoint.startsWith('/api/album/') || endpoint.startsWith('/api/playlist_info/');
            const data = isAsyncEndpoint
              ? await fetchWithAsyncContract(endpoint)
              : (await apiClient.get(endpoint)).data;

            if (data) {
                if (data.items) {
                    setTracks(data.items);
                    setDetails(prev => ({
                        ...prev,
                        title: data.title || prev.title,
                        cover: data.cover || prev.cover,
                        description: data.description || prev.description,
                        artist: data.artist || prev.artist
                    }));
                } 
                else if (Array.isArray(data)) {
                    setTracks(data);
                }
            }
        } catch (e) {
            console.error("Load failed", e);
        } finally {
            setLoading(false);
        }
    };

    loadContent();
  }, [playlist]);

  // --- ЛОГІКА СОРТУВАННЯ ---
  const handleSortClick = (type) => {
      if (sortOrder === type) {
          setSortDirection(prev => prev === 'asc' ? 'desc' : 'asc');
      } else {
          setSortOrder(type);
          setSortDirection(type === 'date' ? 'desc' : 'asc');
      }
  };

  const getDisplayedTracks = () => {
      let sorted = [...tracks];
      if (sortOrder === 'title') {
          sorted.sort((a, b) => a.title.localeCompare(b.title));
      } else if (sortOrder === 'artist') {
          sorted.sort((a, b) => (a.artist || "").localeCompare(b.artist || ""));
      }
      
      if (sortDirection === 'desc' && sortOrder !== 'date') sorted.reverse();
      if (sortDirection === 'asc' && sortOrder === 'date') sorted.reverse();
      return sorted;
  };

  const displayedTracks = getDisplayedTracks();

  // --- ЛОГІКА ВИБОРУ ---
  const toggleSelectionMode = () => {
      setIsSelectionMode(!isSelectionMode);
      setSelectedTrackIds(new Set());
      setIsSettingsOpen(false);
  };

  const toggleTrackSelection = (trackId) => {
      const newSelected = new Set(selectedTrackIds);
      if (newSelected.has(trackId)) newSelected.delete(trackId);
      else newSelected.add(trackId);
      setSelectedTrackIds(newSelected);
  };

  const handleTrackClick = (track, idx) => {
      if (isSelectionMode) {
          toggleTrackSelection(track.id || track.source_id);
      } else {
          onPlayTrack(track, displayedTracks, idx);
      }
  };

  const handlePlayAll = () => {
      if (displayedTracks.length > 0) {
          onPlayTrack(displayedTracks[0], displayedTracks, 0);
      }
  };

  const handleShuffle = () => {
      if (displayedTracks.length > 0) {
          // Створюємо копію та перемішуємо
          const shuffled = [...displayedTracks].sort(() => Math.random() - 0.5);
          onPlayTrack(shuffled[0], shuffled, 0);
      }
  };

  // --- ДІЇ ---
  const handleShare = () => {
      const url = `${window.location.origin}/playlist/${details.id}`; 
      navigator.clipboard.writeText(url).then(() => {
          setIsCopied(true);
          setTimeout(() => setIsCopied(false), 2000);
      });
  };

  const handleSendClick = async () => {
      if (isSent) return;
      if (!isConfirmingSend) {
          setIsConfirmingSend(true);
          setTimeout(() => setIsConfirmingSend(false), 3000);
          return;
      }
      
      try {
          await apiClient.post(`/api/library/playlists/${details.id}/send-to-chat`);
          setIsSent(true);
          setTimeout(() => { setIsSettingsOpen(false); setIsSent(false); }, 1500);
      } catch (e) {
          console.error("Send failed", e);
          setIsConfirmingSend(false);
      }
  };

  const handleDeleteSelected = async () => {
      if (!details.is_owner) return;
      if (!isConfirmingDelete) {
          setIsConfirmingDelete(true);
          setTimeout(() => setIsConfirmingDelete(false), 3000);
          return;
      }
      try {
          await apiClient.post(`/api/library/playlists/${details.id}/remove-tracks`, {
              track_ids: Array.from(selectedTrackIds)
          });
          setTracks(prev => prev.filter(t => !selectedTrackIds.has(t.id || t.source_id)));
          setIsSelectionMode(false);
          setIsConfirmingDelete(false);
      } catch (e) {
          console.error(e);
      }
  };

  return (
    <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="w-full h-full bg-[#09090b] relative flex flex-col font-sans overflow-hidden"
    >
      {/* --- STICKY HEADER --- */}
      <div 
        className="absolute top-0 left-0 right-0 h-20 z-30 flex items-center justify-between px-6 transition-all duration-300"
        style={{ 
            backgroundColor: `rgba(9, 9, 11, ${headerOpacity})`, 
            backdropFilter: headerOpacity > 0.8 ? 'blur(20px)' : 'none',
            borderBottom: headerOpacity > 0.9 ? '1px solid rgba(255,255,255,0.05)' : 'none'
        }}
      >
          <button 
            onClick={() => isSelectionMode ? toggleSelectionMode() : onBack()} 
            className="p-2 -ml-2 rounded-full hover:bg-white/10 transition text-white"
          >
              {isSelectionMode ? <X size={24} /> : <ChevronLeft size={28} />}
          </button>
          
          {/* Назва в хедері (з'являється при скролі) */}
          <span 
            className="text-lg font-bold text-white truncate transition-opacity duration-300 absolute left-1/2 -translate-x-1/2 pointer-events-none"
            style={{ opacity: headerOpacity > 0.6 ? 1 : 0 }}
          >
              {isSelectionMode ? `${t('selected')}: ${selectedTrackIds.size}` : details.title}
          </span>

          {!isSelectionMode ? (
              <button onClick={() => setIsSettingsOpen(true)} className={`p-2 -mr-2 rounded-full hover:bg-white/10 transition ${isSettingsOpen ? 'text-purple-500' : 'text-white'}`}>
                  <SlidersHorizontal size={22} />
              </button>
          ) : (
              <div className="w-10"></div> 
          )}
      </div>

      {/* --- SCROLLABLE CONTENT --- */}
      <div 
        className="w-full h-full overflow-y-auto custom-scrollbar"
        onScroll={handleScroll}
        ref={scrollRef}
      >
        {/* HERO SECTION (Обкладинка) */}
        <div className="relative w-full flex flex-col items-center pt-24 pb-8 px-6">
            {/* Фонове розмиття (Ambilight) */}
            <div className="absolute inset-0 z-0 overflow-hidden pointer-events-none">
                <div 
                    className="absolute top-0 left-0 right-0 h-[500px] bg-cover bg-center blur-3xl opacity-30 scale-125"
                    style={{ backgroundImage: `url(${details.cover})` }}
                />
                <div className="absolute inset-0 bg-gradient-to-b from-transparent via-[#09090b]/80 to-[#09090b]" />
            </div>

            {/* Контент Hero */}
            <div className="relative z-10 flex flex-col items-center text-center">
                <motion.div 
                    initial={{ scale: 0.9, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    className="w-48 h-48 sm:w-64 sm:h-64 shadow-[0_20px_60px_-15px_rgba(0,0,0,0.7)] rounded-xl overflow-hidden mb-6 ring-1 ring-white/10"
                >
                    <img src={details.cover} alt={details.title} className="w-full h-full object-cover" />
                </motion.div>

                <h1 className="text-2xl sm:text-4xl font-extrabold text-white mb-2 leading-tight max-w-2xl drop-shadow-lg">
                    {details.title}
                </h1>
                
                <div className="flex flex-wrap items-center justify-center gap-2 text-sm sm:text-base text-gray-300 font-medium opacity-90">
                    {details.type === 'album' && <span className="uppercase tracking-widest text-xs font-bold text-purple-400">Album</span>}
                    {details.type === 'album' && <span>•</span>}
                    {details.artist && <span>{details.artist}</span>}
                    {details.artist && <span>•</span>}
                    <span>{loading ? "..." : tracks.length} {t('tracks_suffix')}</span>
                </div>

                {/* Кнопки Play / Shuffle */}
                <div className="flex items-center gap-4 mt-6">
                    <button 
                        onClick={handlePlayAll}
                        disabled={loading || tracks.length === 0}
                        className="flex items-center gap-2 px-8 py-3 bg-white text-black rounded-full font-bold hover:scale-105 active:scale-95 transition shadow-xl disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                        <Play size={20} fill="black" />
                        <span>{t('play_all')}</span>
                    </button>
                    
                    <button 
                        onClick={handleShuffle}
                        disabled={loading || tracks.length === 0}
                        className="p-3 bg-white/10 text-white rounded-full hover:bg-white/20 transition active:scale-95 border border-white/10"
                    >
                        <Shuffle size={20} />
                    </button>
                </div>
            </div>
        </div>

        {/* TRACK LIST */}
        <div className="relative z-10 px-2 sm:px-6 pb-0 min-h-[300px]">
            {loading ? (
                <div className="flex justify-center py-20">
                    <Loader2 className="animate-spin text-purple-500" size={32} />
                </div>
            ) : (
                <div className="flex flex-col gap-1">
                    {displayedTracks.map((track, index) => {
                        const isSelected = selectedTrackIds.has(track.id || track.source_id);
                        return (
                            <div 
                                key={track.id || index} 
                                onClick={() => handleTrackClick(track, index)} 
                                className={`group flex items-center gap-4 p-3 rounded-xl transition cursor-pointer active:scale-[0.99] border border-transparent ${isSelected ? 'bg-white/10 border-purple-500/30' : 'hover:bg-white/5 hover:border-white/5'}`}
                            >
                                {/* Selection Checkbox */}
                                {isSelectionMode && (
                                    <div className={`transition-colors flex-shrink-0 ${isSelected ? 'text-purple-500' : 'text-gray-600'}`}>
                                        {isSelected ? <CheckCircle2 size={24} fill="currentColor" className="text-purple-500" stroke="black" /> : <Circle size={24} />}
                                    </div>
                                )}
                                
                                {/* Обкладинка треку */}
                                <div className="relative w-12 h-12 flex-shrink-0 rounded-md overflow-hidden bg-[#222]">
                                    <img 
                                        src={track.cover || details.cover || "https://picsum.photos/200"} 
                                        alt="" 
                                        className="w-full h-full object-cover" 
                                    />
                                    {/* Overlay Play Icon */}
                                    <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                                        <Play size={20} fill="white" className="text-white" />
                                    </div>
                                </div>

                                {/* Info */}
                                <div className="flex-1 min-w-0 flex flex-col justify-center">
                                    <span className={`font-semibold text-[15px] truncate leading-tight ${isSelected ? 'text-purple-300' : 'text-white group-hover:text-purple-300 transition-colors'}`}>
                                        {track.title}
                                    </span>
                                    <div className="flex items-center gap-2 mt-0.5">
                                        {/* E (Explicit) значок, якщо є (поки просто заглушка, якщо буде в API) */}
                                        {/* <span className="bg-white/10 px-1 rounded-[3px] text-[8px] text-gray-400 font-bold">E</span> */}
                                        <span className="text-sm text-gray-400 truncate">
                                            {track.artist}
                                        </span>
                                    </div>
                                </div>
                                
                                {/* Duration */}
                                <div className="text-sm text-gray-500 font-mono font-medium">
                                    {track.duration ? `${Math.floor(track.duration / 60)}:${String(track.duration % 60).padStart(2, '0')}` : '--:--'}
                                </div>

                                {/* Actions (Like/More) - з'являються при наведенні */}
                                {!isSelectionMode && (
                                    <button className="p-2 text-gray-400 hover:text-white opacity-0 group-hover:opacity-100 transition-opacity hidden sm:block">
                                        <MoreHorizontal size={20} />
                                    </button>
                                )}
                            </div>
                        );
                    })}
                </div>
            )}
            
            {!loading && tracks.length === 0 && (
                <div className="text-center py-20 text-gray-500">
                    {t('no_tracks_in_playlist')}
                </div>
            )}
        </div>
      </div>

      {/* --- FLOATING DELETE BUTTON --- */}
      <AnimatePresence>
          {isSelectionMode && selectedTrackIds.size > 0 && details.is_owner && (
              <motion.div initial={{ y: 100, opacity: 0 }} animate={{ y: 0, opacity: 1 }} exit={{ y: 100, opacity: 0 }} className="fixed bottom-32 left-0 right-0 flex justify-center z-[60] px-6 pointer-events-none">
                  <button onClick={handleDeleteSelected} className={`pointer-events-auto w-full max-w-sm font-bold py-4 rounded-2xl shadow-2xl flex items-center justify-center gap-2 active:scale-95 transition border backdrop-blur-md ${isConfirmingDelete ? 'bg-orange-600 border-orange-400/30 text-white' : 'bg-red-600 border-red-400/30 text-white'}`}>
                      {isConfirmingDelete ? <><AlertCircle size={20} /> {t('confirm_action')}</> : <><Trash2 size={20} /> {t('remove_tracks')} ({selectedTrackIds.size})</>}
                  </button>
              </motion.div>
          )}
      </AnimatePresence>

      {/* --- SETTINGS SHEET --- */}
      <AnimatePresence>
         {isSettingsOpen && (
            <>
                <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={() => setIsSettingsOpen(false)} className="fixed inset-0 bg-black/60 z-[60] backdrop-blur-sm" />
                <motion.div initial={{ y: "100%" }} animate={{ y: 0 }} exit={{ y: "100%" }} transition={{ type: "spring", damping: 25, stiffness: 200 }} className="fixed bottom-0 left-0 right-0 z-[70] bg-[#121214] rounded-t-[2.5rem] border-t border-white/10 shadow-2xl pb-36 overflow-hidden">
                    <div className="w-full flex justify-center pt-4 pb-2" onClick={() => setIsSettingsOpen(false)}><div className="w-12 h-1.5 bg-gray-600 rounded-full" /></div>
                    
                    <div className="px-6 pt-4 overflow-y-auto max-h-[70vh]">
                        <div className="flex items-center justify-between mb-6">
                            <h3 className="text-xl font-bold text-white">{t('manage')}</h3>
                            <button onClick={() => setIsSettingsOpen(false)} className="p-2 bg-white/5 rounded-full text-white hover:bg-white/10"><X size={20}/></button>
                        </div>

                        {details.is_owner && (
                            <div className="mb-6 bg-white/5 rounded-2xl overflow-hidden">
                                <MenuRow icon={CheckSquare} label={t('remove_tracks')} onClick={toggleSelectionMode} />
                            </div>
                        )}

                        <div className="mb-6 bg-white/5 rounded-2xl overflow-hidden">
                            <MenuRow icon={Share2} label={t('share_link')} onClick={handleShare} isSuccess={isCopied} successLabel={t('copied')} />
                        </div>
                        
                        <div className="mb-6">
                            <label className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-3 block ml-1">{t('sort_label')}</label>
                            <div className="grid grid-cols-3 gap-2">
                                <SortButton label={t('sort_date')} active={sortOrder === 'date'} direction={sortDirection} onClick={() => handleSortClick('date')} />
                                <SortButton label={t('sort_title')} active={sortOrder === 'title'} direction={sortDirection} onClick={() => handleSortClick('title')} />
                                <SortButton label={t('sort_artist')} active={sortOrder === 'artist'} direction={sortDirection} onClick={() => handleSortClick('artist')} />
                            </div>
                        </div>

                        {details.is_owner && (
                            <div className="mb-8">
                                <button onClick={handleSendClick} disabled={isSent} className={`w-full flex items-center justify-center gap-2 py-4 rounded-xl text-sm font-bold transition-all duration-300 active:scale-98 shadow-lg ${isSent ? 'bg-green-600 text-white' : isConfirmingSend ? 'bg-orange-600 hover:bg-orange-500 text-white' : 'bg-purple-600 hover:bg-purple-500 text-white'}`}>
                                    {isSent ? <><Check size={18} /> {t('sent')}</> : isConfirmingSend ? <><AlertCircle size={18} /> {t('confirm_action')}</> : <><Send size={18} /> {t('send_to_telegram')}</>}
                                </button>
                                <p className="text-xs text-gray-500 text-center mt-3">{t('music_bot_hint')}</p>
                            </div>
                        )}
                    </div>
                </motion.div>
            </>
         )}
      </AnimatePresence>
    </motion.div>
  );
}