import { Search, X, Clock } from 'lucide-react';
import { useSearch } from '../../context/SearchContext';
import { useLanguage } from '../../context/LanguageContext';
import { useState, useRef, useEffect, useMemo } from 'react';
import jsonp from 'jsonp';

export default function TopBar() {
  const {
    isSearchOpen,
    searchQuery,
    setSearchQuery,
    closeSearch,
    runSearch,
    searchHistory,
    removeFromHistory,
  } = useSearch();

  const { t } = useLanguage();

  const [remoteSuggestions, setRemoteSuggestions] = useState([]);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const inputRef = useRef(null);
  const containerRef = useRef(null);

  const trimmedQuery = (searchQuery ?? '').trim();
  const isEmptyQuery = trimmedQuery.length < 1;

  const historySuggestions = useMemo(
    () => searchHistory.map((item) => ({ type: 'history', text: item })),
    [searchHistory]
  );

  const suggestions = isEmptyQuery ? historySuggestions : remoteSuggestions;

  const performSearch = (query) => {
    if (!query || query.trim().length < 1) return;

    setSearchQuery(query);
    setShowSuggestions(false);
    if (inputRef.current) inputRef.current.blur();

    runSearch(query);
  };

  useEffect(() => {
    if (isEmptyQuery) return;

    const timeoutId = setTimeout(() => {
      const url = `https://clients1.google.com/complete/search?client=youtube&gs_ri=youtube&ds=yt&q=${encodeURIComponent(trimmedQuery)}`;

      jsonp(url, { param: 'jsonp' }, (err, data) => {
        if (!err && data && data[1]) {
          const googleMatches = data[1]
            .slice(0, 5)
            .map((item) => ({ type: 'google', text: item[0] }));
          setRemoteSuggestions(googleMatches);
        }
      });
    }, 300);

    return () => clearTimeout(timeoutId);
  }, [trimmedQuery, isEmptyQuery]);

  const handleKeyDown = (e) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      performSearch(searchQuery);
    }
  };

  useEffect(() => {
    if (isSearchOpen) {
      setTimeout(() => inputRef.current?.focus(), 100);
    }
  }, [isSearchOpen]);

  if (!isSearchOpen) return null;

  return (
    <div className="px-6 pt-8 pb-4 sticky top-0 z-50 bg-[#09090b]">
      <div ref={containerRef} className="relative w-full animate-fade-in">
        <div className="flex items-center gap-3 relative z-50">
          <div className="flex-1 relative group">
            <Search size={18} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-400" />
            <input
              ref={inputRef}
              autoFocus
              type="text"
              placeholder={t('search_placeholder')}
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onFocus={() => setShowSuggestions(true)}
              onKeyDown={handleKeyDown}
              className="w-full bg-[#1A1A1A] border border-white/10 rounded-full py-3 pl-10 pr-10 text-sm text-white focus:outline-none focus:border-purple-500 transition shadow-xl"
            />
            {searchQuery && (
              <button
                type="button"
                onClick={() => {
                  setSearchQuery('');
                  inputRef.current?.focus();
                }}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-white p-1"
              >
                <X size={14} />
              </button>
            )}
          </div>
          <button type="button" onClick={closeSearch} className="text-sm font-medium text-gray-400 hover:text-white transition px-2">
            {t('cancel') || 'Cancel'}
          </button>
        </div>

        {showSuggestions && suggestions.length > 0 && (
          <div className="absolute top-full left-0 right-0 mt-2 bg-[#1A1A1A] border border-white/10 rounded-2xl shadow-2xl overflow-hidden z-40 max-h-[60vh] overflow-y-auto">
            <ul>
              {suggestions.map((item, index) => (
                <li
                  key={`${item.type}-${item.text}-${index}`}
                  className="flex items-center gap-3 py-3 px-4 hover:bg-white/5 cursor-pointer border-b border-white/5 last:border-0"
                  onMouseDown={(e) => {
                    e.preventDefault();
                    performSearch(item.text);
                  }}
                >
                  {item.type === 'history' && <Clock size={16} className="text-gray-500" />}
                  {item.type === 'google' && <Search size={16} className="text-gray-400" />}
                  <span className="text-gray-200 text-sm flex-1 truncate">{item.text}</span>
                  {item.type === 'history' && (
                    <button
                      type="button"
                      onMouseDown={(e) => {
                        e.stopPropagation();
                        removeFromHistory(item.text);
                      }}
                      className="p-2 text-gray-600 hover:text-red-400"
                    >
                      <X size={14} />
                    </button>
                  )}
                </li>
              ))}
            </ul>
          </div>
        )}
      </div>
    </div>
  );
}
