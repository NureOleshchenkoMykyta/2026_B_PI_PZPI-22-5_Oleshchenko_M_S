import React, { useState, useEffect } from 'react';
import { createPortal } from 'react-dom';
import { ChevronLeft, Globe, BellOff, MessageCircle, ExternalLink, ChevronRight, Volume2, Check, X, Loader2, Crown } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

import { useLanguage, AVAILABLE_LANGUAGES } from '../../context/LanguageContext';
import { apiClient } from '../../config';

export default function SettingsPage({ onBack }) {
  const [silentMode, setSilentMode] = useState(false);
  const [isLangModalOpen, setIsLangModalOpen] = useState(false);
  const [isLoadingSettings, setIsLoadingSettings] = useState(true);
  const [subscriptionTier, setSubscriptionTier] = useState('free');
  const [plans, setPlans] = useState([]);
  const [subscribing, setSubscribing] = useState(null);
  
  const { t, language, changeLanguage } = useLanguage();

  const selectedLanguage = AVAILABLE_LANGUAGES.find(l => l.code === language) || AVAILABLE_LANGUAGES[0];

  // 1. Завантажуємо налаштування при старті
  useEffect(() => {
      const loadSettings = async () => {
          try {
              const res = await apiClient.get('/api/user/me');
              if (res.data) {
                  setSilentMode(!!res.data.silent_mode);
                  setSubscriptionTier(res.data.tier?.value || res.data.tier || 'free');
              }
              const plansRes = await apiClient.get('/api/subscription/plans');
              setPlans(plansRes.data?.plans || []);
          } catch (e) {
              console.error("Failed to load settings:", e);
          } finally {
              setIsLoadingSettings(false);
          }
      };
      loadSettings();
  }, []);

  // 2. Обробка перемикання "Тихого режиму"
  const toggleSilentMode = async () => {
      const newState = !silentMode;
      setSilentMode(newState); // Оптимістичне оновлення інтерфейсу

      try {
          // Відправляємо запит на новий ендпоінт PATCH
          await apiClient.patch('/api/user/settings', { silent_mode: newState });
          console.log("Silent mode updated:", newState);
      } catch (e) {
          console.error("Failed to update silent mode:", e);
          setSilentMode(!newState);
      }
  };

  const handleSubscribe = async (planId) => {
      if (planId === 'free') return;
      setSubscribing(planId);
      try {
          await apiClient.post('/api/subscription/checkout', { plan: planId });
          await apiClient.post('/api/subscription/confirm', {
              plan: planId,
              provider: 'telegram_stars',
              transaction_id: `demo_${Date.now()}`,
          });
          setSubscriptionTier(planId);
      } catch (e) {
          console.error('Subscribe failed:', e);
      } finally {
          setSubscribing(null);
      }
  };

  const handleLanguageSelect = (langCode) => {
      changeLanguage(langCode);
      setIsLangModalOpen(false);
  };

  return (
    <div className="fixed inset-0 z-50 bg-[#09090b] flex flex-col animate-slide-in font-sans">
      
      {/* HEADER */}
      <div className="px-6 pt-8 pb-4 bg-[#09090b]/95 backdrop-blur-md border-b border-white/5 flex items-center gap-4 sticky top-0 z-10">
        <button 
          onClick={onBack} 
          className="p-2 -ml-2 rounded-full hover:bg-white/10 transition text-white active:scale-95"
        >
          <ChevronLeft size={28} />
        </button>
        <h2 className="text-xl font-bold text-white tracking-tight">{t('settings_title')}</h2>
      </div>

      {/* CONTENT */}
      <div className="flex-1 overflow-y-auto custom-scrollbar p-6 space-y-8 pb-48">
        
        {isLoadingSettings ? (
            <div className="flex justify-center py-10"><Loader2 className="animate-spin text-gray-500"/></div>
        ) : (
            <>
                {/* 1. МОВА */}
                <section>
                    <h3 className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-3 ml-2">{t('section_general')}</h3>
                    <div className="bg-[#18181b] rounded-2xl overflow-hidden border border-white/5">
                        
                        <button 
                            onClick={() => setIsLangModalOpen(true)}
                            className="w-full flex items-center justify-between p-4 active:bg-white/5 transition group"
                        >
                            <div className="flex items-center gap-3">
                                <div className="w-8 h-8 rounded-full bg-blue-500/10 flex items-center justify-center text-blue-400">
                                    <Globe size={18} />
                                </div>
                                <span className="text-white font-medium text-sm">{t('lang_label')}</span>
                            </div>
                            <div className="flex items-center gap-2 text-gray-500 group-hover:text-white transition">
                                <span className="text-sm">{selectedLanguage.label}</span>
                                <ChevronRight size={16} />
                            </div>
                        </button>

                    </div>
                </section>

                {/* 2. TELEGRAM */}
                <section>
                    <h3 className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-3 ml-2">{t('section_tg')}</h3>
                    <div className="bg-[#18181b] rounded-2xl overflow-hidden border border-white/5">
                        
                        <div className="w-full flex items-center justify-between p-4 border-b border-white/5 last:border-0">
                            <div className="flex items-center gap-3">
                                <div className={`w-8 h-8 rounded-full flex items-center justify-center transition-colors ${silentMode ? 'bg-green-500/10 text-green-400' : 'bg-gray-800 text-gray-400'}`}>
                                    {silentMode ? <BellOff size={18} /> : <Volume2 size={18} />}
                                </div>
                                <div className="text-left">
                                    <span className="text-white font-medium text-sm block">{t('silent_mode')}</span>
                                    <span className="text-[10px] text-gray-500">{t('silent_desc')}</span>
                                </div>
                            </div>
                            
                            <button 
                                onClick={toggleSilentMode}
                                className={`w-11 h-6 rounded-full relative transition-colors duration-300 ease-in-out focus:outline-none ${silentMode ? 'bg-purple-600' : 'bg-gray-600'}`}
                            >
                                <div className={`absolute top-1 w-4 h-4 bg-white rounded-full shadow-sm transition-transform duration-300 ${silentMode ? 'translate-x-6' : 'translate-x-1'}`} />
                            </button>
                        </div>

                    </div>
                </section>

                {/* SUBSCRIPTION */}
                <section>
                    <h3 className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-3 ml-2">{t('section_subscription')}</h3>
                    <div className="space-y-3">
                        {plans.filter((p) => p.id !== 'free').map((plan) => (
                            <div key={plan.id} className={`bg-[#18181b] rounded-2xl p-4 border ${subscriptionTier === plan.id ? 'border-purple-500' : 'border-white/5'}`}>
                                <div className="flex items-center justify-between mb-2">
                                    <div className="flex items-center gap-2">
                                        <Crown size={18} className="text-yellow-400" />
                                        <span className="text-white font-bold">{plan.name}</span>
                                    </div>
                                    <span className="text-purple-400 font-bold">{plan.price} {plan.currency}</span>
                                </div>
                                <ul className="text-xs text-gray-400 mb-3 space-y-1">
                                    {(plan.features || []).map((f) => (
                                        <li key={f}>• {f}</li>
                                    ))}
                                </ul>
                                <button
                                    onClick={() => handleSubscribe(plan.id)}
                                    disabled={subscriptionTier === plan.id || subscribing === plan.id}
                                    className="w-full py-2 bg-purple-600 text-white rounded-xl text-sm font-bold disabled:opacity-50"
                                >
                                    {subscriptionTier === plan.id ? t('current_plan') : subscribing === plan.id ? t('loading') : t('subscribe')}
                                </button>
                            </div>
                        ))}
                    </div>
                </section>

                {/* 3. ПІДТРИМКА */}
                <section>
                    <h3 className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-3 ml-2">{t('section_info')}</h3>
                    <div className="bg-[#18181b] rounded-2xl overflow-hidden border border-white/5">
                        
                        <a 
                            href="https://t.me/hydra_support" 
                            target="_blank" 
                            rel="noopener noreferrer" 
                            className="w-full flex items-center justify-between p-4 active:bg-white/5 transition"
                        >
                            <div className="flex items-center gap-3">
                                <div className="w-8 h-8 rounded-full bg-pink-500/10 flex items-center justify-center text-pink-400">
                                    <MessageCircle size={18} />
                                </div>
                                <span className="text-white font-medium text-sm">{t('support_chat')}</span>
                            </div>
                            <ExternalLink size={16} className="text-gray-500" />
                        </a>

                    </div>
                </section>

                <div className="mt-8 text-center pb-8">
                    <p className="text-xs text-gray-700 font-mono">Hydra Music v1.0.5 Beta</p>
                </div>
            </>
        )}

      </div>

      {/* МЕНЮ МОВИ (Без змін) */}
      {createPortal(
        <AnimatePresence>
            {isLangModalOpen && (
                <>
                    <motion.div 
                        initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} 
                        onClick={() => setIsLangModalOpen(false)} 
                        className="fixed inset-0 bg-black/60 z-[9998] backdrop-blur-sm" 
                    />
                    
                    <motion.div 
                        initial={{ y: "100%" }} animate={{ y: 0 }} exit={{ y: "100%" }} 
                        transition={{ type: "spring", damping: 25, stiffness: 200 }}
                        className="fixed bottom-0 left-0 right-0 z-[9999] bg-[#121214] rounded-t-[2rem] border-t border-white/10 shadow-2xl overflow-hidden pb-safe"
                    >
                        <div className="w-full flex justify-center pt-4 pb-2" onClick={() => setIsLangModalOpen(false)}>
                            <div className="w-12 h-1.5 bg-gray-600 rounded-full" />
                        </div>
                        
                        <div className="px-6 py-4 pb-12">
                            <div className="flex items-center justify-between mb-6">
                                <h3 className="text-xl font-bold text-white">Select Language</h3>
                                <button onClick={() => setIsLangModalOpen(false)} className="p-2 bg-white/5 rounded-full text-white hover:bg-white/10">
                                    <X size={20}/>
                                </button>
                            </div>

                            <div className="space-y-2 max-h-[60vh] overflow-y-auto">
                                {AVAILABLE_LANGUAGES.map((lang) => (
                                    <button
                                        key={lang.code}
                                        onClick={() => handleLanguageSelect(lang.code)}
                                        className={`w-full flex items-center justify-between p-4 rounded-xl transition ${
                                            language === lang.code 
                                            ? 'bg-purple-600 text-white' 
                                            : 'bg-white/5 text-gray-300 hover:bg-white/10'
                                        }`}
                                    >
                                        <div className="flex items-center gap-3">
                                            <span className="text-2xl">{lang.flag}</span>
                                            <span className="font-medium text-base">{lang.label}</span>
                                        </div>
                                        {language === lang.code && <Check size={20} />}
                                    </button>
                                ))}
                            </div>
                        </div>
                    </motion.div>
                </>
            )}
        </AnimatePresence>,
        document.body
      )}

    </div>
  );
}