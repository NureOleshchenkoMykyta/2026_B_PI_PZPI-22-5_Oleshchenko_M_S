import { Play, Pause, SkipBack, SkipForward, Shuffle, Repeat, Repeat1, Blend } from 'lucide-react';
import { useLanguage } from '../../context/LanguageContext';

export default function Controls({
    isPlaying,
    onPlayPause,
    onNext,
    onPrev,
    isShuffle,
    repeatMode,
    onToggleShuffle,
    onToggleRepeat,
    isCrossfade,
    onToggleCrossfade,
}) {
  const { t } = useLanguage();

  return (
    <div className="flex flex-col items-center gap-3 mb-4">
      <div className="flex items-center justify-between w-full max-w-[280px]">
        <button
          type="button"
          onClick={onToggleShuffle}
          aria-label={t('shuffle')}
          className={`p-2 transition active:scale-90 ${isShuffle ? 'text-purple-500' : 'text-gray-400 hover:text-white'}`}
        >
          <Shuffle size={22} />
        </button>

        <button type="button" onClick={onPrev} className="p-3 hover:bg-white/10 rounded-full transition active:scale-95">
          <SkipBack size={32} fill="currentColor" />
        </button>

        <button
          type="button"
          onClick={onPlayPause}
          className="w-[4.5rem] h-[4.5rem] bg-white text-black rounded-full flex items-center justify-center hover:scale-105 active:scale-95 transition-all shadow-[0_0_40px_rgba(255,255,255,0.25)]"
        >
          {isPlaying ? (
            <Pause size={32} fill="currentColor" />
          ) : (
            <Play size={32} fill="currentColor" className="ml-1" />
          )}
        </button>

        <button type="button" onClick={onNext} className="p-3 hover:bg-white/10 rounded-full transition active:scale-95">
          <SkipForward size={32} fill="currentColor" />
        </button>

        <button
          type="button"
          onClick={onToggleRepeat}
          aria-label={t('repeat')}
          className={`p-2 transition active:scale-90 relative ${repeatMode !== 'off' ? 'text-purple-500' : 'text-gray-400 hover:text-white'}`}
        >
          {repeatMode === 'one' ? <Repeat1 size={22} /> : <Repeat size={22} />}
          {repeatMode === 'all' && (
            <div className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-1 h-1 bg-purple-500 rounded-full" />
          )}
        </button>
      </div>

      {onToggleCrossfade && (
        <button
          type="button"
          onClick={onToggleCrossfade}
          title={t('crossfade_hint')}
          className={`flex items-center gap-2 px-4 py-2 rounded-full text-xs font-semibold border transition active:scale-95 ${
            isCrossfade
              ? 'bg-purple-600/30 border-purple-500/50 text-purple-300'
              : 'bg-white/5 border-white/10 text-white/50 hover:text-white/80 hover:bg-white/10'
          }`}
        >
          <Blend size={14} />
          {t('crossfade')}
        </button>
      )}
    </div>
  );
}
