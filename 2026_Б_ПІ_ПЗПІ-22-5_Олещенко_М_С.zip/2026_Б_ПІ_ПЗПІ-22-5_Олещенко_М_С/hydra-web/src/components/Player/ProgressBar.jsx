export default function ProgressBar({ progress, duration, onSeek }) {
  // Форматування часу (0:00)
  const formatTime = (time) => {
    if (!time || isNaN(time) || time === Infinity) return "0:00";
    const min = Math.floor(time / 60);
    const sec = Math.floor(time % 60);
    return `${min}:${sec < 10 ? '0' : ''}${sec}`;
  };

  // Безпечний розрахунок відсотка заповнення
  // Якщо duration 0, то відсоток 0 (щоб не було помилок NaN)
  const currentPercentage = duration > 0 ? (progress / duration) * 100 : 0;

  return (
    <div className="w-full mb-8 group">
      <input 
        type="range" 
        min="0" 
        // Якщо duration ще не завантажився, ставимо 100 як заглушку, але value буде 0
        max={duration || 0} 
        value={progress || 0} 
        onChange={(e) => onSeek(Number(e.target.value))}
        className="w-full h-1.5 rounded-full appearance-none cursor-pointer bg-white/20 focus:outline-none"
        style={{ 
            background: `linear-gradient(to right, #fff ${currentPercentage}%, rgba(255,255,255,0.2) ${currentPercentage}%)` 
        }}
      />
      <div className="flex justify-between text-xs font-medium text-gray-400 mt-2 font-mono">
        <span>{formatTime(progress)}</span>
        <span>{formatTime(duration)}</span>
      </div>
    </div>
  );
}