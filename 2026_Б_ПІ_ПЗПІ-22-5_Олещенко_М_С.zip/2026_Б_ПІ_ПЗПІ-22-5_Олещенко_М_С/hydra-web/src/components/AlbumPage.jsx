import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, Play, Loader2, Disc } from 'lucide-react';
import { fetchWithAsyncContract } from '../utils/asyncApi';
import { useLanguage } from '../context/LanguageContext';

export default function AlbumPage({ onTrackSelect }) {
  const { id } = useParams();
  const navigate = useNavigate();
  const { t } = useLanguage();
  const [album, setAlbum] = useState(null);
  const [tracks, setTracks] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const load = async () => {
      setLoading(true);
      try {
        const data = await fetchWithAsyncContract(`/api/album/${id}`);
        if (data) {
          setAlbum(data);
          setTracks(data.items || []);
        }
      } catch (e) {
        console.error('Album load error:', e);
      } finally {
        setLoading(false);
      }
    };
    if (id) load();
  }, [id]);

  const handlePlayAll = () => {
    if (tracks.length > 0) onTrackSelect(tracks[0], tracks, 0);
  };

  return (
    <div className="w-full min-h-screen bg-[#09090b] pb-40 animate-fade-in">
      <div className="relative pt-20 pb-8 px-6 bg-gradient-to-b from-indigo-900/40 to-[#09090b]">
        <button
          onClick={() => navigate(-1)}
          className="absolute top-6 left-6 p-2 bg-white/10 rounded-full hover:bg-white/20 transition backdrop-blur-md z-10"
        >
          <ArrowLeft size={24} className="text-white" />
        </button>

        <div className="flex flex-col md:flex-row gap-6 items-start md:items-end mt-4">
          {album?.cover ? (
            <img src={album.cover} alt="" className="w-32 h-32 md:w-40 md:h-40 rounded-lg object-cover shadow-2xl" />
          ) : (
            <div className="w-32 h-32 md:w-40 md:h-40 rounded-lg bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center">
              <Disc size={64} className="text-white/80" />
            </div>
          )}
          <div className="flex flex-col gap-2">
            <span className="text-xs font-bold uppercase tracking-widest text-white/60">{t('page_album')}</span>
            <h1 className="text-3xl md:text-4xl font-extrabold text-white">{album?.title || '...'}</h1>
            {album?.artist && (
              <button
                onClick={() => navigate(`/artist/${encodeURIComponent(album.artist)}`)}
                className="text-purple-400 text-sm hover:underline text-left"
              >
                {album.artist}
              </button>
            )}
            <p className="text-white/50 text-sm">
              {loading ? t('loading') : `${tracks.length} ${t('tracks_count')}`}
            </p>
          </div>
        </div>

        {!loading && tracks.length > 0 && (
          <button
            onClick={handlePlayAll}
            className="mt-6 flex items-center gap-2 bg-green-500 hover:bg-green-400 text-black font-bold py-3 px-8 rounded-full transition"
          >
            <Play size={20} fill="black" />
            <span>{t('play_all')}</span>
          </button>
        )}
      </div>

      <div className="px-6 mt-4">
        {loading ? (
          <div className="flex justify-center py-20">
            <Loader2 className="animate-spin text-purple-500" size={40} />
          </div>
        ) : (
          tracks.map((track, idx) => (
            <div
              key={track.id + idx}
              onClick={() => onTrackSelect(track, tracks, idx)}
              className="flex items-center gap-4 py-3 border-b border-white/5 cursor-pointer hover:bg-white/5 px-2 rounded-lg"
            >
              <span className="text-white/40 w-6 text-sm">{idx + 1}</span>
              <img src={track.cover} alt="" className="w-12 h-12 rounded object-cover" />
              <div className="flex-1 min-w-0">
                <p className="text-white font-medium truncate">{track.title}</p>
                <p className="text-gray-400 text-sm truncate">{track.artist}</p>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
