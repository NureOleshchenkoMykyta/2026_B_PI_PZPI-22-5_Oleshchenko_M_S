import React from 'react';
import { useNavigate } from 'react-router-dom';

// Дані, які ви надали, розбиті по секціях
const MOOD_DATA = [
  {
    title: "Популярне",
    items: [
      "Японський реп", "Хіп-хоп дезі", "Китайськомовна поп-музика", 
      "Бразильський хіп-хоп", "Класика", "Family"
    ]
  },
  {
    title: "Настрої та події",
    items: [
      "В дорозі", "Вечірка", "Гарний настрій", "Заряд енергії", 
      "Зосередження", "Релакс", "Романтика", "Сон", "Сум", 
      "Тренування", "Gaming", "Winter"
    ]
  },
  {
    title: "Жанри",
    items: [
      "Арабська музика", "Африканська", "Блюз", "Боллівуд", "Джаз",
      "Інді й aльтернатива", "Кантрі та Американа", "Китайськомовна поп-музика",
      "Класика", "Латинська", "Метал", "Німецький хіп-хоп", 
      "Регі й kарибська", "Саундтреки", "Танцювальна й електронна", 
      "Фолк і hародна", "Японська поп-музика", "Decades", "Family",
      "German pop", "Hip-hop", "K-Pop", "Pop", "R&B та cоул", "Rock", "Schlager"
    ]
  }
];

// Функція для отримання стабільного кольору на основі назви (щоб не миготіло при оновленні)
const getColor = (str) => {
  const colors = [
    'from-purple-500 to-indigo-600',
    'from-pink-500 to-rose-500',
    'from-emerald-500 to-teal-600',
    'from-blue-500 to-cyan-500',
    'from-orange-500 to-amber-500',
    'from-red-500 to-orange-600',
    'from-indigo-500 to-blue-600',
    'from-lime-500 to-green-600',
    'from-fuchsia-500 to-purple-600',
    'from-violet-600 to-indigo-600',
  ];
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    hash = str.charCodeAt(i) + ((hash << 5) - hash);
  }
  const index = Math.abs(hash % colors.length);
  return colors[index];
};

const MoodsGrid = () => {
  const navigate = useNavigate();

  const handleCardClick = (query) => {
    // При кліку шукаємо цей жанр/настрій
    navigate(`/search?q=${encodeURIComponent(query)}`);
  };

  return (
    <div className="space-y-8 pb-8">
      {MOOD_DATA.map((section, idx) => (
        <section key={idx} className="space-y-4">
          <h2 className="text-2xl font-bold text-white mb-4">{section.title}</h2>
          
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
            {section.items.map((item) => (
              <div
                key={item}
                onClick={() => handleCardClick(item)}
                className={`
                  relative overflow-hidden rounded-lg aspect-[16/9] or aspect-square
                  cursor-pointer transition-all duration-300 hover:scale-105 hover:shadow-lg
                  bg-gradient-to-br ${getColor(item)}
                  group
                `}
              >
                {/* Текст */}
                <span className="absolute top-3 left-3 text-white font-bold text-lg md:text-xl break-words max-w-[90%] drop-shadow-md">
                  {item}
                </span>

                {/* Декоративний елемент (можна прибрати, якщо хочеться мінімалізму) */}
                <div className="absolute -bottom-2 -right-2 w-16 h-16 bg-white/10 rounded-full blur-xl group-hover:bg-white/20 transition-all" />
              </div>
            ))}
          </div>
        </section>
      ))}
    </div>
  );
};

export default MoodsGrid;