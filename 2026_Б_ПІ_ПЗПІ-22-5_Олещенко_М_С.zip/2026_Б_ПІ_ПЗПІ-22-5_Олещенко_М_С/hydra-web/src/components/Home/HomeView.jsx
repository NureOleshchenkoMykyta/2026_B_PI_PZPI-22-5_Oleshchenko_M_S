import React, { useEffect, useState, useRef, useCallback } from 'react';
import { createPortal } from 'react-dom';
import { Play, History, ListMusic, Heart, Search, Sparkles, Plus, Mic, X, Loader2, Download,SearchX } from 'lucide-react';
import { apiClient } from '../../config';
import { useSearch } from '../../context/SearchContext';
import { useLanguage } from '../../context/LanguageContext';
import { AnimatePresence, motion } from 'framer-motion';
export default function HomeView({ onTrackSelect, onTabChange, onPlaylistSelect, hasPlayer }) {
  const { setIsSearchOpen } = useSearch();
  const { t } = useLanguage();
  
  // Data States
  const [history, setHistory] = useState([]);
  const [recommendations, setRecommendations] = useState([]);
  const [playlists, setPlaylists] = useState([]);
  const [favorites, setFavorites] = useState([]);
  const [continueItems, setContinueItems] = useState([]);
  const [dailyMix, setDailyMix] = useState([]);
  const [loading, setLoading] = useState(true);
  const [isRecLoading, setIsRecLoading] = useState(false);

  // === SHAZAM STATES ===
  const [isListening, setIsListening] = useState(false);
  const [recognitionResult, setRecognitionResult] = useState(null);
  const [isRecognizing, setIsRecognizing] = useState(false);
  const [showNoMatch, setShowNoMatch] = useState(false);
  // Refs for Audio Logic
  const mediaRecorderRef = useRef(null);
  const audioChunksRef = useRef([]);
  const audioContextRef = useRef(null);
  const analyserRef = useRef(null);
  const animationFrameRef = useRef(null);
  const barRefs = useRef([]); // Refs для 5 стовпчиків візуалізатора

  const loadRecommendations = useCallback(async (retries = 3) => {
      setIsRecLoading(true);
      try {
          const res = await apiClient.get('/api/recommendations/personalized');
          if (res.status === 200) {
              setRecommendations(res.data.slice(0, 9)); 
              setIsRecLoading(false);
          } else if (res.status === 202 && retries > 0) {
              setTimeout(() => {
                  void loadRecommendations(retries - 1);
              }, 3000);
          } else {
              setIsRecLoading(false);
          }
      } catch (e) {
          console.error("Rec load error", e);
          setIsRecLoading(false);
      }
  }, []);

  useEffect(() => {
    const loadData = async () => {
      setLoading(true);
      try {
        const historyRes = await apiClient.get('/api/library/history', { params: { unique: true, limit: 10 } });
        setHistory(historyRes.data.map(item => item.track));

        const playlistsRes = await apiClient.get('/api/library/playlists');
        setPlaylists(playlistsRes.data.slice(0, 9));

        const favRes = await apiClient.get('/api/favorites');
        setFavorites(favRes.data.slice(0, 10));

        try {
          const contRes = await apiClient.get('/api/recommendations/continue');
          setContinueItems(contRes.data || []);
        } catch { /* empty */ }

        try {
          const mixRes = await apiClient.get('/api/recommendations/daily-mix');
          setDailyMix(mixRes.data?.items || []);
        } catch { /* empty */ }

        void loadRecommendations();

      } catch (e) {
        console.error("Home load error", e);
      } finally {
        setLoading(false);
      }
    };
    void loadData();

    return () => {
        if (audioContextRef.current) audioContextRef.current.close();
        if (animationFrameRef.current) cancelAnimationFrame(animationFrameRef.current);
    };
  }, [loadRecommendations]);

  // --- ЛОГІКА SHAZAM ---

  const startListening = async () => {
    try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        
        // 1. Налаштування запису (MediaRecorder)
        mediaRecorderRef.current = new MediaRecorder(stream);
        audioChunksRef.current = [];

        mediaRecorderRef.current.ondataavailable = (event) => {
            if (event.data.size > 0) audioChunksRef.current.push(event.data);
        };

        mediaRecorderRef.current.onstop = async () => {
            const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
            // Зупиняємо візуалізацію та треки
            if (animationFrameRef.current) cancelAnimationFrame(animationFrameRef.current);
            if (audioContextRef.current) {
                audioContextRef.current.close();
                audioContextRef.current = null;
            }
            stream.getTracks().forEach(track => track.stop());
            
            await handleRecognitionUpload(audioBlob);
        };

        // 2. Налаштування візуалізації (Web Audio API)
        const audioCtx = new (window.AudioContext || window.webkitAudioContext)();
        audioContextRef.current = audioCtx;
        
        const analyser = audioCtx.createAnalyser();
        analyser.fftSize = 64; // Менший розмір = менше даних, швидше (нам треба всього 5 стовпчиків)
        analyserRef.current = analyser;

        const source = audioCtx.createMediaStreamSource(stream);
        source.connect(analyser);

        // 3. Цикл анімації
        const visualize = () => {
            if (!analyserRef.current) return;

            const dataArray = new Uint8Array(analyser.frequencyBinCount);
            analyser.getByteFrequencyData(dataArray);

            // Оновлюємо висоту 5 стовпчиків
            // Беремо дані з різних частин спектру (баси, середні, високі)
            const indexes = [2, 6, 12, 18, 24]; 
            
            indexes.forEach((dataIndex, i) => {
                if (barRefs.current[i]) {
                    const value = dataArray[dataIndex] || 0;
                    // Нормалізуємо: 0-255 -> 4px-24px
                    // Додаємо трохи рандому для "живості"
                    const height = Math.max(4, (value / 255) * 24);
                    barRefs.current[i].style.height = `${height}px`;
                }
            });

            animationFrameRef.current = requestAnimationFrame(visualize);
        };
        visualize();

        // Старт
        mediaRecorderRef.current.start();
        setIsListening(true);
        setRecognitionResult(null);

        // Авто-стоп через 7 секунд
        setTimeout(() => {
            if (mediaRecorderRef.current && mediaRecorderRef.current.state === 'recording') {
                stopListening();
            }
        }, 7000);

    } catch (err) {
        console.error("Error accessing microphone:", err);
        alert("Не вдалося отримати доступ до мікрофона");
        setIsListening(false);
    }
  };

  const stopListening = () => {
      if (mediaRecorderRef.current && mediaRecorderRef.current.state === 'recording') {
          mediaRecorderRef.current.stop();
          setIsListening(false);
          setIsRecognizing(true);
      }
  };

  const handleRecognitionUpload = async (audioBlob) => {
      // --- ОБМЕЖЕННЯ РОЗМІРУ (наприклад, 1MB) ---
      if (audioBlob.size > 1024 * 1024) { 
          alert("Файл занадто великий для розпізнавання");
          setIsRecognizing(false);
          return;
      }
      const formData = new FormData();
      formData.append('file', audioBlob, 'shazam_record.webm');

      try {
          const res = await apiClient.post('/api/recognize', formData, {
              headers: { 'Content-Type': 'multipart/form-data' }
          });

          if (res.data && res.data.track) {
              const track = res.data.track;
              setRecognitionResult(track);
              // Фоновий запит для прогріву кешу
              apiClient.get(`/api/track/${track.source_id}`).catch(() => {});
          } else {
              setShowNoMatch(true);
              setTimeout(() => {
                  setShowNoMatch(false);
              }, 2500);
          }
      } catch (e) {
          console.error("Recognition failed", e);
          // При помилці теж доцільно показати, що нічого не розпізнано (або залишити alert)
          setShowNoMatch(true);
          setTimeout(() => {
              setShowNoMatch(false);
          }, 2500);
      } finally {
          setIsRecognizing(false);
      }
  };

  const closeShazam = () => {
      setIsListening(false);
      setIsRecognizing(false);
      setRecognitionResult(null);
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-full min-h-[50dvh] sm:min-h-[60dvh] px-4">
        <Loader2 className="animate-spin text-purple-500" size={32} aria-hidden />
      </div>
    );
  }

  return (
    <div className="w-full max-w-[1600px] mx-auto pb-1 animate-fade-in">
      
      {/* HEADER */}
      <div className="sticky top-0 z-20 bg-[#09090b]/90 backdrop-blur-xl px-4 sm:px-6 lg:px-8 pt-[max(1.25rem,env(safe-area-inset-top))] sm:pt-8 pb-3 sm:pb-4 flex items-center justify-between gap-3 border-b border-white/5">
        
        {/* ЛОГОТИП або ВІЗУАЛІЗАТОР */}
        {isListening ? (
            <div className="flex items-center gap-2 sm:gap-3 text-pink-500 min-w-0 flex-1">
                <div className="flex items-center gap-1 h-6 shrink-0">
                    {[0, 1, 2, 3, 4].map((i) => (
                        <div 
                            key={i}
                            ref={el => barRefs.current[i] = el}
                            className="w-1 bg-pink-500 rounded-full transition-[height] duration-75 ease-linear will-change-[height]"
                            style={{ height: '4px' }} // Початкова висота
                        />
                    ))}
                </div>
                <span className="text-xs sm:text-sm font-bold tracking-widest uppercase animate-pulse truncate">{t('listening') || "Слухаю..."}</span>
            </div>
        ) : (
            <h1 className="text-lg sm:text-xl lg:text-2xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-blue-500 tracking-wide min-w-0 truncate pr-1">
                {t('app_title')}
            </h1>
        )}
        
        <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
            <button 
                type="button"
                onClick={isListening ? stopListening : startListening} 
                className={`p-2 sm:p-2.5 rounded-full text-white transition active:scale-95 touch-manipulation ${
                    isListening 
                    ? 'bg-pink-500 shadow-[0_0_20px_rgba(236,72,153,0.6)] scale-110 ring-2 ring-pink-400 ring-offset-2 ring-offset-black' 
                    : 'bg-white/5 hover:bg-white/10'
                }`}
            >
                {isListening ? <div className="w-4 h-4 sm:w-5 sm:h-5 bg-white rounded-sm animate-pulse" /> : <Mic className="w-[18px] h-[18px] sm:w-5 sm:h-5" aria-hidden />}
            </button>

            <button 
                type="button"
                onClick={() => setIsSearchOpen(true)} 
                className="p-2 sm:p-2.5 bg-white/5 rounded-full text-white hover:bg-white/10 transition active:scale-95 touch-manipulation"
            >
                <Search className="w-[18px] h-[18px] sm:w-5 sm:h-5" aria-hidden />
            </button>
        </div>
      </div>

      {/* === SPINNER (Searching) === */}
      {isRecognizing && (
          <div className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-black/80 backdrop-blur-sm animate-fade-in px-6">
              <Loader2 className="w-10 h-10 sm:w-12 sm:h-12 text-pink-500 animate-spin mb-3 sm:mb-4" aria-hidden />
              <p className="text-white font-medium text-base sm:text-lg text-center">Шукаю трек...</p>
          </div>
      )}

      {/* === RESULT PANEL (Через Portal, прибита до низу) === */}
      {recognitionResult && createPortal(
          <>
            <div 
                onClick={closeShazam}
                className="fixed inset-0 z-[9998] bg-transparent"
            />

            <div 
                className={`fixed z-[9999] left-3 right-3 sm:left-4 sm:right-4 md:left-1/2 md:right-auto md:-translate-x-1/2 md:w-full md:max-w-md 
                transition-all duration-500 cubic-bezier(0.32, 0.72, 0, 1)
                ${hasPlayer ? 'bottom-[max(9rem,env(safe-area-inset-bottom)+7.5rem)] md:bottom-[max(6.25rem,env(safe-area-inset-bottom)+4rem)]' : 'bottom-[max(5.5rem,env(safe-area-inset-bottom)+4.25rem)] md:bottom-[max(2.5rem,env(safe-area-inset-bottom)+1.5rem)]'} 
                `}
            >
              <div className="w-full bg-[#18181b] border border-white/10 rounded-xl sm:rounded-2xl p-3 sm:p-4 shadow-[0_8px_30px_rgb(0,0,0,0.5)] relative overflow-hidden backdrop-blur-xl">
                  
                  <div className="absolute -top-10 -left-10 w-40 h-40 bg-pink-500/20 rounded-full blur-3xl pointer-events-none" />
                  
                  <button onClick={closeShazam} className="absolute top-3 right-3 p-1.5 bg-white/5 hover:bg-white/10 rounded-full text-white/70 hover:text-white transition z-10">
                      <X size={16} />
                  </button>

                  <div className="relative flex flex-row items-center gap-3">
                      <div className="w-14 h-14 rounded-lg overflow-hidden shadow-lg border border-white/10 flex-shrink-0 bg-gray-800">
                          <img src={recognitionResult.cover} alt={recognitionResult.title} className="w-full h-full object-cover" />
                      </div>

                      <div className="flex-1 min-w-0 pr-6">
                          <h2 className="text-sm font-bold text-white leading-tight truncate">{recognitionResult.title}</h2>
                          <p className="text-white/60 text-xs truncate mt-0.5">{recognitionResult.artist}</p>
                          
                          <div className="flex items-center gap-1.5 mt-1.5">
                              <div className="flex gap-0.5 h-2 items-end">
                                  <span className="w-0.5 h-2 bg-green-400 animate-pulse"></span>
                                  <span className="w-0.5 h-1.5 bg-green-400 animate-pulse delay-75"></span>
                                  <span className="w-0.5 h-2.5 bg-green-400 animate-pulse delay-150"></span>
                              </div>
                              <span className="text-[10px] text-green-400 font-medium">Завантажено</span>
                          </div>
                      </div>
                  </div>

                  <div className="flex gap-2 w-full mt-3">
                      <button 
                          onClick={() => {
                              onTrackSelect(recognitionResult, [recognitionResult]);
                              closeShazam(); 
                          }}
                          className="flex-1 bg-white text-black py-2 rounded-lg text-xs font-bold flex items-center justify-center gap-2 hover:bg-gray-200 transition active:scale-95"
                      >
                          <Play size={14} className="fill-black" />
                          Слухати
                      </button>
                      
                      <button 
                          onClick={async (e) => {
                              e.stopPropagation();
                              try {
                                  const isLiked = favorites.some(f => f.id === recognitionResult.source_id);
                                  if (isLiked) {
                                      setFavorites(prev => prev.filter(f => f.id !== recognitionResult.source_id));
                                  } else {
                                      setFavorites(prev => [recognitionResult, ...prev]);
                                  }
                                  await apiClient.post(`/api/favorites/toggle`, { track_id: recognitionResult.source_id });
                              } catch(e) { console.error(e); }
                          }}
                          className={`w-10 flex items-center justify-center bg-white/10 rounded-lg hover:bg-white/20 transition active:scale-95 ${
                              favorites.some(f => f.id === recognitionResult.source_id) ? 'text-pink-500' : 'text-white'
                          }`}
                      >
                          <Heart size={18} className={favorites.some(f => f.id === recognitionResult.source_id) ? 'fill-pink-500' : ''} />
                      </button>
                  </div>
              </div>
            </div>
          </>,
          document.body 
      )}

        <AnimatePresence>
            {showNoMatch && (
                <motion.div 
                    initial={{ opacity: 0, scale: 0.8 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.8 }}
                    transition={{ duration: 0.2 }}
                    className="fixed inset-0 z-[60] flex items-center justify-center pointer-events-none"
                >
                    <div className="bg-black/60 backdrop-blur-md p-5 sm:p-6 rounded-2xl sm:rounded-3xl flex flex-col items-center gap-2 sm:gap-3 border border-white/10 shadow-2xl max-w-[min(100%,20rem)] mx-4">
                        <SearchX className="w-10 h-10 sm:w-12 sm:h-12 text-white/70" />
                        <span className="text-white/90 font-medium text-xs sm:text-sm text-center">
                            {t('nothing_found')}
                        </span>
                    </div>
                </motion.div>
            )}
        </AnimatePresence>
        
      {/* CONTENT */}
      <div className="space-y-4 sm:space-y-5 lg:space-y-6 pt-3 sm:pt-4 lg:pt-5 px-0">
        {continueItems.length > 0 && (
            <SimpleTrackSection title={t('continue_listening')} icon={Play}>
                {continueItems.map((item) => (
                    <TrackCard
                      key={item.track.id}
                      track={item.track}
                      onClick={() => onTrackSelect(item.track, [item.track], 0, item.playback_position)}
                    />
                ))}
            </SimpleTrackSection>
        )}

        {dailyMix.length > 0 && (
            <SimpleTrackSection title={t('daily_mix')} icon={Sparkles}>
                {dailyMix.slice(0, 9).map((track) => (
                    <TrackCard key={track.id} track={track} onClick={() => onTrackSelect(track, dailyMix)} />
                ))}
            </SimpleTrackSection>
        )}

        {history.length > 0 && (
            <SimpleTrackSection title={t('recently_listened')} icon={History}>
                {history.map((track) => (
                    <TrackCard key={track.id} track={track} onClick={() => onTrackSelect(track, history)} />
                ))}
            </SimpleTrackSection>
        )}

        {(recommendations.length > 0 || isRecLoading) && (
             <RecsSection 
                title={t('section_you_may_like')} 
                loadingText={t('picking_music')}
                icon={Sparkles} 
                tracks={recommendations} 
                isLoading={isRecLoading} 
                onTrackSelect={onTrackSelect} 
            />
        )}

        <div className="px-4 sm:px-6 lg:px-8 pb-2">
            <div className="flex items-center gap-2 mb-2 sm:mb-3 text-white/90">
                <ListMusic className="w-4 h-4 sm:w-[18px] sm:h-[18px] text-blue-400 shrink-0" aria-hidden />
                <h3 className="font-bold text-base sm:text-lg">{t('section_library')}</h3>
            </div>
            
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-2 sm:gap-3">
                {/* 1. Улюблене (Першим, колір як в бібліотеці) */}
                <QuickActionBox 
                    icon={Heart} 
                    label={t('folder_favorites')} 
                    color="from-purple-700 to-blue-800" 
                    onClick={() => onTabChange('liked')} 
                />

                {/* 2. Ваші плейлисти (до 8 штук, щоб заповнити сітку 3x3) */}
                {playlists.slice(0, 8).map((pl) => (
                    <div 
                        key={pl.id} 
                        onClick={() => onPlaylistSelect(pl)}
                        className="aspect-square bg-[#1A1A1A] rounded-lg sm:rounded-xl relative overflow-hidden group cursor-pointer hover:bg-[#222] transition border border-white/5 shadow-sm touch-manipulation"
                    >
                        {pl.cover ? (
                            <img src={pl.cover} className="w-full h-full object-cover opacity-60 group-hover:opacity-40 transition" />
                        ) : (
                            <div className="w-full h-full flex items-center justify-center text-gray-600">
                                <ListMusic className="w-5 h-5 sm:w-6 sm:h-6" aria-hidden />
                            </div>
                        )}
                        <span className="absolute bottom-1.5 sm:bottom-2 left-1.5 right-1.5 sm:left-2 sm:right-2 text-[9px] sm:text-[10px] font-bold text-white leading-tight line-clamp-2 z-10 drop-shadow-md">
                            {pl.title}
                        </span>
                    </div>
                ))}
                
                {/* Кнопку "Plus" (Створити плейлист) прибрано */}
            </div>
        </div>
      </div>
    </div>
  );
}

// ... SimpleTrackSection, TrackCard, RecsSection, QuickActionBox залишаються без змін ...
const RecsSection = ({ title, icon: Icon, tracks, isLoading, onTrackSelect, loadingText }) => (
    <div className="flex flex-col gap-2 sm:gap-3">
        <div className="px-4 sm:px-6 lg:px-8 flex items-center justify-between">
            <div className="flex items-center gap-2 text-white/90 min-w-0">
                {Icon && <Icon className="w-4 h-4 sm:w-[18px] sm:h-[18px] text-purple-400 shrink-0" aria-hidden />}
                <h3 className="font-bold text-base sm:text-lg truncate">{title}</h3>
            </div>
        </div>
        
        <div className="overflow-x-auto overscroll-x-contain custom-scrollbar pl-4 sm:pl-6 lg:pl-8 pr-3 sm:pr-4 pb-3 sm:pb-4 snap-x snap-mandatory scroll-pl-4 sm:scroll-pl-6 [-webkit-overflow-scrolling:touch] touch-manipulation">
            {isLoading ? (
                 <div className="w-full min-h-[8rem] sm:h-36 flex items-center justify-center text-gray-500 gap-2 px-2">
                    <Loader2 className="animate-spin shrink-0" size={24} />
                    <span className="text-xs sm:text-sm text-center">{loadingText}</span>
                </div>
            ) : (
                <div 
                    className="w-fit grid grid-rows-3 grid-flow-col gap-2 sm:gap-3"
                    style={{ 
                        width: 'max-content',
                        minWidth: '100%',
                    }}
                >
                    {tracks.map((track, index) => (
                        <div 
                            key={track.id + index} 
                            onClick={() => onTrackSelect(track, tracks)}
                            className="w-[9.25rem] sm:w-40 md:w-44 flex items-center gap-2 sm:gap-3 p-1.5 sm:p-2 bg-[#1A1A1A] rounded-lg group cursor-pointer hover:bg-[#222] transition active:scale-[0.99] shadow-md snap-center touch-manipulation"
                            style={{ gridRow: `span 1 / span 1` }} 
                        >
                            <img src={track.cover} alt="" className="w-9 h-9 sm:w-10 sm:h-10 rounded-md object-cover flex-shrink-0" />
                            <div className="min-w-0 flex-1">
                                <div className="text-[11px] sm:text-xs font-bold text-white truncate">{track.title}</div>
                                <div className="text-[10px] text-gray-400 truncate">{track.artist}</div>
                            </div>
                        </div>
                    ))}
                </div>
            )}
        </div>
        
    </div>
);

const SimpleTrackSection = ({ title, icon: Icon, children }) => (
  <div className="flex flex-col gap-2 sm:gap-3">
    <div className="px-4 sm:px-6 lg:px-8 flex items-center justify-between">
      <div className="flex items-center gap-2 text-white/90 min-w-0">
        {Icon && <Icon className="w-4 h-4 sm:w-[18px] sm:h-[18px] text-purple-400 shrink-0" aria-hidden />}
        <h3 className="font-bold text-base sm:text-lg truncate">{title}</h3>
      </div>
    </div>
    <div className="overflow-x-auto overscroll-x-contain custom-scrollbar px-4 sm:px-6 lg:px-8 flex gap-2 sm:gap-3 pb-3 sm:pb-4 snap-x snap-mandatory scroll-pl-4 sm:scroll-pl-6 [-webkit-overflow-scrolling:touch] touch-manipulation">
      {children}
    </div>
  </div>
);

const TrackCard = ({ track, onClick }) => (
    <div 
        onClick={onClick}
        role="button"
        tabIndex={0}
        onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); onClick?.(); } }}
        className="snap-start flex-shrink-0 w-[6.5rem] sm:w-32 md:w-36 lg:w-40 flex flex-col gap-1.5 sm:gap-2 group cursor-pointer touch-manipulation"
    >
        <div className="relative w-full aspect-square rounded-lg sm:rounded-xl overflow-hidden bg-gray-800 shadow-md border border-white/5">
            <img src={track.cover} alt="" className="w-full h-full object-cover opacity-90 group-hover:opacity-100 transition duration-300" />
            <div className="absolute inset-0 flex items-center justify-center bg-black/20 opacity-0 group-hover:opacity-100 transition">
                <div className="w-7 h-7 sm:w-8 sm:h-8 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center">
                    <Play className="w-3.5 h-3.5 sm:w-[14px] sm:h-[14px] fill-white text-white ml-0.5" aria-hidden />
                </div>
            </div>
        </div>
        <div className="min-w-0 px-0.5">
            <h4 className="text-[11px] sm:text-xs font-bold text-gray-100 truncate leading-tight">{track.title}</h4>
            <p className="text-[9px] sm:text-[10px] text-gray-500 truncate">{track.artist}</p>
        </div>
    </div>
);

const QuickActionBox = ({ icon: Icon, label, color, onClick }) => (
    <div 
        onClick={onClick}
        role="button"
        tabIndex={0}
        onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); onClick?.(); } }}
        className={`aspect-square rounded-lg sm:rounded-xl relative overflow-hidden group cursor-pointer bg-gradient-to-br ${color} flex flex-col items-center justify-center shadow-lg active:scale-95 transition px-1 touch-manipulation`}
    >
        <Icon className="text-white mb-0.5 sm:mb-1 w-5 h-5 sm:w-6 sm:h-6" aria-hidden />
        <span className="text-[9px] sm:text-[10px] font-bold text-white text-center leading-tight line-clamp-2 px-0.5">{label}</span>
    </div>
);