import React, { useEffect, useState } from 'react';
import { Compass, TrendingUp, Search, Play, Disc, ListMusic, ChevronRight, Loader2, Globe } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useSearch } from '../../context/SearchContext';
import { useLanguage } from '../../context/LanguageContext';
import { apiClient } from '../../config';
import SearchResults from '../Search/SearchResults';

// --- КОНФІГУРАЦІЯ ---
const MOOD_SECTIONS = [
  {
    titleKey: 'section_moods_events',
    items: [
      'cat_on_road', 'cat_party', 'cat_good_mood', 'cat_energy', 
      'cat_focus', 'cat_relax', 'cat_romance', 'cat_sleep', 'cat_sad', 
      'cat_workout', 'cat_gaming', 'cat_winter'
    ]
  },
  {
    titleKey: 'section_all_genres',
    items: [
      'cat_pop', 'cat_hiphop', 'cat_rock', 'cat_dance_electronic',
      'cat_indie_alt', 'cat_rnb_soul', 'cat_kpop', 'cat_jazz',
      'cat_metal', 'cat_classic', 'cat_reggae', 'cat_country_americana', 
      'cat_latin', 'cat_blues', 'cat_folk', 'cat_soundtracks', 
      'cat_jpop', 'cat_arab', 'cat_african', 'cat_bollywood', 
      'cat_decades', 'cat_schlager' 
    ]
  }
];

const getGradient = (str) => {
  const gradients = [
    'from-purple-900/60 to-blue-900/60 border-purple-500/20',
    'from-red-900/60 to-orange-900/60 border-red-500/20',
    'from-emerald-900/60 to-green-900/60 border-emerald-500/20',
    'from-pink-900/60 to-rose-900/60 border-pink-500/20',
    'from-blue-900/60 to-indigo-900/60 border-blue-500/20',
    'from-violet-900/60 to-purple-900/60 border-violet-500/20',
    'from-amber-700/60 to-orange-700/60 border-amber-500/20',
    'from-cyan-900/60 to-blue-900/60 border-cyan-500/20'
  ];
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    hash = str.charCodeAt(i) + ((hash << 5) - hash);
  }
  return gradients[Math.abs(hash % gradients.length)];
};

export default function OverviewPage({ onTrackSelect, onPlaylistSelect }) {
  const { isSearchOpen, setIsSearchOpen, searchQuery, setSearchQuery, closeSearch } = useSearch();
  const { t } = useLanguage();
  const navigate = useNavigate();
  
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
      const loadOverview = async () => {
          setLoading(true);
          try {
              const res = await apiClient.get('/api/overview');
              setData(res.data);
          } catch (e) {
              console.error("Failed to load overview", e);
          } finally {
              setLoading(false);
          }
      };
      loadOverview();
  }, []);

  const handleCategoryClick = (key) => {
      navigate(`/genre/${key}`, { state: { title: t(key), originalKey: key } });
  };

  const handleItemClick = (item) => {
      // 1. АЛЬБОМ або ПЛЕЙЛИСТ -> Відкриваємо сторінку деталей
      if (item.type === 'album' || item.type === 'playlist') {
          onPlaylistSelect(item); 
      } 
      // 2. ТРЕК -> Граємо одразу
      else if (item.type === 'video' || item.type === 'song') {
          onTrackSelect({
              id: item.id || item.videoId,
              title: item.title,
              artist: item.artist,
              cover: item.cover,
              source: 'youtube'
          });
      } 
      // 3. Інше -> Шукаємо
      else {
          setIsSearchOpen(true);
          setSearchQuery(`${item.artist} ${item.title}`);
      }
  };

  return (
    <div className="w-full pb-1 animate-fade-in bg-[#09090b]">
       
       {/* HEADER */}
       <div className="sticky top-0 z-20 bg-[#09090b]/90 backdrop-blur-xl px-6 pt-8 pb-4 flex items-center justify-between border-b border-white/5">
          {!isSearchOpen ? (
             <>
                <div className="flex items-center gap-2 text-white">
                   
                   <h2 className="text-xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-blue-500 tracking-wide">
                      {t('overview_title')}
                   </h2>
                </div>
                <button 
                    onClick={() => setIsSearchOpen(true)} 
                    className="p-2.5 bg-white/5 rounded-full text-white hover:bg-white/10 transition active:scale-95"
                >
                   <Search size={20} />
                </button>
             </>
          ) : (
             <div className="w-full flex items-center gap-3 animate-fade-in">
                <div className="flex-1 relative">
                    <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                    <input 
                        autoFocus
                        type="text" 
                        placeholder={t('find_trends')}
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        className="w-full bg-[#1A1A1A] border border-white/10 rounded-full py-2 pl-9 pr-4 text-sm text-white focus:outline-none focus:border-purple-500 transition"
                    />
                </div>
                <button onClick={closeSearch} className="text-sm text-gray-400 hover:text-white font-medium">{t('cancel')}</button>
             </div>
          )}
       </div>

       {/* CONTENT */}
       {isSearchOpen && searchQuery ? (
          <div className="px-6 pt-4">
             <SearchResults onResultClick={onTrackSelect} />
          </div>
       ) : (
          <div className="space-y-0 pt-4">
             
             {/* 1. БЛОКИ: API DATA (Тренди, Чарти, Новинки) - ПЕРШИМИ */}
             {!loading && data?.sections && (
                 <div className="space-y-2 pb-4">
                     {data.sections.map((section) => {
                         // Пропускаємо ручні mood-секції, якщо вони прийшли з API (хоча ми їх рендеримо нижче вручну)
                         if (section.id === 'moods') return null;
                         
                         if (section.id === 'charts_ua') return null;

                         return section.items.length > 0 && (
                            <div key={section.id} className="flex flex-col gap-4">
                                <div className="px-6 flex items-center justify-between">
                                    <div className="flex items-center gap-2 text-white/90">
                                        {/* Іконки для різних секцій */}
                                        {(section.id === 'charts' || section.id === 'charts_ua') && (
                                            <TrendingUp size={18} className="text-green-400" />
                                        )}
                                        {section.id === 'charts_global' && (
                                            <Globe size={18} className="text-blue-400" />
                                        )}
                                        {section.id === 'new' && (
                                            <Disc size={18} className="text-purple-400" />
                                        )}
                                        
                                        <h3 className="font-bold text-lg">
                                        {/* Перевіряємо ID секції і підставляємо ключ перекладу */}
                                        {section.id === 'new' ? t('section_fresh') : 
                                        section.id === 'charts_global' ? t('section_trending') : 
                                        section.title}
                                    </h3>
                                    </div>
                                    <ChevronRight size={16} className="text-white/30" />
                                </div>
                                
                                <div className="overflow-x-auto custom-scrollbar px-6 flex gap-3 pb-4 snap-x snap-mandatory scroll-pl-6">
                                    {section.items.map((item, idx) => (
                                        <div 
                                            key={idx} 
                                            onClick={() => handleItemClick(item)}
                                            className="snap-start flex-shrink-0 w-28 sm:w-32 flex flex-col gap-2 group cursor-pointer"
                                        >
                                            <div className="relative w-full aspect-square rounded-xl overflow-hidden bg-gray-800 shadow-md border border-white/5">
                                                <img 
                                                    src={item.cover} 
                                                    loading="lazy" 
                                                    alt={item.title}
                                                    className="w-full h-full object-cover opacity-90 group-hover:opacity-100 transition duration-300" 
                                                />
                                                <div className="absolute inset-0 flex items-center justify-center bg-black/20 opacity-0 group-hover:opacity-100 transition">
                                                    <div className="w-8 h-8 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center">
                                                        {item.type === 'album' || item.type === 'playlist' ? (
                                                            <ListMusic size={14} className="text-white ml-0.5" />
                                                        ) : (
                                                            <Play size={14} fill="white" className="text-white ml-0.5" />
                                                        )}
                                                    </div>
                                                </div>
                                            </div>
                                            
                                            <div className="min-w-0 px-0.5">
                                                <h4 className="text-xs font-bold text-gray-100 truncate leading-tight">{item.title}</h4>
                                                <p className="text-[10px] text-gray-500 truncate mt-0.5">{item.artist}</p>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            </div>
                         );
                     })}
                 </div>
             )}

             {/* 2. БЛОКИ: MOODS & GENRES - ДРУГИМИ (В НИЗУ) */}
             <div className="space-y-6">
                {MOOD_SECTIONS.map((section, idx) => (
                    <div key={idx} className="flex flex-col gap-3">
                        <div className="px-6 flex items-center justify-between">
                            <div className="flex items-center gap-2 text-white/90">
                                <h3 className="font-bold text-lg">{t(section.titleKey)}</h3>
                            </div>
                        </div>
                        
                        <div className="overflow-x-auto custom-scrollbar pl-6 pr-4 pb-2 snap-x snap-mandatory scroll-pl-6">
                            <div className="w-fit grid grid-rows-3 grid-flow-col gap-3 min-w-full">
                                {section.items.map((key) => (
                                    <div
                                        key={key}
                                        onClick={() => handleCategoryClick(key)}
                                        className={`
                                            snap-center
                                            relative w-36 h-10 rounded-lg overflow-hidden cursor-pointer 
                                            transition-all duration-200 active:scale-95 hover:brightness-110 group
                                            bg-gradient-to-r border ${getGradient(key)}
                                            flex items-center justify-start px-3
                                        `}
                                    >
                                        <span className="text-white font-bold text-[11px] leading-tight drop-shadow-md truncate w-full">
                                            {t(key)}
                                        </span>
                                    </div>
                                ))}
                            </div>
                        </div>
                    </div>
                ))}
             </div>

             {loading && (
                <div className="flex justify-center items-center h-40">
                    <Loader2 className="animate-spin text-purple-500" size={32} />
                </div>
             )}
          </div>
       )}
    </div>
  );
}