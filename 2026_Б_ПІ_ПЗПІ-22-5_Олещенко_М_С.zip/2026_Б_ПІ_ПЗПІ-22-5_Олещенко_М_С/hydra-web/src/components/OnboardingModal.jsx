import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Check } from 'lucide-react';
import { apiClient } from '../config';
import { useLanguage } from '../context/LanguageContext';

const GENRE_OPTIONS = [
  'cat_pop', 'cat_rock', 'cat_hiphop', 'cat_electronic',
  'cat_jazz', 'cat_classical', 'cat_reggae', 'cat_country',
  'cat_rnb', 'cat_metal', 'cat_indie', 'cat_latin',
];

export default function OnboardingModal({ onComplete }) {
  const { t } = useLanguage();
  const [selected, setSelected] = useState([]);
  const [saving, setSaving] = useState(false);

  const toggle = (g) => {
    setSelected((prev) =>
      prev.includes(g) ? prev.filter((x) => x !== g) : prev.length < 5 ? [...prev, g] : prev
    );
  };

  const handleSave = async () => {
    if (selected.length < 3) return;
    setSaving(true);
    try {
      await apiClient.patch('/api/user/settings', {
        music_preferences: { genres: selected },
        onboarding_completed: true,
      });
      onComplete?.();
    } catch (e) {
      console.error('Onboarding save failed:', e);
    } finally {
      setSaving(false);
    }
  };

  const label = (key) => t(key) || key.replace('cat_', '').replace('_', ' ');

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="fixed inset-0 z-[100] bg-black/90 flex items-end sm:items-center justify-center p-4"
    >
      <div className="bg-[#18181b] rounded-2xl w-full max-w-md p-6 max-h-[85vh] overflow-y-auto">
        <h2 className="text-2xl font-bold text-white mb-2">{t('onboarding_title')}</h2>
        <p className="text-gray-400 text-sm mb-6">{t('onboarding_subtitle')}</p>

        <div className="flex flex-wrap gap-2 mb-6">
          {GENRE_OPTIONS.map((g) => (
            <button
              key={g}
              onClick={() => toggle(g)}
              className={`px-4 py-2 rounded-full text-sm font-medium transition flex items-center gap-1 ${
                selected.includes(g)
                  ? 'bg-purple-600 text-white'
                  : 'bg-white/10 text-white hover:bg-white/20'
              }`}
            >
              {selected.includes(g) && <Check size={14} />}
              {label(g)}
            </button>
          ))}
        </div>

        <p className="text-xs text-gray-500 mb-4">
          {selected.length}/5 — {t('onboarding_min')}
        </p>

        <button
          onClick={handleSave}
          disabled={selected.length < 3 || saving}
          className="w-full py-3 bg-green-500 text-black font-bold rounded-full disabled:opacity-40"
        >
          {saving ? t('loading') : t('onboarding_continue')}
        </button>
      </div>
    </motion.div>
  );
}
