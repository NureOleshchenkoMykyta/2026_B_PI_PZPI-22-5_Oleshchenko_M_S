import React, { useEffect, useState } from 'react';
import { useParams, useLocation, useNavigate } from 'react-router-dom';
import { ArrowLeft, Play, Loader2, Disc } from 'lucide-react';
import { fetchWithAsyncContract } from '../utils/asyncApi';

export default function GenrePage({ onTrackSelect }) {
  const { id } = useParams(); // Отримуємо 'cat_party' тощо
  const { state } = useLocation(); // Отримуємо назву, якщо перейшли з меню
  const navigate = useNavigate();
  
  const [tracks, setTracks] = useState([]);
  const [loading, setLoading] = useState(true);

  // Назва для відображення (якщо немає в state, показуємо ID)
  const displayTitle = state?.title || id?.replace('cat_', '').replace('_', ' ');

  useEffect(() => {
    const loadGenreTracks = async () => {
        setLoading(true);
        try {
            const data = await fetchWithAsyncContract(`/api/genre/${id}`);
            if (data && data.items) {
                setTracks(data.items);
            }
        } catch (e) {
            console.error("Genre load error:", e);
        } finally {
            setLoading(false);
        }
    };

    if (id) loadGenreTracks();
  }, [id]);

  // Функція для запуску всього списку
  const handlePlayAll = () => {
      if (tracks.length > 0) {
          onTrackSelect(tracks[0], tracks);
      }
  };

  return (
    <div className="w-full min-h-screen bg-[#09090b] pb-40 animate-fade-in">
      
      {/* --- HEADER --- */}
      <div className="relative pt-20 pb-8 px-6 bg-gradient-to-b from-purple-900/40 to-[#09090b]">
          {/* Back Button */}
          <button 
            onClick={() => navigate(-1)} 
            className="absolute top-6 left-6 p-2 bg-white/10 rounded-full hover:bg-white/20 transition backdrop-blur-md z-10"
          >
            <ArrowLeft size={24} className="text-white" />
          </button>

          <div className="flex flex-col md:flex-row gap-6 items-start md:items-end mt-4">
              {/* Велика іконка категорії (Декоративна) */}
              <div className="w-32 h-32 md:w-40 md:h-40 rounded-lg bg-gradient-to-br from-purple-500 to-blue-600 flex items-center justify-center shadow-2xl shadow-purple-900/20">
                  <Disc size={64} className="text-white/80 animate-spin-slow" />
              </div>

              <div className="flex flex-col gap-2">
                  <span className="text-xs font-bold uppercase tracking-widest text-white/60">Категорія</span>
                  <h1 className="text-3xl md:text-5xl font-extrabold text-white capitalize drop-shadow-lg">
                      {displayTitle}
                  </h1>
                  <p className="text-white/50 text-sm mt-1">
                      {loading ? "Завантаження..." : `${tracks.length} треків підібрано для вас`}
                  </p>
              </div>
          </div>

          {/* Play All Button (Floating) */}
          {!loading && tracks.length > 0 && (
              <button 
                onClick={handlePlayAll}
                className="mt-6 md:mt-0 md:absolute md:bottom-8 md:right-8 flex items-center gap-2 bg-green-500 hover:bg-green-400 text-black font-bold py-3 px-8 rounded-full transition transform hover:scale-105 shadow-lg active:scale-95"
              >
                <Play size={20} fill="black" />
                <span>Слухати</span>
              </button>
          )}
      </div>

      {/* --- CONTENT --- */}
      <div className="px-6 mt-6">
          {loading ? (
              <div className="flex flex-col items-center justify-center py-20 gap-4">
                  <Loader2 className="animate-spin text-purple-500" size={40} />
                  <span className="text-white/50 text-sm">Підбираємо найкращі треки...</span>
              </div>
          ) : (
              <>
                {tracks.length > 0 ? (
                    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4">
                        {tracks.map((track, idx) => (
                            <div 
                                key={track.id + idx}
                                onClick={() => onTrackSelect(track, tracks)} 
                                className="group relative bg-[#18181b] p-3 rounded-md hover:bg-[#27272a] transition duration-300 cursor-pointer"
                            >
                                {/* Cover Image */}
                                <div className="relative w-full aspect-square mb-3 rounded-md overflow-hidden shadow-lg">
                                    <img 
                                        src={track.cover} 
                                        loading="lazy" 
                                        alt={track.title}
                                        className="w-full h-full object-cover group-hover:scale-105 transition duration-500" 
                                    />
                                    {/* Hover Overlay Play Button */}
                                    <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center translate-y-2 group-hover:translate-y-0 duration-300">
                                        <div className="w-10 h-10 bg-green-500 rounded-full flex items-center justify-center shadow-lg hover:scale-110 transition">
                                            <Play size={20} fill="black" className="text-black ml-1" />
                                        </div>
                                    </div>
                                </div>

                                {/* Text Info */}
                                <div className="flex flex-col gap-1">
                                    <h3 className="font-bold text-white text-sm truncate" title={track.title}>
                                        {track.title}
                                    </h3>
                                    <p className="text-xs text-gray-400 truncate hover:underline">
                                        {track.artist}
                                    </p>
                                </div>
                            </div>
                        ))}
                    </div>
                ) : (
                    <div className="text-center py-20 text-white/50">
                        <p>На жаль, нічого не знайдено для цієї категорії.</p>
                        <button onClick={() => window.location.reload()} className="mt-4 text-purple-400 hover:text-purple-300 underline">
                            Спробувати ще раз
                        </button>
                    </div>
                )}
              </>
          )}
      </div>
    </div>
  );
}