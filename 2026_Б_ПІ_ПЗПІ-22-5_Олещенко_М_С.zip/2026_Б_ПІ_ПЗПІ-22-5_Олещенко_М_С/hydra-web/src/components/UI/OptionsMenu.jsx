import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  X, ListPlus, Heart, Share2, Radio, ChevronLeft, Plus, Loader2, Check, 
  Send, Moon
} from 'lucide-react';
import { useFavorites } from '../../context/FavoritesContext';
import { useLanguage } from '../../context/LanguageContext';
import { apiClient } from '../../config';

export default function OptionsMenu({
  isOpen,
  onClose,
  track,
  onPlayRadio,
  sleepRemaining = null,
  onStartSleepTimer,
  onCancelSleepTimer,
}) {
  const { toggleFavorite, isFavorite } = useFavorites();
  const { t } = useLanguage();
  
  const [view, setView] = useState('menu'); 
  const [playlists, setPlaylists] = useState([]);
  const [isLoadingPlaylists, setIsLoadingPlaylists] = useState(false);
  
  const [newPlaylistTitle, setNewPlaylistTitle] = useState('');
  const [isCreating, setIsCreating] = useState(false);
  
  const [toastMessage, setToastMessage] = useState(null); 
  const [isSuccess, setIsSuccess] = useState(true);

  const trackId = track?.id || track?.source_id;
  const isLiked = isFavorite(trackId);

  useEffect(() => {
    if (!isOpen) setView('menu');
  }, [isOpen]);

  const formatSleep = (sec) => {
    const m = Math.floor(sec / 60);
    const s = sec % 60;
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  const showToast = (msg, success = true) => {
      setToastMessage(msg);
      setIsSuccess(success);
      if (success) {
          setTimeout(() => {
              setToastMessage(null);
              onClose();
          }, 1500);
      } else {
          setTimeout(() => setToastMessage(null), 3000);
      }
  };

  const loadPlaylists = () => {
    setIsLoadingPlaylists(true);
    apiClient
      .get('/api/library/playlists')
      .then((res) => setPlaylists(res.data))
      .catch((err) => console.error(err))
      .finally(() => setIsLoadingPlaylists(false));
  };

  // === ДІЇ З ПЕРЕКЛАДОМ ===
  const handleSendToChat = async () => {
      try {
          await apiClient.post(`/api/download/send-to-chat/${trackId}`);
          showToast(t('toast_sent_tg'), true);
      } catch (e) {
          console.error(e);
          showToast(t('toast_send_error'), false);
      }
  };

  const handleShare = async () => {
      try {
          const res = await apiClient.post('/api/share/card', { track_id: trackId });
          const { url, telegram_share_text } = res.data;
          if (window.Telegram?.WebApp?.openTelegramLink) {
              const shareUrl = `https://t.me/share/url?url=${encodeURIComponent(url)}&text=${encodeURIComponent(telegram_share_text || '')}`;
              window.Telegram.WebApp.openTelegramLink(shareUrl);
              showToast(t('toast_link_copied'), true);
          } else {
              await navigator.clipboard.writeText(telegram_share_text || url);
              showToast(t('toast_link_copied'), true);
          }
      } catch {
          const url = `${window.location.origin}/track/${trackId}`;
          navigator.clipboard.writeText(url)
              .then(() => showToast(t('toast_link_copied'), true))
              .catch(() => showToast(t('toast_copy_error'), false));
      }
  };

  const handleRadio = async () => {
      try {
          showToast(t('toast_searching_similar'), true);
          
          const res = await apiClient.get(`/api/recommendations/${trackId}`);
          
          if (res.status === 202) {
             showToast(t('toast_radio_creating'), true);
             return;
          }

          if (onPlayRadio && Array.isArray(res.data) && res.data.length > 0) {
              onPlayRadio(res.data);
              onClose();
          } else {
              showToast(t('toast_no_similar'), false);
          }
      } catch (e) {
          console.error("Radio API error", e);
          showToast(t('toast_radio_error'), false);
      }
  };

  const handleAddToPlaylist = async (playlistId) => {
      try {
          await apiClient.post(`/api/library/playlists/${playlistId}/add`, null, {
              params: { track_id: trackId }
          });
          showToast(t('toast_added_playlist'), true);
      } catch {
          showToast(t('toast_add_error'), false);
      }
  };

  const handleCreateAndAdd = async () => {
      if (!newPlaylistTitle.trim()) return;
      setIsCreating(true);
      try {
          const createRes = await apiClient.post('/api/library/playlists', null, {
              params: { title: newPlaylistTitle }
          });
          await handleAddToPlaylist(createRes.data.id);
      } catch {
          setIsCreating(false);
          showToast(t('toast_create_error'), false);
      }
  };

  if (!track) return null;

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-black/60 z-50 backdrop-blur-sm"
          />
          
          <motion.div 
            initial={{ y: "100%" }}
            animate={{ y: 0 }}
            exit={{ y: "100%" }}
            transition={{ type: "spring", damping: 25, stiffness: 200 }}
            className="absolute bottom-0 left-0 right-0 max-h-[85dvh] bg-[#121214] z-[60] rounded-t-[2.5rem] flex flex-col border-t border-white/10 shadow-2xl overflow-hidden"
          >
            <div className="w-full flex justify-center pt-4 pb-2" onClick={onClose}>
              <div className="w-12 h-1.5 bg-gray-600 rounded-full" />
            </div>

            {/* HEADER */}
            <div className="px-6 py-4 flex items-center border-b border-white/5 gap-4">
               {view !== 'menu' && (
                   <button onClick={() => setView('menu')} className="p-2 -ml-2 rounded-full hover:bg-white/10 text-white transition">
                       <ChevronLeft size={24} />
                   </button>
               )}

               {view === 'menu' ? (
                   <>
                        <img src={track.cover} className="w-14 h-14 rounded-xl object-cover shadow-lg bg-gray-800" alt="Cover" />
                        <div className="flex-1 min-w-0">
                            <h3 className="text-lg font-bold text-white truncate">{track.title}</h3>
                            <p className="text-sm text-gray-400 truncate">{track.artist}</p>
                        </div>
                   </>
               ) : (
                   <div className="flex-1 text-center font-bold text-lg text-white">
                       {view === 'playlists' && t('header_add_playlist')}
                       {view === 'create' && t('header_new_playlist')}
                       {view === 'sleep' && t('sleep_timer')}
                   </div>
               )}

               <button onClick={onClose} className="p-2 bg-white/10 rounded-full text-white hover:bg-white/20 transition ml-auto">
                 <X size={20} />
               </button>
            </div>

            {/* CONTENT */}
            <div className="flex-1 overflow-y-auto p-2 custom-scrollbar min-h-[300px] relative">
              
              {/* --- VIEW: MENU --- */}
              {view === 'menu' && (
                  <div className="flex flex-col gap-1 p-2">
                    
                    <MenuItem 
                        icon={Send} 
                        label={t('action_send_tg')} 
                        onClick={handleSendToChat}
                    />

                    <div className="h-px bg-white/10 my-2 mx-4" />

                    <MenuItem 
                        icon={ListPlus} 
                        label={t('action_add_playlist')}
                        onClick={() => {
                          setView('playlists');
                          loadPlaylists();
                        }} 
                    />
                    
                    <MenuItem 
                        icon={Heart} 
                        label={isLiked ? t('action_unlike') : t('action_like')}
                        active={isLiked}
                        activeColor="text-purple-500"
                        activeIconFill="currentColor"
                        onClick={() => toggleFavorite(track)} 
                    />
                    
                    <MenuItem icon={Share2} label={t('action_share')} onClick={handleShare} />
                    <MenuItem icon={Radio} label={t('action_radio')} onClick={handleRadio} />

                    <div className="h-px bg-white/10 my-2 mx-4" />

                    <MenuItem
                        icon={Moon}
                        label={
                          sleepRemaining != null
                            ? `${t('sleep_timer')}: ${formatSleep(sleepRemaining)}`
                            : t('sleep_timer')
                        }
                        active={sleepRemaining != null}
                        activeColor="text-purple-400"
                        onClick={() => setView('sleep')}
                    />
                  </div>
              )}

              {view === 'sleep' && (
                  <div className="flex flex-col gap-4 p-4">
                      {sleepRemaining != null && (
                          <div className="text-center py-2">
                              <p className="text-purple-400 text-sm font-medium">{t('sleep_timer_active')}</p>
                              <p className="text-white text-3xl font-bold mt-1 tabular-nums">{formatSleep(sleepRemaining)}</p>
                          </div>
                      )}
                      <p className="text-gray-400 text-sm text-center">
                          {t('sleep_timer_desc')}
                      </p>
                      <div className="grid grid-cols-3 gap-2">
                          {[15, 30, 60].map((m) => (
                              <button
                                  key={m}
                                  type="button"
                                  onClick={() => onStartSleepTimer?.(m)}
                                  className="py-3 bg-purple-600 text-white rounded-xl text-sm font-bold hover:bg-purple-500 active:scale-95 transition"
                              >
                                  {m} {t('minutes')}
                              </button>
                          ))}
                      </div>
                      {sleepRemaining != null && (
                          <button
                              type="button"
                              onClick={() => {
                                  onCancelSleepTimer?.();
                                  setView('menu');
                              }}
                              className="w-full py-3 bg-white/10 text-white rounded-xl text-sm font-medium hover:bg-white/15 transition"
                          >
                              {t('sleep_timer_cancel')}
                          </button>
                      )}
                  </div>
              )}

              {/* --- VIEW: PLAYLISTS --- */}
              {view === 'playlists' && (
                  <div className="flex flex-col gap-2 p-2">
                      <button onClick={() => setView('create')} className="flex items-center gap-4 p-4 rounded-xl transition-all active:scale-98 hover:bg-white/10 bg-white/5 text-white mb-2">
                          <div className="w-10 h-10 rounded-full bg-purple-600 flex items-center justify-center"><Plus size={24} /></div>
                          <span className="font-medium text-base">{t('new_playlist')}</span>
                      </button>

                      {isLoadingPlaylists ? (
                          <div className="flex justify-center py-10 text-purple-500"><Loader2 className="animate-spin" size={32} /></div>
                      ) : playlists.length === 0 ? (
                          <div className="text-center text-gray-500 py-10">{t('no_playlists_short')}</div>
                      ) : (
                          playlists.map(pl => (
                              <button key={pl.id} onClick={() => handleAddToPlaylist(pl.id)} className="flex items-center gap-4 p-3 rounded-xl hover:bg-white/5 transition-all active:scale-98">
                                  <div className="w-12 h-12 rounded-lg bg-gray-800 overflow-hidden">
                                      {pl.cover ? <img src={pl.cover} className="w-full h-full object-cover" /> : <ListPlus className="w-full h-full p-3 text-gray-500" />}
                                  </div>
                                  <div className="text-left flex-1 min-w-0">
                                      <div className="text-white font-medium truncate">{pl.title}</div>
                                      <div className="text-gray-400 text-xs">{pl.type || 'Playlist'}</div>
                                  </div>
                              </button>
                          ))
                      )}
                  </div>
              )}

              {/* --- VIEW: CREATE --- */}
              {view === 'create' && (
                  <div className="flex flex-col gap-4 p-4">
                      <div className="text-gray-400 text-sm text-center mb-2">{t('hint_enter_name')}</div>
                      <input autoFocus type="text" placeholder={t('playlist_name_placeholder')} value={newPlaylistTitle} onChange={(e) => setNewPlaylistTitle(e.target.value)} className="w-full bg-[#2A2A2A] text-white px-4 py-4 rounded-2xl outline-none focus:ring-2 focus:ring-purple-500 text-lg" />
                      <button disabled={!newPlaylistTitle.trim() || isCreating} onClick={handleCreateAndAdd} className="mt-4 w-full py-4 rounded-2xl bg-purple-600 text-white font-bold text-lg hover:bg-purple-500 active:scale-95 transition disabled:opacity-50 disabled:scale-100 flex items-center justify-center gap-2">
                          {isCreating ? <Loader2 className="animate-spin" /> : <Check />} {t('btn_create')}
                      </button>
                  </div>
              )}

            </div>

            <AnimatePresence>
                {toastMessage && (
                    <motion.div 
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: 20 }}
                        className="absolute bottom-6 left-0 right-0 flex justify-center pointer-events-none z-50"
                    >
                        <div className={`px-4 py-2 rounded-full shadow-2xl flex items-center gap-2 text-sm font-bold ${
                            isSuccess ? 'bg-green-500 text-black' : 'bg-red-500 text-white'
                        }`}>
                            {isSuccess ? <Check size={16} strokeWidth={3} /> : <X size={16} strokeWidth={3} />}
                            {toastMessage}
                        </div>
                    </motion.div>
                )}
            </AnimatePresence>

          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}

function MenuItem({ icon: Icon, label, danger, onClick, active, activeColor, activeIconFill }) {
    return (
        <button 
            onClick={onClick}
            className={`w-full flex items-center gap-4 p-4 rounded-xl transition-all active:scale-98 text-left ${
                danger 
                ? 'hover:bg-red-500/10 text-red-400' 
                : active 
                    ? activeColor 
                    : 'hover:bg-white/5 text-gray-200'
            }`}
        >
            <Icon 
                size={22} 
                strokeWidth={danger ? 2 : 1.5} 
                fill={active && activeIconFill ? activeIconFill : "none"} 
                className="flex-shrink-0"
            />
            <span className="font-medium text-sm sm:text-base leading-tight">{label}</span>
        </button>
    );
}