import { ChevronDown, MoreVertical } from 'lucide-react'; // Змінив іконку на MoreVertical (стандарт Android/Web)

export default function Header({ onMenuClick }) {
  return (
    <div className="w-full z-10 flex justify-between items-center px-6 pt-6 pb-2 min-h-[60px]">
      {/* Кнопка згортання (поки декоративна) */}
      <button className="p-2 opacity-50 hover:opacity-100 transition hover:bg-white/10 rounded-full">
        <ChevronDown size={28} />
      </button>

      {/* Інформація про джерело */}
      <div className="flex flex-col items-center">
          <span className="text-[10px] font-bold tracking-[0.2em] uppercase text-white/60">Зараз грає</span>
          <span className="text-xs font-bold text-white shadow-glow">Мій плейліст</span>
      </div>

      {/* Кнопка меню 3 крапки */}
      <button 
        onClick={onMenuClick}
        className="p-2 opacity-70 hover:opacity-100 transition hover:bg-white/10 rounded-full active:scale-90"
      >
         <MoreVertical size={24} />
      </button>
    </div>
  );
}