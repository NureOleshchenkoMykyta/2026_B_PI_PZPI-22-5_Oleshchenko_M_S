import React, { useState, useEffect, useRef, lazy, Suspense } from 'react';
import { AnimatePresence } from 'framer-motion';
import { Home, Search, Library, Compass, ListMusic, ChevronLeft } from 'lucide-react';
import { Routes, Route, useNavigate, useLocation } from 'react-router-dom';

// Context
import { SearchProvider, useSearch } from './context/SearchContext';
import { FavoritesProvider } from './context/FavoritesContext';
import { LanguageProvider, useLanguage } from './context/LanguageContext';
import TopBar from './components/Shared/TopBar';
// Hooks
import { useAudioPlayer } from './hooks/useAudioPlayer';

// Components
import MiniPlayer from './components/Dashboard/MiniPlayer';
import SearchResults from './components/Search/SearchResults';
import OptionsMenu from './components/UI/OptionsMenu'; 
import PageLoader from './components/UI/PageLoader';

// Lazy Components
const GenrePage = lazy(() => import('./components/GenrePage'));
const AlbumPage = lazy(() => import('./components/AlbumPage'));
const ArtistPage = lazy(() => import('./components/ArtistPage'));
const UserProfilePage = lazy(() => import('./components/UserProfilePage'));
const OnboardingModal = lazy(() => import('./components/OnboardingModal'));
const FullScreenPlayer = lazy(() => import('./components/Player/FullScreenPlayer'));
const LibraryPage = lazy(() => import('./components/Library/Library'));
const PlaylistsPage = lazy(() => import('./components/Playlists/CompilationsView'));
const PlaylistDetails = lazy(() => import('./components/Playlists/PlaylistDetails'));
const OverviewPage = lazy(() => import('./components/Overview/OverviewPage'));
const HomeView = lazy(() => import('./components/Home/HomeView'));

import { apiClient, API_BASE_URL } from './config';

// === ГЛОБАЛЬНИЙ КЕШ URL ===
const TRACK_URL_CACHE = new Map();



async function getTrackUrlOrFetch(trackId) {
    if (!trackId) return null;
    const idKey = String(trackId).trim();

    // 1. Спочатку перевіряємо кеш в пам'яті
    if (TRACK_URL_CACHE.has(idKey)) {
        return TRACK_URL_CACHE.get(idKey);
    }

    console.log(`🌐 [API] Запит треку ${idKey}...`);
    
    const maxAttempts = 20; 
    let attempts = 0;

    while (attempts < maxAttempts) {
        try {
            const response = await apiClient.get(`/api/track/${idKey}`);
            
            // JSON response
            if (response.status === 200 && response.headers['content-type']?.includes('application/json')) {
                const data = response.data;
                
                // Direct R2 URL
                if (data.url) {
                    console.log("✅ [API] R2 URL:", data.url);
                    TRACK_URL_CACHE.set(idKey, data.url);
                    return data.url;
                }
                
                // Stream URL or ready status
                if (data.stream_url || data.status === 'ready') {
                      console.log("⚠️ [API] Stream Ready (JSON)");
                      const finalUrl = data.stream_url || `${API_BASE_URL}/api/track/${idKey}`;
                      TRACK_URL_CACHE.set(idKey, finalUrl);
                      return finalUrl;
                }
            } 
            
            // Binary stream response
            else if (response.status === 200) {
                 console.log("⚠️ [API] Stream Direct (Binary)");
                 const streamUrl = `${API_BASE_URL}/api/track/${idKey}`;
                 TRACK_URL_CACHE.set(idKey, streamUrl);
                 return streamUrl;
            }

            // Still processing (202)
            if (response.status === 202) {
                const ra = Number(response.data?.retry_after);
                const delayMs = Number.isFinite(ra)
                  ? Math.min(10000, Math.max(1000, ra * 1000))
                  : 3000;
                console.log(`⏳ [API] Трек обробляється (Спроба ${attempts + 1}/${maxAttempts}), pause ${delayMs}ms...`);
                await new Promise(resolve => setTimeout(resolve, delayMs));
                attempts++;
                continue;
            }
            
            console.warn("⚠️ [API] Невідомий формат відповіді 200 OK, чекаємо...");
            await new Promise(resolve => setTimeout(resolve, 3000));
            attempts++;

        } catch (error) {
            // Якщо 202 приходить як помилка (іноді буває в axios)
            if (error.response && error.response.status === 202) {
                 const ra = Number(error.response.data?.retry_after);
                 const delayMs = Number.isFinite(ra)
                   ? Math.min(10000, Math.max(1000, ra * 1000))
                   : 3000;
                 console.log(`⏳ [API] Трек обробляється (Catch 202), pause ${delayMs}ms...`);
                 await new Promise(resolve => setTimeout(resolve, delayMs));
                 attempts++;
                 continue;
            }
            
            console.warn("Помилка отримання треку:", error);
            await new Promise(resolve => setTimeout(resolve, 3000));
            attempts++;
        }
    }
    
    console.error("❌ Timeout: Не вдалося отримати трек.");
    return null;
}

function AppContent() {
  const player = useAudioPlayer([]); 
  const { t, isLoading: isLangLoading } = useLanguage();
  const navigate = useNavigate();
  const location = useLocation();

  const preloadingRef = useRef(new Set());

  const [isPlayerOpen, setIsPlayerOpen] = useState(false);
  const [isOptionsMenuOpen, setIsOptionsMenuOpen] = useState(false);
  const [isDownloading, setIsDownloading] = useState(false);
  const [selectedPlaylist, setSelectedPlaylist] = useState(null);
  const [showOnboarding, setShowOnboarding] = useState(false);
  const [sleepMinutes, setSleepMinutes] = useState(null);
  const [sleepRemaining, setSleepRemaining] = useState(null);
  const togglePlayRef = useRef(player.togglePlay);
  const isPlayingRef = useRef(player.isPlaying);
  togglePlayRef.current = player.togglePlay;
  isPlayingRef.current = player.isPlaying;

  const { isSearchOpen, closeSearch } = useSearch();

  useEffect(() => {
    if (!sleepMinutes) {
      setSleepRemaining(null);
      return;
    }
    setSleepRemaining(sleepMinutes * 60);
    const interval = setInterval(() => {
      setSleepRemaining((prev) => {
        if (prev == null || prev <= 1) {
          clearInterval(interval);
          if (isPlayingRef.current) togglePlayRef.current();
          setSleepMinutes(null);
          return null;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(interval);
  }, [sleepMinutes]);

  useEffect(() => {
    const checkOnboarding = async () => {
      try {
        const res = await apiClient.get('/api/user/me');
        if (res.data && !res.data.onboarding_completed) {
          setShowOnboarding(true);
        }
      } catch {
        /* ignore */
      }
    };
    checkOnboarding();
  }, []);

  useEffect(() => {
    const onUnauthorized = () => {
      closeSearch();
      setSelectedPlaylist(null);
      navigate('/', { replace: true });
    };
    window.addEventListener('hydra:unauthorized', onUnauthorized);
    return () => window.removeEventListener('hydra:unauthorized', onUnauthorized);
  }, [closeSearch, navigate]);
  
  

  useEffect(() => {
    const handleDeepLinks = async () => {
      const path = window.location.pathname;

      // 1. ТРЕК
      if (path.startsWith('/track/')) {
        const trackId = path.split('/')[2];
        if (trackId) {
          const trackData = {
            id: trackId,
            source_id: trackId,
            title: "Loading...",
            artist: "Shared Track",
            cover: `https://img.youtube.com/vi/${trackId}/mqdefault.jpg`
          };
          handlePlayContext(trackData);
        }
      }

      // 2. ПЛЕЙЛИСТ
      if (path.startsWith('/playlist/')) {
        const playlistId = path.split('/')[2];
        if (playlistId) {
          try {
            const res = await apiClient.get(`/api/library/playlists/${playlistId}`);
            if (res.data) {
              setSelectedPlaylist(res.data);
            }
          } catch (error) {
            console.error("Shared playlist not found:", error);
          }
        }
      }
    };

    handleDeepLinks();
    // handlePlayContext стабільно не виноситься в deps без великого рефактору player
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // === SMART PRELOAD & UPDATE ===
  // Поточний трек і наступний префетч з воркерами не блокуємо один одного — інакше наступний чекає,
  // поки весь цикл 202/polling завершиться для поточного.
  useEffect(() => {
    const manageDownloads = () => {
        const { track, currentIndex, currentPlaylist } = player;
        if (!track || !currentPlaylist || currentPlaylist.length === 0) return;

        const trackId = track.id || track.source_id;
        const idStr = String(trackId);

        // А. ПОТОЧНИЙ ТРЕК (паралельно з префетчем наступного)
        const isCurrentValid =
          track.r2_url && !track.r2_url.includes("youtube.com");

        if (!isCurrentValid && !preloadingRef.current.has(idStr)) {
          if (!TRACK_URL_CACHE.has(idStr)) setIsDownloading(true);

          preloadingRef.current.add(idStr);
          void (async () => {
            try {
              const url = await getTrackUrlOrFetch(trackId);
              if (url) {
                player.updateTrack(currentIndex, {
                  ...track,
                  r2_url: url,
                  url: url,
                  source: "r2",
                });
              }
            } finally {
              setIsDownloading(false);
              preloadingRef.current.delete(idStr);
            }
          })();
        }

        // Б. НАСТУПНИЙ ТРЕК (PRELOAD) — одразу, не після поточного fetch
        if (currentPlaylist.length > 1) {
          const nextIdx = (currentIndex + 1) % currentPlaylist.length;
          const nextTrackItem = currentPlaylist[nextIdx];
          const nextId = nextTrackItem.id || nextTrackItem.source_id;
          const nextIdStr = String(nextId);

          const isNextValid =
            nextTrackItem.r2_url &&
            !nextTrackItem.r2_url.includes("youtube.com");

          if (!isNextValid && !preloadingRef.current.has(nextIdStr)) {
            if (!TRACK_URL_CACHE.has(nextIdStr)) {
              console.log(`🚀 [App] Preload наступного: ${nextTrackItem.title}`);
              preloadingRef.current.add(nextIdStr);

              getTrackUrlOrFetch(nextId)
                .then((url) => {
                  if (url) {
                    player.updateTrack(nextIdx, {
                      ...nextTrackItem,
                      r2_url: url,
                      url: url,
                      source: "r2",
                    });
                  }
                })
                .finally(() => {
                  preloadingRef.current.delete(nextIdStr);
                });
            } else {
              const cachedUrl = TRACK_URL_CACHE.get(nextIdStr);
              player.updateTrack(nextIdx, {
                ...nextTrackItem,
                r2_url: cachedUrl,
                url: cachedUrl,
                source: "r2",
              });
            }
          }
        }
    };
    manageDownloads();
    // eslint-disable-next-line react-hooks/exhaustive-deps -- цілеспрямовано лише на індекс/трек/довжину черги
  }, [player.currentIndex, player.track?.id, player.currentPlaylist?.length]);

  const handlePlayContext = async (track, contextList = [], index = 0, seekTo = null) => {
      console.log(`▶️ Запуск: ${track.title}`);
      let trackToPlay = track;
      const trackId = track.id || track.source_id;
      const idStr = String(trackId);

      const needsCheck = !track.r2_url || track.r2_url.includes("youtube.com");

      if (needsCheck) {
          if (!TRACK_URL_CACHE.has(idStr)) setIsDownloading(true);

          const r2Url = await getTrackUrlOrFetch(trackId);
          setIsDownloading(false);

          if (r2Url) {
              trackToPlay = { ...track, r2_url: r2Url, url: r2Url, source: 'r2' };
          } else {
              console.error("Не вдалося завантажити трек.");
              return;
          }
      }

      let finalList = contextList.length > 0 ? [...contextList] : [trackToPlay];
      if (contextList.length > 0) finalList[index] = trackToPlay;

      player.playNewContext(finalList, index, seekTo);
      setIsPlayerOpen(true);
  };

  const handlePlaylistSelection = (playlist) => {
    setSelectedPlaylist(playlist); 
    closeSearch();                 
  };
  
  const getActiveTab = () => {
      const path = location.pathname;
      if (path === '/') return 'home';
      if (path.startsWith('/overview') || path.startsWith('/genre') || path.startsWith('/album') || path.startsWith('/artist')) return 'overview';
      if (path.startsWith('/playlists')) return 'playlists';
      if (path.startsWith('/library')) return 'library';
      return '';
  };

  const currentTab = getActiveTab();

  if (isLangLoading) {
      return (
        <div className="w-full h-full bg-black flex items-center justify-center">
            <PageLoader />
        </div>
      );
  }

  return (
    <div className={`relative w-full h-[100dvh] bg-black text-white overflow-hidden font-sans flex flex-col ${isDownloading ? "cursor-wait" : ""}`}>
      
      {isDownloading && <div className="absolute top-0 w-full h-1 bg-purple-500 animate-pulse z-50"></div>}

      <div className={`flex-1 overflow-y-auto custom-scrollbar transition-transform duration-500 
    ${player.track && !isPlayerOpen ? 'pb-33' : 'pb-18'} 
    ${isPlayerOpen ? 'scale-95 opacity-50' : 'scale-100 opacity-100'}`}
>
        {!selectedPlaylist && <TopBar />}
        
        <Suspense fallback={<PageLoader />}>
            {isSearchOpen ? (
                <div className="w-full px-6">
                   <SearchResults onResultClick={(t) => handlePlayContext(t)} />
                </div>
            ) : selectedPlaylist ? (
                   <PlaylistDetails 
                       playlist={selectedPlaylist} 
                       onBack={() => {
                           setSelectedPlaylist(null);
                           // Додаємо перехід на головну, щоб скинути URL /playlist/:id
                           if (window.location.pathname.startsWith('/playlist/')) {
                               navigate('/');
                           }
                       }}
                       onPlayTrack={(track, tracks, idx) => handlePlayContext(track, tracks, idx)}
                   />
            ) : (
                   <div className="w-full">
                       <Routes>
                            <Route path="/" element={
                                <HomeView 
                                    onTrackSelect={(track, list) => handlePlayContext(track, list)}
                                    onTabChange={(tab) => {
                                        if (tab === 'liked') {
                                            // Передаємо state, щоб Library.jsx знала, що треба відкрити вкладку "liked"
                                            navigate('/library', { state: { view: 'liked' } });
                                        } else {
                                            navigate('/' + tab);
                                        }
                                    }}
                                    onPlaylistSelect={handlePlaylistSelection}
                                    hasPlayer={!!player.track}
                                />
                            } />
                            
                            
                            <Route path="/track/:id" element={
                                <HomeView 
                                    onTrackSelect={(track, list) => handlePlayContext(track, list)}
                                    onTabChange={(tab) => {
                                        if (tab === 'liked') navigate('/library');
                                        else navigate('/' + tab);
                                    }}
                                    onPlaylistSelect={handlePlaylistSelection}
                                    hasPlayer={!!player.track}
                                />
                            } />

                            <Route path="/playlist/:id" element={
                                <HomeView 
                                    onTrackSelect={(track, list) => handlePlayContext(track, list)}
                                    onTabChange={(tab) => {
                                        if (tab === 'liked') navigate('/library');
                                        else navigate('/' + tab);
                                    }}
                                    onPlaylistSelect={handlePlaylistSelection}
                                    hasPlayer={!!player.track}
                                />
                            } />
                          <Route 
                            path="/overview" 
                            element={
                                <OverviewPage 
                                    onTrackSelect={(t) => handlePlayContext(t)} 
                                    onPlaylistSelect={handlePlaylistSelection}
                                />
                            } 
                        />
                           <Route path="/playlists" element={<PlaylistsPage onPlaylistClick={handlePlaylistSelection} />} />
                           <Route path="/library" element={<LibraryPage onTrackSelect={handlePlayContext} onPlaylistClick={handlePlaylistSelection} />} />
                           
                           <Route 
                            path="/genre/:id" 
                            element={
                                <GenrePage 
                                onTrackSelect={(track, list, idx) => handlePlayContext(track, list, idx ?? 0)} 
                                />
                            } 
                            />
                           <Route 
                            path="/album/:id" 
                            element={
                                <AlbumPage 
                                onTrackSelect={(track, list, idx) => handlePlayContext(track, list, idx ?? 0)} 
                                />
                            } 
                            />
                           <Route 
                            path="/artist/:id" 
                            element={
                                <ArtistPage 
                                onTrackSelect={(track, list, idx) => handlePlayContext(track, list, idx ?? 0)} 
                                />
                            } 
                            />
                           <Route 
                            path="/user/:id" 
                            element={
                                <UserProfilePage onPlaylistSelect={handlePlaylistSelection} />
                            } 
                            />
                       </Routes>
                   </div>
            )}
        </Suspense>
      </div>
      
      <AnimatePresence>
        {!isPlayerOpen && player.track && (
          <MiniPlayer 
            track={player.track} 
            isPlaying={player.isPlaying} 
            onPlayPause={player.togglePlay}
            onExpand={() => setIsPlayerOpen(true)}
            progress={player.progress}
            duration={player.duration}
            onSeek={player.seek}
          />
        )}
      </AnimatePresence>

      <div className="fixed bottom-0 left-0 right-0 h-[80px] bg-[#121212] border-t border-white/5 flex justify-around items-center z-40 pb-2">
         <div onClick={() => { navigate('/'); closeSearch(); setSelectedPlaylist(null); }} className={`flex flex-col items-center gap-1.5 cursor-pointer ${currentTab === 'home' ? 'text-white' : 'text-[#888]'}`}>
             <Home size={24} />
             <span className="text-[10px] capitalize">{t('nav_home')}</span>
         </div>
         
         <div onClick={() => { navigate('/overview'); closeSearch(); setSelectedPlaylist(null); }} className={`flex flex-col items-center gap-1.5 cursor-pointer ${currentTab === 'overview' ? 'text-white' : 'text-[#888]'}`}>
             <Compass size={24} />
             <span className="text-[10px] capitalize">{t('nav_overview')}</span>
         </div>

         <div onClick={() => { navigate('/playlists'); closeSearch(); setSelectedPlaylist(null); }} className={`flex flex-col items-center gap-1.5 cursor-pointer ${currentTab === 'playlists' ? 'text-white' : 'text-[#888]'}`}>
             <ListMusic size={24} />
             <span className="text-[10px] capitalize">{t('nav_playlists')}</span>
         </div>

         <div onClick={() => { navigate('/library'); closeSearch(); setSelectedPlaylist(null); }} className={`flex flex-col items-center gap-1.5 cursor-pointer ${currentTab === 'library' ? 'text-white' : 'text-[#888]'}`}>
             <Library size={24} />
             <span className="text-[10px] capitalize">{t('nav_library')}</span>
         </div>
      </div>

        {/* --- SHARED PLAYLIST OVERLAY --- */}
      
      <AnimatePresence>
        {isPlayerOpen && (
            <FullScreenPlayer 
                player={player}
                selectedPlaylist={selectedPlaylist}
                onClose={() => setIsPlayerOpen(false)}
                onOpenOptions={() => setIsOptionsMenuOpen(true)}
                sleepRemaining={sleepRemaining}
            />
        )}
      </AnimatePresence>

      {player.track && (
        <OptionsMenu 
            key={`opt-${isOptionsMenuOpen ? '1' : '0'}-${player.track.id || player.track.source_id}`}
            isOpen={isOptionsMenuOpen} 
            onClose={() => setIsOptionsMenuOpen(false)} 
            track={player.track} 
            onPlayRadio={(tracks) => {
                handlePlayContext(tracks[0], tracks, 0);
            }}
            sleepRemaining={sleepRemaining}
            onStartSleepTimer={(minutes) => {
                setSleepMinutes(minutes);
                setIsOptionsMenuOpen(false);
            }}
            onCancelSleepTimer={() => setSleepMinutes(null)}
        />
      )}

      {showOnboarding && (
        <Suspense fallback={null}>
          <OnboardingModal onComplete={() => setShowOnboarding(false)} />
        </Suspense>
      )}
    </div>
  );
}

export default function App() {
  return (
    <FavoritesProvider>
        <SearchProvider>
            <LanguageProvider>
                <AppContent />
            </LanguageProvider>
        </SearchProvider>
    </FavoritesProvider>
  );
}