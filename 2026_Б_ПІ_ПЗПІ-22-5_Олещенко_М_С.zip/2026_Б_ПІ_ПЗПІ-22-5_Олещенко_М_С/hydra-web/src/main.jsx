import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App.jsx'
import './index.css'

if (typeof window !== 'undefined' && window.Telegram?.WebApp) {
  window.Telegram.WebApp.ready()
  window.Telegram.WebApp.expand?.()
}
import { SearchProvider } from './context/SearchContext.jsx';
import { FavoritesProvider } from './context/FavoritesContext.jsx';
import { LanguageProvider } from './context/LanguageContext.jsx'; // 1. Додайте імпорт
import { BrowserRouter } from 'react-router-dom' 

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <LanguageProvider> {/* 2. Обгорніть найвище (або всередині інших, головне щоб було) */}
      <SearchProvider>
        <FavoritesProvider>
          <BrowserRouter>
            <App />
          </BrowserRouter>
        </FavoritesProvider>
      </SearchProvider>
    </LanguageProvider>
  </React.StrictMode>,
)