import React, { createContext, useContext, useState, useEffect } from 'react';
import { apiClient } from '../config';
import defaultEn from '../locales/en'; // Імпортуємо англійську як гарантований запас

const LanguageContext = createContext();

export const AVAILABLE_LANGUAGES = [
    { code: 'en', label: 'English', flag: '🇺🇸' },
    { code: 'uk', label: 'Українська', flag: '🇺🇦' },
    { code: 'de', label: 'Deutsch', flag: '🇩🇪' },
];

function normalizeLanguageFromServer(code) {
    if (!code || typeof code !== 'string') return 'en';
    if (code === 'ru') return 'uk';
    const allowed = new Set(AVAILABLE_LANGUAGES.map((l) => l.code));
    return allowed.has(code) ? code : 'en';
}

export function LanguageProvider({ children }) {
    const [language, setLanguage] = useState('en');
    // Починаємо одразу з англійської, щоб не було "пустих" ключів
    const [translations, setTranslations] = useState(defaultEn); 
    const [isLoading, setIsLoading] = useState(true);

    const loadLanguage = async (langCode) => {
        setIsLoading(true);
        try {
            let messages;
            
            if (langCode === 'en') {
                messages = defaultEn;
            } else {
                try {
                    // Vite вимагає, щоб динамічний імпорт мав розширення явно
                    const module = await import(`../locales/${langCode}.js`);
                    messages = module.default;
                } catch {
                    console.warn(`⚠️ Файл перекладу ../locales/${langCode}.js не знайдено. Використовую English.`);
                    messages = defaultEn;
                }
            }

            setTranslations(messages);
            setLanguage(langCode);
        } catch (error) {
            console.error("Critical language load error:", error);
            setTranslations(defaultEn);
        } finally {
            setIsLoading(false);
        }
    };

    // При старті: питаємо API
    useEffect(() => {
        const initLanguage = async () => {
            try {
                const res = await apiClient.get('/api/user/me');
                const raw = res.data.language || 'en';
                const userLang = normalizeLanguageFromServer(raw);
                await loadLanguage(userLang);
                if (raw === 'ru' && userLang === 'uk') {
                    try {
                        await apiClient.patch('/api/user/settings', { language: 'uk' });
                    } catch {
                        /* ignore */
                    }
                }
            } catch (e) {
                console.error("Failed to fetch user language", e);
                // Якщо API впало - просто залишаємося на EN (який вже встановлено в useState)
                setIsLoading(false);
            }
        };
        initLanguage();
    }, []);

    const changeLanguage = async (newLang) => {
        await loadLanguage(newLang);
        try {
            await apiClient.patch('/api/user/settings', { language: newLang });
        } catch (e) {
            console.error("Failed to save language preference", e);
        }
    };

    const t = (key) => {
        return translations[key] || key;
    };

    return (
        <LanguageContext.Provider value={{ t, language, changeLanguage, isLoading }}>
            {children}
        </LanguageContext.Provider>
    );
}

export const useLanguage = () => useContext(LanguageContext);