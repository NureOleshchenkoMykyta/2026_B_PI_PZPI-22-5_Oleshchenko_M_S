"""Single background loop to prune old files under the downloads directory."""
import asyncio
import logging
import os
import time

logger = logging.getLogger(__name__)

DOWNLOAD_DIR = "/app/downloads"
MAX_AGE_SECONDS = 3600
SLEEP_SECONDS = 600


async def downloads_cleanup_loop() -> None:
    while True:
        try:
            if not os.path.exists(DOWNLOAD_DIR):
                os.makedirs(DOWNLOAD_DIR, exist_ok=True)
            now = time.time()
            for filename in os.listdir(DOWNLOAD_DIR):
                file_path = os.path.join(DOWNLOAD_DIR, filename)
                if not os.path.isfile(file_path):
                    continue
                if now - os.path.getmtime(file_path) <= MAX_AGE_SECONDS:
                    continue
                try:
                    os.remove(file_path)
                    logger.info("Removed stale download file: %s", filename)
                except OSError as e:
                    logger.error("Failed to remove %s: %s", filename, e)
        except Exception:
            logger.exception("Downloads cleanup iteration failed")
        await asyncio.sleep(SLEEP_SECONDS)
