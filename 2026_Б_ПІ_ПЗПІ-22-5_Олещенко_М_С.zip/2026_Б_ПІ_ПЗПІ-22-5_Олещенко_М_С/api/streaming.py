import os
import mimetypes
import asyncio
import logging
from typing import BinaryIO, Optional
from fastapi import APIRouter, Request, Depends, HTTPException, status, Header
from fastapi.responses import StreamingResponse, FileResponse, RedirectResponse
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select

from common.database import get_db
from common.models import Track, User, AccountTier
from common.config import settings
from common.redis_client import redis_client
from common.schemas import DownloadTask
from api.deps import get_current_user

logger = logging.getLogger(__name__)

router = APIRouter()

def send_bytes_range_requests(
    file_obj: BinaryIO, start: int, end: int, chunk_size: int = 10_000
):
    """Функція-генератор для читання файлу шматками для підтримки перемотки."""
    with file_obj as f:
        f.seek(start)
        while (pos := f.tell()) <= end:
            read_size = min(chunk_size, end + 1 - pos)
            yield f.read(read_size)

def _get_range_header(range_header: str, file_size: int) -> tuple[int, int]:
    """Парсинг HTTP заголовка Range."""
    if not range_header:
        return 0, file_size - 1
    
    try:
        unit, ranges = range_header.strip().split("=")
        if unit != "bytes":
            return 0, file_size - 1
        
        start_str, end_str = ranges.split("-")
        start = int(start_str)
        end = int(end_str) if end_str else file_size - 1
            
        if start >= file_size:
            return 0, file_size - 1
            
        return start, min(end, file_size - 1)
    except ValueError:
        return 0, file_size - 1

def range_requests_response(
    request: Request, file_path: str, content_type: str = "audio/mp4"
):
    """Створює StreamingResponse з підтримкою Partial Content (206) для перемотки."""
    if not os.path.exists(file_path):
        raise HTTPException(status_code=404, detail="File not found")

    file_size = os.path.getsize(file_path)
    range_header = request.headers.get("range")

    start, end = _get_range_header(range_header, file_size)
    content_length = (end - start) + 1

    status_code = status.HTTP_206_PARTIAL_CONTENT if range_header else status.HTTP_200_OK

    headers = {
        "Content-Range": f"bytes {start}-{end}/{file_size}",
        "Accept-Ranges": "bytes",
        "Content-Length": str(content_length),
        "Content-Type": content_type,
        "Cache-Control": "public, max-age=3600"
    }

    return StreamingResponse(
        send_bytes_range_requests(open(file_path, "rb"), start, end),
        status_code=status_code,
        headers=headers,
        media_type=content_type,
    )

@router.get("/track/{source_id}")
async def stream_track(
    source_id: str, 
    request: Request,
    db: AsyncSession = Depends(get_db),
    user_id: int = Depends(get_current_user) # Тепер тут приходить int
):

    result = await db.execute(select(User).where(User.user_id == user_id))
    current_user = result.scalar_one_or_none()

    if not current_user:
        current_user = User(user_id=user_id, tier=AccountTier.FREE) 

    local_filename = f"{source_id}.m4a"
    local_path = os.path.join("downloads", local_filename)

    # Premium: serve from local file when available
    if current_user.tier == AccountTier.PREMIUM:
        # Стрімінг напряму з сервера, якщо файл існує (навіть якщо ще качається)
        if os.path.exists(local_path) and os.path.getsize(local_path) > 1024:
            logger.info("Premium stream from server: %s", source_id)
            return range_requests_response(request, file_path=local_path)
        
        # Якщо файлу немає на сервері, ігноруємо R2 для Premium і штовхаємо воркера
        # (Завантаження на сервер -> фон: Telegram)
    
    # Lookup track in database
    result = await db.execute(select(Track).where(Track.source_id == source_id))
    track = result.scalar_one_or_none()

    # Free tier or premium file not ready yet: redirect to R2 if cached
    if track and track.r2_url:
        logger.info("Redirecting to R2: %s", source_id)
        return RedirectResponse(url=track.r2_url)

    # Queue worker if track is not cached anywhere
    lock_key = f"stream_init:{source_id}"
    is_pushed = await redis_client.redis.get(lock_key)

    if not is_pushed:
        # Формуємо задачу для воркера згідно зі схемою
        task = DownloadTask(
            query=f"dl_id:{source_id}",
            user_id=current_user.user_id,
            chat_id=current_user.user_id,
            is_interface=True
        )
        await redis_client.push_task(task)
        await redis_client.redis.set(lock_key, "1", ex=45) # Замок на 45 сек
        logger.info("Worker triggered for stream init: %s", source_id)

    # Повертаємо 202, фронтенд робить поллінг кожні 2-3 секунди
    raise HTTPException(
        status_code=status.HTTP_202_ACCEPTED, 
        detail="Track is being prepared (Streaming/R2 Logic applied)."
    )