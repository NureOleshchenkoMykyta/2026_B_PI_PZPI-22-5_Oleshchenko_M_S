import logging

from fastapi import HTTPException

logger = logging.getLogger(__name__)


def raise_safe_500(log_event: str = "internal_error") -> None:
    """Call from an `except` block: logs traceback, returns generic 500 to client."""
    logger.exception("%s", log_event)
    raise HTTPException(status_code=500, detail="Internal server error") from None
