# Shared API service helpers (no FastAPI route definitions).
