import asyncio
import json
import logging
import re
from typing import Any, Optional

import httpx
import yt_dlp
from sqlalchemy import select
from sqlalchemy.dialects.postgresql import insert
from sqlalchemy.sql import func

from common.database import AsyncSessionLocal
from common.models import TrackLyrics
from common.redis_client import redis_client

logger = logging.getLogger(__name__)

LRCLIB_BASE = "https://lrclib.net/api"
USER_AGENT = "Hydra/1.0 (https://nikkme.online)"
LYRICS_CACHE_TTL = 86400 * 7
_LRC_TIME = re.compile(r"\[[\d:.]+\]\s*")


def _has_lrc_timestamps(text: str) -> bool:
    return bool(re.search(r"\[\d{1,2}:\d{2}", text or ""))


def _vtt_timestamp_to_lrc(hours: Optional[str], mins: str, secs: str, ms: str) -> str:
    total_m = int(hours or 0) * 60 + int(mins)
    frac = ms[:2] if len(ms) >= 2 else ms.ljust(2, "0")
    return f"{total_m:02d}:{secs}.{frac}"


def _vtt_to_lrc(raw: str) -> tuple[Optional[str], bool]:
    """Convert WebVTT to LRC; returns (text, is_synced)."""
    if "WEBVTT" not in raw[:30] and "-->" not in raw:
        return None, False

    lrc_lines: list[str] = []
    blocks = re.split(r"\n\s*\n", raw.replace("\r\n", "\n"))
    for block in blocks:
        if "-->" not in block:
            continue
        lines = [ln.strip() for ln in block.split("\n") if ln.strip()]
        if not lines:
            continue

        time_line = next((ln for ln in lines if "-->" in ln), None)
        if not time_line:
            continue

        start_part = time_line.split("-->")[0].strip()
        m = re.match(r"(\d{1,2}):(\d{2}):(\d{2})[.,](\d{3})", start_part)
        if m:
            lrc_tag = _vtt_timestamp_to_lrc(m.group(1), m.group(2), m.group(3), m.group(4))
        else:
            m = re.match(r"(\d{1,2}):(\d{2})[.,](\d{3})", start_part)
            if not m:
                continue
            lrc_tag = _vtt_timestamp_to_lrc(None, m.group(1), m.group(2), m.group(3))
        text_parts = []
        for ln in lines:
            if "-->" in ln or re.match(r"^\d+$", ln):
                continue
            if ln.startswith("WEBVTT") or ln.startswith("NOTE"):
                continue
            clean = re.sub(r"<[^>]+>", "", ln).strip()
            if clean:
                text_parts.append(clean)

        if text_parts:
            lrc_lines.append(f"[{lrc_tag}] {' '.join(text_parts)}")

    if lrc_lines:
        return "\n".join(lrc_lines), True

    plain_lines = []
    for line in raw.splitlines():
        line = line.strip()
        if not line or line.startswith("WEBVTT") or "-->" in line:
            continue
        if re.match(r"^\d+$", line):
            continue
        clean = re.sub(r"<[^>]+>", "", line)
        if clean:
            plain_lines.append(clean)
    text = "\n".join(dict.fromkeys(plain_lines))
    return (text or None), False


def _pick_lyrics(data: dict[str, Any]) -> tuple[Optional[str], bool]:
    synced = (data.get("syncedLyrics") or "").strip() or None
    plain = (data.get("plainLyrics") or "").strip() or None
    if synced:
        return synced, True
    if plain:
        return plain, False
    return None, False


def _normalize_title(title: str) -> str:
    t = title.strip()
    for suffix in (" (Official Video)", " (Official Audio)", " [Official Video]"):
        if t.endswith(suffix):
            t = t[: -len(suffix)]
    return t.strip()


async def _cache_get(key: str) -> Optional[dict]:
    raw = await redis_client.redis.get(key)
    if not raw:
        return None
    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        return None


async def _cache_set(key: str, payload: dict) -> None:
    await redis_client.redis.set(key, json.dumps(payload), ex=LYRICS_CACHE_TTL)


async def _db_get(source_id: str) -> Optional[dict]:
    try:
        async with AsyncSessionLocal() as session:
            row = await session.scalar(
                select(TrackLyrics).where(TrackLyrics.source_id == source_id)
            )
            if row and row.lyrics:
                return {
                    "lyrics": row.lyrics,
                    "synced": bool(row.synced),
                    "source": row.source,
                }
    except Exception as e:
        logger.warning("Lyrics DB read failed for %s: %s", source_id, e)
    return None


async def _db_save(
    source_id: str,
    title: str,
    artist: str,
    lyrics: str,
    synced: bool,
    source: Optional[str],
) -> None:
    try:
        async with AsyncSessionLocal() as session:
            stmt = insert(TrackLyrics).values(
                source_id=source_id,
                title=title.strip() or None,
                artist=artist.strip() or None,
                lyrics=lyrics,
                synced=synced,
                source=source,
            ).on_conflict_do_update(
                index_elements=["source_id"],
                set_={
                    "title": title.strip() or None,
                    "artist": artist.strip() or None,
                    "lyrics": lyrics,
                    "synced": synced,
                    "source": source,
                    "updated_at": func.now(),
                },
            )
            await session.execute(stmt)
            await session.commit()
    except Exception as e:
        logger.warning("Lyrics DB save failed for %s: %s", source_id, e)


async def _lrclib_request(
    client: httpx.AsyncClient,
    path: str,
    params: dict[str, Any],
    timeout: float,
) -> Optional[dict]:
    try:
        resp = await client.get(
            f"{LRCLIB_BASE}/{path}",
            params=params,
            headers={"User-Agent": USER_AGENT},
            timeout=timeout,
        )
        if resp.status_code == 200:
            return resp.json()
    except Exception as e:
        logger.debug("LRCLIB %s failed: %s", path, e)
    return None


async def _from_lrclib(
    title: str,
    artist: str,
    album: Optional[str],
    duration: Optional[int],
) -> Optional[dict]:
    track_name = _normalize_title(title)
    artist_name = artist.strip()
    album_name = (album or "").strip()

    async with httpx.AsyncClient(follow_redirects=True) as client:
        if duration:
            for path in ("get-cached", "get"):
                data = await _lrclib_request(
                    client,
                    path,
                    {
                        "track_name": track_name,
                        "artist_name": artist_name,
                        "album_name": album_name,
                        "duration": duration,
                    },
                    timeout=20.0 if path == "get-cached" else 45.0,
                )
                if data and not data.get("code"):
                    lyrics, synced = _pick_lyrics(data)
                    if lyrics:
                        return {"lyrics": lyrics, "synced": synced, "source": f"lrclib:{path}"}

        search = await _lrclib_request(
            client,
            "search",
            {"track_name": track_name, "artist_name": artist_name},
            timeout=25.0,
        )
        if isinstance(search, list):
            for item in search:
                lyrics, synced = _pick_lyrics(item)
                if lyrics:
                    return {"lyrics": lyrics, "synced": synced, "source": "lrclib:search"}

                item_id = item.get("id")
                if not item_id:
                    continue
                by_id = await _lrclib_request(
                    client, f"get/{item_id}", {}, timeout=15.0
                )
                if by_id:
                    lyrics, synced = _pick_lyrics(by_id)
                    if lyrics:
                        return {"lyrics": lyrics, "synced": synced, "source": "lrclib:id"}

    return None


def _youtube_captions_sync(video_id: str) -> tuple[Optional[str], bool]:
    url = f"https://www.youtube.com/watch?v={video_id}"
    ydl_opts = {
        "skip_download": True,
        "quiet": True,
        "no_warnings": True,
        "writesubtitles": False,
        "writeautomaticsub": False,
    }

    def _pick_lang(entries: dict) -> Optional[str]:
        for lang in ("en", "en-US", "en-GB", "uk", "ru"):
            if lang in entries and entries[lang]:
                return lang
        if entries:
            return next(iter(entries.keys()))
        return None

    try:
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            info = ydl.extract_info(url, download=False)
            if not info:
                return None, False

            manual = info.get("subtitles") or {}
            auto = info.get("automatic_captions") or {}
            lang = _pick_lang(manual) or _pick_lang(auto)
            if not lang:
                return None, False

            entries = manual.get(lang) or auto.get(lang) or []
            if not entries:
                return None, False

            sub_url = entries[0].get("url")
            if not sub_url:
                return None, False

            import urllib.request

            with urllib.request.urlopen(sub_url, timeout=20) as resp:
                raw = resp.read().decode("utf-8", errors="ignore")

            if "WEBVTT" in raw[:30] or "-->" in raw:
                lrc, synced = _vtt_to_lrc(raw)
                if lrc:
                    return (lrc, synced)

            text = _LRC_TIME.sub("", raw)
            text = re.sub(r"<[^>]+>", "", text)
            text = "\n".join(dict.fromkeys(l.strip() for l in text.splitlines() if l.strip()))
            return (text or None), _has_lrc_timestamps(text) if text else False
    except Exception as e:
        logger.debug("YouTube captions failed for %s: %s", video_id, e)
        return None, False


async def fetch_lyrics(
    track_id: str,
    title: str,
    artist: str,
    duration: Optional[int] = None,
    album: Optional[str] = None,
) -> dict:
    cache_key = f"lyrics:{track_id}"
    cached = await _cache_get(cache_key)
    if cached is not None:
        return {**cached, "track_id": track_id, "cached": True}

    db_hit = await _db_get(track_id)
    if db_hit:
        payload = {"track_id": track_id, **db_hit}
        await _cache_set(cache_key, payload)
        return {**payload, "cached": True, "stored": True}

    result = await _from_lrclib(title, artist, album, duration)
    if not result and track_id and len(track_id) == 11:
        yt_text, yt_synced = await asyncio.to_thread(_youtube_captions_sync, track_id)
        if yt_text:
            result = {
                "lyrics": yt_text,
                "synced": yt_synced,
                "source": "youtube_captions",
            }

    if result:
        payload = {
            "track_id": track_id,
            "lyrics": result["lyrics"],
            "synced": result["synced"],
            "source": result["source"],
        }
        await _cache_set(cache_key, payload)
        await _db_save(
            track_id,
            title,
            artist,
            result["lyrics"],
            result["synced"],
            result["source"],
        )
        return payload

    empty = {"track_id": track_id, "lyrics": None, "synced": False, "source": None}
    await redis_client.redis.set(cache_key, json.dumps(empty), ex=3600)
    return empty
