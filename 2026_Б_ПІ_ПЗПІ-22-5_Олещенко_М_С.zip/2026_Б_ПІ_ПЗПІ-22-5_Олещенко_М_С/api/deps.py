import hashlib
import hmac
import json
from typing import Optional
from urllib.parse import parse_qsl

from fastapi import Header, HTTPException, Request
from pydantic import SecretStr

from common.config import settings


def _telegram_user_id_from_init_data(init_data: str) -> int:
    """Validate Telegram Web App initData (HMAC-SHA256) and return user.id."""
    bot_token = (
        settings.BOT_TOKEN.get_secret_value()
        if isinstance(settings.BOT_TOKEN, SecretStr)
        else str(settings.BOT_TOKEN)
    )
    if not bot_token:
        raise ValueError("bot token not configured")

    parsed = dict(parse_qsl(init_data, keep_blank_values=True))
    received_hash = parsed.pop("hash", None)
    if not received_hash:
        raise ValueError("missing hash")

    data_check_string = "\n".join(f"{k}={v}" for k, v in sorted(parsed.items()))
    secret_key = hmac.new(
        b"WebAppData", bot_token.encode("utf-8"), hashlib.sha256
    ).digest()
    expected_hash = hmac.new(
        secret_key, data_check_string.encode("utf-8"), hashlib.sha256
    ).hexdigest()
    if not hmac.compare_digest(expected_hash, received_hash):
        raise ValueError("invalid hash")

    user_raw = parsed.get("user")
    if not user_raw:
        raise ValueError("missing user")
    user = json.loads(user_raw)
    uid = user.get("id")
    if uid is None:
        raise ValueError("missing user id")
    return int(uid)


def _host_from_request(request: Request) -> str:
    raw = (request.headers.get("host") or "").strip().lower()
    if not raw:
        return ""
    # [::1]:8080 vs 127.0.0.1:8005 vs localhost:8080
    if raw.startswith("["):
        end = raw.find("]")
        return raw[1:end] if end != -1 else raw
    return raw.split(":")[0]


def _auth_debug_trusted_hosts() -> frozenset[str]:
    hosts = {"localhost", "127.0.0.1", "::1"}
    for part in (settings.AUTH_DEBUG_HOSTS or "").split(","):
        host = part.strip().lower()
        if host:
            hosts.add(host)
    return frozenset(hosts)


def _is_trusted_debug_host(request: Request) -> bool:
    if not settings.AUTH_DEBUG:
        return False
    host = _host_from_request(request)
    return bool(host) and host in _auth_debug_trusted_hosts()


async def get_current_user(
    request: Request,
    telegram_data: Optional[str] = Header(None, alias="X-Telegram-Data"),
) -> int:
    """
    Resolve Telegram user id from WebApp initData in X-Telegram-Data.
    If AUTH_DEBUG=true: on trusted debug hosts (localhost + AUTH_DEBUG_HOSTS), missing header
    falls back to ADMIN_ID; a numeric header is accepted as user id for browser testing.
    """
    if settings.AUTH_DEBUG:
        if not telegram_data:
            if _is_trusted_debug_host(request):
                return settings.ADMIN_ID
            raise HTTPException(
                status_code=401,
                detail="Authentication required (send X-Telegram-Data or use a trusted debug host with AUTH_DEBUG)",
            )
        # Лише з довірених debug-хостів: імітація user id без валідного initData.
        if telegram_data.isdigit() and _is_trusted_debug_host(request):
            return int(telegram_data)

    if not telegram_data:
        raise HTTPException(status_code=401, detail="Authentication required")

    try:
        return _telegram_user_id_from_init_data(telegram_data)
    except Exception:
        raise HTTPException(
            status_code=401, detail="Invalid or expired Telegram initData"
        ) from None


async def get_search_user_id(
    request: Request,
    telegram_data: Optional[str] = Header(None, alias="X-Telegram-Data"),
    search_api_key: Optional[str] = Header(None, alias="X-Search-Api-Key"),
) -> int:
    """
    Same as get_current_user, or optional X-Search-Api-Key when SEARCH_API_SECRET is set.
    """
    sec = settings.SEARCH_API_SECRET
    if sec is not None:
        expected = (
            sec.get_secret_value() if isinstance(sec, SecretStr) else str(sec)
        )
        if expected and search_api_key and hmac.compare_digest(
            search_api_key, expected
        ):
            return settings.ADMIN_ID
    return await get_current_user(request, telegram_data)
