import asyncio
import json
import logging
import os
import time
import uuid
from urllib.parse import urlparse

import aiohttp
from fastapi import APIRouter, Depends, Request
from fastapi.responses import JSONResponse
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from api.deps import get_current_user
from common.config import settings
from common.database import get_db
from common.models import AccountTier, Track, User
from common.redis_client import redis_client
from common.schemas import DownloadTask

logger = logging.getLogger(__name__)

router = APIRouter(tags=["Tracks"])


def _valid_public_http_base(url: str) -> bool:
    """Відсікає плейсхолдери з кирилицею в hostname (невалідний DNS для клієнта)."""
    u = (url or "").strip()
    if not u.startswith(("http://", "https://")):
        return False
    try:
        host = urlparse(u).hostname or ""
        if not host:
            return False
        return all(ord(c) < 128 for c in host)
    except ValueError:
        return False


def _r2_playable_url(track: Track) -> str | None:
    """Повна URL: спочатку track.r2_url з БД (те, що повертає CF worker), інакше R2_PUBLIC_URL + key."""
    u = (track.r2_url or "").strip()
    if u.startswith(("http://", "https://")):
        if _valid_public_http_base(u):
            return u
        logger.warning(
            "Track %s: r2_url у БД некоректна або не-ASCII host, ігноруємо: %s",
            track.source_id,
            u[:80],
        )

    base = (settings.R2_PUBLIC_URL or "").strip().rstrip("/")
    if base and not _valid_public_http_base(base):
        logger.warning(
            "R2_PUBLIC_URL у .env не виглядає як реальний публічний URL "
            "(встав з Cloudflare → R2 → hydra-storage → Public access, напр. https://pub-….r2.dev). "
            "Ігноруємо для збирання URL."
        )
        base = ""
    key = (track.r2_key or "").strip().lstrip("/")
    if base and key:
        return f"{base}/{key}"
    return None


async def _r2_object_readable(url: str) -> bool:
    """HEAD; якщо провайдер не любить HEAD — легкий GET Range."""
    timeout = aiohttp.ClientTimeout(total=12)
    try:
        async with aiohttp.ClientSession(timeout=timeout) as session:
            async with session.head(url, allow_redirects=True) as resp:
                if resp.status == 200:
                    return True
                if resp.status == 404:
                    return False
            async with session.get(
                url,
                headers={"Range": "bytes=0-0"},
                allow_redirects=True,
            ) as resp2:
                return resp2.status in (200, 206)
    except Exception as e:
        logger.error("R2 reachability check failed for %s: %s", url[:120], e)
        return False


@router.get("/track/{youtube_id}")
async def get_track(
    youtube_id: str,
    request: Request,
    user_id: int = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    track = await db.scalar(select(Track).where(Track.source_id == youtube_id))

    if track and (track.r2_key or track.r2_url):
        r2_url = _r2_playable_url(track)
        is_alive = False
        if r2_url:
            is_alive = await _r2_object_readable(r2_url)
            if not is_alive:
                logger.warning(
                    "R2 URL не читається (HEAD/GET): %s — можливо приватний бакет або невірна публічна база",
                    r2_url[:100],
                )
        else:
            logger.warning(
                "Track %s has r2_key/r2_url in DB but no absolute URL "
                "(set R2_PUBLIC_URL or store full https r2_url). Will try Telegram restore.",
                youtube_id,
            )

        if is_alive:
            return {
                "id": track.source_id,
                "title": track.title,
                "artist": track.artist,
                "duration": track.duration,
                "url": r2_url,
                "cover": track.cover_big,
                "source": "r2",
                "status": "ready",
            }

        if track.telegram_file_id:
            logger.info("Queue restore from Telegram for %s", youtube_id)
            lock_key = f"restore_lock:{youtube_id}"
            if not await redis_client.redis.exists(lock_key):
                await redis_client.redis.set(lock_key, "1", ex=60)
                req_id = str(uuid.uuid4())
                task_payload = {
                    "request_id": req_id,
                    "action": "restore_file",
                    "payload": {
                        "track_id": youtube_id,
                        "file_id": track.telegram_file_id,
                        "r2_key": track.r2_key or f"{youtube_id}.m4a",
                    },
                }
                await redis_client.redis.lpush("metadata_queue", json.dumps(task_payload))

            rs_key = f"restore_started:{youtube_id}"
            if not await redis_client.redis.exists(rs_key):
                await redis_client.redis.set(rs_key, str(int(time.time())), ex=3600)

            try:
                t0 = int(await redis_client.redis.get(rs_key) or 0)
            except (TypeError, ValueError):
                t0 = 0
            if t0 and (time.time() - t0) > 120:
                fb = f"ytdl_restore_fb:{youtube_id}"
                if await redis_client.redis.set(fb, "1", nx=True, ex=600):
                    logger.info(
                        "Restore for %s exceeded 120s; enqueue YouTube re-download (fallback)",
                        youtube_id,
                    )
                    proc = f"proc_lock:{youtube_id}"
                    if not await redis_client.redis.exists(proc):
                        await redis_client.redis.set(proc, "1", ex=60)
                        await redis_client.push_task(
                            DownloadTask(
                                chat_id=user_id,
                                user_id=user_id,
                                query=f"dl_id:{youtube_id}",
                                message_id=0,
                                is_interface=True,
                            ),
                            is_background=False,
                        )

            return JSONResponse(
                status_code=202,
                content={
                    "status": "restoring",
                    "message": "Restoring file from backup...",
                    "retry_after": 3,
                },
            )

        logger.warning(
            "Track %s: R2 недоступний і немає telegram_file_id — переходимо до черги завантаження",
            youtube_id,
        )

    user = await db.get(User, user_id)
    user_tier = user.tier if user else AccountTier.FREE

    if user_tier == AccountTier.PREMIUM:
        logging.info("Premium user %s waiting for stream %s", user_id, youtube_id)
        filename = f"{youtube_id}.m4a"
        file_path = os.path.join("/app/downloads", filename)
        lock_key = f"proc_lock:{youtube_id}"

        if not os.path.exists(file_path) and not await redis_client.redis.exists(
            lock_key
        ):
            await redis_client.redis.set(lock_key, "1", ex=120)
            task = DownloadTask(
                chat_id=user_id,
                user_id=user_id,
                query=f"dl_id:{youtube_id}",
                message_id=0,
                is_interface=True,
                pre_downloaded_path=file_path,
            )
            await redis_client.push_task(task, is_background=False)

        start_time = time.time()
        while time.time() - start_time < 45:
            if os.path.exists(file_path) and os.path.getsize(file_path) > 1024:
                logging.info("Stream ready for %s", youtube_id)
                break
            await asyncio.sleep(0.5)

        base_url = str(request.base_url).rstrip("/")
        stream_url = f"{base_url}/api/stream/track/{youtube_id}"
        fresh_track = await db.scalar(select(Track).where(Track.source_id == youtube_id))

        return {
            "source_id": youtube_id,
            "title": fresh_track.title if fresh_track else "Loading...",
            "artist": fresh_track.artist if fresh_track else "Unknown",
            "stream_url": stream_url,
            "cover": fresh_track.cover_big if fresh_track else "",
            "status": "ready",
        }

    lock_key = f"proc_lock:{youtube_id}"
    if not await redis_client.redis.exists(lock_key):
        await redis_client.redis.set(lock_key, "1", ex=60)
        task = DownloadTask(
            chat_id=user_id,
            user_id=user_id,
            query=f"dl_id:{youtube_id}",
            message_id=0,
            is_interface=True,
        )
        await redis_client.push_task(task, is_background=False)

    return JSONResponse(
        status_code=202,
        content={
            "status": "processing",
            "message": "Downloading...",
            "retry_after": 5,
        },
    )
