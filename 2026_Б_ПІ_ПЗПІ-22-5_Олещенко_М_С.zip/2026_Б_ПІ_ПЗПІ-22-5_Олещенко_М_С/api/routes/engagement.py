import json
import logging
from typing import List, Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy import and_, func, select, update
from sqlalchemy.ext.asyncio import AsyncSession

from api.deps import get_current_user
from api.routes.schemas import FavoriteToggleRequest, ListenAnalyticsBody
from common.database import get_db
from common.models import ListeningHistory, Track, User, UserPlaylist
from common.redis_client import redis_client
from common.schemas import DownloadTask

logger = logging.getLogger(__name__)

router = APIRouter(tags=["Engagement"])


async def toggle_like(
    youtube_id: str,
    title: Optional[str],
    artist: Optional[str],
    duration: int,
    user_id: int,
    db: AsyncSession,
):
    if not await db.scalar(select(Track).where(Track.source_id == youtube_id)):
        new_track = Track(
            source_id=youtube_id,
            title=title or "Unknown",
            artist=artist or "Unknown",
            duration=duration,
            source_url=f"https://www.youtube.com/watch?v={youtube_id}",
            telegram_file_id="pending",
        )
        db.add(new_track)
        try:
            await db.commit()
        except Exception:
            await db.rollback()

    existing_like = await db.scalar(
        select(UserPlaylist).where(
            and_(UserPlaylist.user_id == user_id, UserPlaylist.track_id == youtube_id)
        )
    )
    if existing_like:
        await db.delete(existing_like)
        await db.commit()
        return {"status": "unliked", "id": youtube_id}
    db.add(UserPlaylist(user_id=user_id, track_id=youtube_id))
    await db.commit()
    return {"status": "liked", "id": youtube_id}


@router.post("/favorites/toggle")
async def toggle_favorite_json(
    data: FavoriteToggleRequest,
    user_id: int = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    return await toggle_like(
        youtube_id=data.track_id,
        title=None,
        artist=None,
        duration=0,
        user_id=user_id,
        db=db,
    )


@router.post("/like/{youtube_id}")
async def toggle_like_endpoint(
    youtube_id: str,
    title: Optional[str] = Query(None),
    artist: Optional[str] = Query(None),
    duration: Optional[int] = Query(0),
    user_id: int = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    return await toggle_like(
        youtube_id=youtube_id,
        title=title,
        artist=artist,
        duration=duration or 0,
        user_id=user_id,
        db=db,
    )


@router.get("/recommendations/personalized")
async def get_personalized_recommendations(
    user_id: int = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    last_listen = await db.scalar(
        select(ListeningHistory)
        .where(ListeningHistory.user_id == user_id)
        .order_by(ListeningHistory.listened_at.desc())
        .limit(1)
    )
    seed_track_id = None
    if last_listen:
        seed_track_id = last_listen.track_source_id
    else:
        last_like = await db.scalar(
            select(UserPlaylist)
            .where(UserPlaylist.user_id == user_id)
            .order_by(UserPlaylist.added_at.desc())
            .limit(1)
        )
        if last_like:
            seed_track_id = last_like.track_id

    if not seed_track_id:
        return []

    redis_key = f"rec:{seed_track_id}"
    cached_data = await redis_client.redis.get(redis_key)
    if cached_data:
        data = json.loads(cached_data)
        if data:
            return data
        await redis_client.redis.delete(redis_key)

    task = DownloadTask(
        chat_id=user_id,
        user_id=user_id,
        query=f"rec:{seed_track_id}",
        message_id=0,
        is_interface=True,
    )
    await redis_client.push_task(task, is_background=False)
    raise HTTPException(
        status_code=202,
        detail="Generating...",
        headers={"X-Status": "PROCESSING"},
    )


@router.get("/recommendations/{youtube_id}")
async def get_recommendations(
    youtube_id: str,
    user_id: int = Depends(get_current_user),
):
    redis_key = f"rec:{youtube_id}"
    cached_data = await redis_client.redis.get(redis_key)
    if cached_data:
        return json.loads(cached_data)

    task = DownloadTask(
        chat_id=user_id,
        user_id=user_id,
        query=f"rec:{youtube_id}",
        message_id=0,
        is_interface=True,
    )
    await redis_client.push_task(task, is_background=False)
    raise HTTPException(
        status_code=202,
        detail="Generating...",
        headers={"X-Status": "PROCESSING"},
    )


@router.get("/favorites", response_model=List[dict])
async def get_favorites(
    user_id: int = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    query = (
        select(Track)
        .join(UserPlaylist, UserPlaylist.track_id == Track.source_id)
        .where(UserPlaylist.user_id == user_id)
        .order_by(UserPlaylist.added_at.desc())
    )
    result = await db.execute(query)
    tracks = result.scalars().all()
    return [
        {
            "id": t.source_id,
            "title": t.title,
            "artist": t.artist,
            "duration": t.duration or 0,
            "url": t.source_url,
            "cover": t.cover_small
            or f"https://img.youtube.com/vi/{t.source_id}/mqdefault.jpg",
            "source": "r2" if t.r2_url else "youtube",
        }
        for t in tracks
    ]


@router.post("/analytics/listen/{source_id}")
async def record_listen(
    source_id: str,
    body: ListenAnalyticsBody = ListenAnalyticsBody(),
    user_id: int = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(select(Track).where(Track.source_id == source_id))
    track = result.scalar_one_or_none()

    if not track:
        logger.info("Creating track stub for analytics: %s", source_id)
        track = Track(
            source_id=source_id,
            title="Loading...",
            artist="Unknown Artist",
            duration=0,
            source_url=f"https://www.youtube.com/watch?v={source_id}",
            telegram_file_id=f"pending_{source_id}",
        )
        db.add(track)
        await db.commit()
        await db.refresh(track)

    db.add(
        ListeningHistory(
            user_id=user_id,
            track_id=track.track_id,
            track_source_id=source_id,
            playback_position=body.playback_position or 0.0,
        )
    )
    await db.execute(
        update(User)
        .where(User.user_id == user_id)
        .values(last_activity_date=func.current_date())
    )
    await db.commit()
    return {"status": "ok", "track_id": track.track_id}


@router.get("/library/history")
async def get_listening_history(
    user_id: int = Depends(get_current_user),
    limit: int = 50,
    unique: bool = Query(False, description="Повертати тільки унікальні треки"),
    db: AsyncSession = Depends(get_db),
):
    query = (
        select(ListeningHistory, Track)
        .join(Track, Track.source_id == ListeningHistory.track_source_id)
        .where(ListeningHistory.user_id == user_id)
        .order_by(ListeningHistory.listened_at.desc())
        .limit(limit)
    )
    result = await db.execute(query)
    history = result.all()

    response_data = []
    seen_ids = set()
    for entry in history:
        track_id = entry.Track.source_id
        if unique and track_id in seen_ids:
            continue
        seen_ids.add(track_id)
        response_data.append(
            {
                "listened_at": entry.ListeningHistory.listened_at,
                "playback_position": getattr(entry.ListeningHistory, "playback_position", 0) or 0,
                "track": {
                    "id": entry.Track.source_id,
                    "title": entry.Track.title,
                    "artist": entry.Track.artist,
                    "duration": entry.Track.duration,
                    "cover": entry.Track.cover_small
                    if entry.Track.cover_small
                    else f"https://img.youtube.com/vi/{entry.Track.source_id}/mqdefault.jpg",
                    "cover_big": entry.Track.cover_big
                    if entry.Track.cover_big
                    else entry.Track.cover_small,
                    "url": entry.Track.source_url,
                },
            }
        )
        if unique and len(response_data) >= 20:
            break
    return response_data


@router.get("/recommendations/continue")
async def get_continue_listening(
    user_id: int = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Треки з незавершеним прослуховуванням (>10% і <90%)."""
    query = (
        select(ListeningHistory, Track)
        .join(Track, Track.source_id == ListeningHistory.track_source_id)
        .where(ListeningHistory.user_id == user_id)
        .order_by(ListeningHistory.listened_at.desc())
        .limit(30)
    )
    result = await db.execute(query)
    items = []
    seen = set()
    for entry in result.all():
        tid = entry.Track.source_id
        if tid in seen:
            continue
        seen.add(tid)
        pos = getattr(entry.ListeningHistory, "playback_position", 0) or 0
        dur = entry.Track.duration or 0
        if dur > 0 and 0.1 * dur < pos < 0.9 * dur:
            items.append({
                "playback_position": pos,
                "listened_at": entry.ListeningHistory.listened_at,
                "track": {
                    "id": tid,
                    "title": entry.Track.title,
                    "artist": entry.Track.artist,
                    "duration": dur,
                    "cover": entry.Track.cover_small
                    or f"https://img.youtube.com/vi/{tid}/mqdefault.jpg",
                },
            })
        if len(items) >= 10:
            break
    return items


@router.get("/recommendations/daily-mix")
async def get_daily_mix(
    user_id: int = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    user = await db.scalar(select(User).where(User.user_id == user_id))
    seeds = []

    last_listen = await db.scalar(
        select(ListeningHistory)
        .where(ListeningHistory.user_id == user_id)
        .order_by(ListeningHistory.listened_at.desc())
        .limit(1)
    )
    if last_listen and last_listen.track_source_id:
        redis_key = f"rec:{last_listen.track_source_id}"
        cached_data = await redis_client.redis.get(redis_key)
        if cached_data:
            seeds = json.loads(cached_data)[:15]

    if not seeds:
        history_q = (
            select(Track)
            .join(ListeningHistory, ListeningHistory.track_source_id == Track.source_id)
            .where(ListeningHistory.user_id == user_id)
            .order_by(ListeningHistory.listened_at.desc())
            .limit(10)
        )
        tracks = (await db.scalars(history_q)).all()
        seeds = [
            {
                "id": t.source_id,
                "title": t.title,
                "artist": t.artist,
                "duration": t.duration or 0,
                "cover": t.cover_small
                or f"https://img.youtube.com/vi/{t.source_id}/mqdefault.jpg",
            }
            for t in tracks
        ]

    return {"title": "Daily Mix", "items": seeds}


@router.post("/download/send-to-chat/{track_id}")
async def send_track_to_chat(
    track_id: str,
    user_id: int = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    track = await db.scalar(select(Track).where(Track.source_id == track_id))
    if not track:
        task = DownloadTask(
            chat_id=user_id,
            user_id=user_id,
            query=f"dl_id:{track_id}",
            message_id=0,
            is_interface=True,
        )
        await redis_client.push_task(task, is_background=False)
        return {"status": "downloading", "message": "Track queued for download"}

    task_data = {
        "user_id": user_id,
        "track_id": track_id,
        "title": track.title,
        "artist": track.artist,
        "file_id": track.telegram_file_id,
        "r2_url": track.r2_url,
    }
    await redis_client.redis.lpush("tg_send_queue", json.dumps(task_data))
    return {"status": "queued", "message": "Sent to bot"}


@router.put("/track/{track_id}")
async def update_track_info(
    track_id: str,
    title: str = Query(None),
    artist: str = Query(None),
    user_id: int = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    values = {}
    if title:
        values["title"] = title
    if artist:
        values["artist"] = artist
    if not values:
        return {"status": "no_changes"}

    await db.execute(update(Track).where(Track.source_id == track_id).values(**values))
    await db.commit()
    return {"status": "updated", "id": track_id, "new_data": values}


@router.post("/favorites/send-to-chat")
async def send_all_favorites_to_chat(
    user_id: int = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    query = (
        select(Track)
        .join(UserPlaylist, UserPlaylist.track_id == Track.source_id)
        .where(UserPlaylist.user_id == user_id)
        .order_by(UserPlaylist.added_at.asc())
    )
    result = await db.execute(query)
    tracks = result.scalars().all()
    if not tracks:
        return {"status": "empty", "message": "No favorites found"}

    count = 0
    for t in tracks:
        task_data = {
            "user_id": user_id,
            "track_id": t.source_id,
            "title": t.title,
            "artist": t.artist,
            "file_id": t.telegram_file_id,
            "r2_url": t.r2_url,
            "disable_notification": True,
        }
        await redis_client.redis.lpush("tg_send_queue", json.dumps(task_data))
        count += 1
    return {"status": "queued", "count": count}
