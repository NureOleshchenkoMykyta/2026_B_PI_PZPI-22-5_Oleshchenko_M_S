import json

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import and_, select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from api.deps import get_current_user
from common.database import get_db
from common.models import Playlist, PlaylistLike, PlaylistTrack
from common.redis_client import redis_client

router = APIRouter(tags=["Overview", "Playlists"])


@router.get("/overview")
async def get_overview_page(user_id: int = Depends(get_current_user)):
    keys = ["cache:new_releases", "cache:charts_ua", "cache:charts_global"]
    values = await redis_client.redis.mget(keys)

    new_releases_raw = values[0]
    charts_ua_raw = values[1]
    charts_global_raw = values[2]

    if not charts_ua_raw:
        charts_ua_raw = await redis_client.redis.get("cache:charts")

    new_releases = json.loads(new_releases_raw) if new_releases_raw else []
    charts_ua = json.loads(charts_ua_raw) if charts_ua_raw else []
    charts_global = json.loads(charts_global_raw) if charts_global_raw else []

    sections = []
    if new_releases:
        sections.append(
            {
                "id": "new",
                "title": "Нові релізи",
                "type": "album",
                "items": new_releases,
            }
        )
    if charts_global:
        sections.append(
            {
                "id": "charts_global",
                "title": "Світові Хіти",
                "type": "song",
                "items": charts_global,
            }
        )
    if charts_ua:
        sections.append(
            {
                "id": "charts_ua",
                "title": "Топ Чарт (Україна)",
                "type": "song",
                "items": charts_ua,
            }
        )
    return {"sections": sections}


@router.post("/playlists/{playlist_id}/clone")
async def clone_playlist(
    playlist_id: int,
    user_id: int = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    original = await db.get(Playlist, playlist_id)
    if not original:
        raise HTTPException(status_code=404, detail="Playlist not found")

    new_playlist = Playlist(
        user_id=user_id,
        title=f"{original.title} (Copy)",
        description=original.description,
        cover=original.cover,
        is_public=False,
        track_count=original.track_count,
    )
    db.add(new_playlist)
    await db.flush()

    tracks_query = select(PlaylistTrack).where(
        PlaylistTrack.playlist_id == playlist_id
    )
    result = await db.execute(tracks_query)
    original_tracks = result.scalars().all()
    new_tracks = [
        PlaylistTrack(
            playlist_id=new_playlist.id,
            track_source_id=t.track_source_id,
            position=t.position,
        )
        for t in original_tracks
    ]
    if new_tracks:
        db.add_all(new_tracks)
    await db.commit()
    return {"status": "cloned", "new_id": new_playlist.id}


@router.post("/playlists/{playlist_id}/like")
async def toggle_playlist_like(
    playlist_id: int,
    user_id: int = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    existing_like = await db.scalar(
        select(PlaylistLike).where(
            and_(PlaylistLike.playlist_id == playlist_id, PlaylistLike.user_id == user_id)
        )
    )
    playlist = await db.get(Playlist, playlist_id)
    if not playlist:
        raise HTTPException(status_code=404, detail="Playlist not found")

    if existing_like:
        await db.delete(existing_like)
        playlist.likes_count = max(0, playlist.likes_count - 1)
        action = "unliked"
    else:
        new_like = PlaylistLike(user_id=user_id, playlist_id=playlist_id)
        db.add(new_like)
        playlist.likes_count += 1
        action = "liked"
    await db.commit()
    return {"status": "ok", "action": action, "likes_count": playlist.likes_count}


@router.get("/playlists/explore")
async def explore_public_playlists(
    user_id: int = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    query = (
        select(Playlist)
        .where(Playlist.is_public == True)
        .options(selectinload(Playlist.user))
        .order_by(Playlist.likes_count.desc(), Playlist.created_at.desc())
    )
    result = await db.execute(query)
    playlists = result.scalars().all()

    liked_ids_query = select(PlaylistLike.playlist_id).where(
        PlaylistLike.user_id == user_id
    )
    liked_result = await db.execute(liked_ids_query)
    liked_ids = set(liked_result.scalars().all())

    return [
        {
            "id": p.id,
            "title": p.title,
            "description": p.description,
            "author": p.user.full_name if p.user else "Unknown",
            "cover": p.cover,
            "likes_count": p.likes_count or 0,
            "tags": p.tags if p.tags else [],
            "is_public": p.is_public,
            "track_count": p.track_count,
            "is_liked": p.id in liked_ids,
            "is_mine": p.user_id == user_id,
        }
        for p in playlists
    ]
