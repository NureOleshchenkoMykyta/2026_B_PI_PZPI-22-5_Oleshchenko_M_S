import logging
from typing import List, Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy import and_, func, select
from sqlalchemy.ext.asyncio import AsyncSession

from api.deps import get_current_user
from common.database import get_db
from common.models import Playlist, PlaylistCollaborator, PlaylistTrack, Track, User, UserFollow

logger = logging.getLogger(__name__)

router = APIRouter(tags=["Social"])


class CollaboratorInvite(BaseModel):
    user_id: int


class ShareCardRequest(BaseModel):
    track_id: Optional[str] = None
    playlist_id: Optional[int] = None


@router.get("/users/{profile_user_id}/profile")
async def get_user_profile(
    profile_user_id: int,
    user_id: int = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    user = await db.scalar(select(User).where(User.user_id == profile_user_id))
    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    public_playlists = await db.scalars(
        select(Playlist)
        .where(and_(Playlist.user_id == profile_user_id, Playlist.is_public == True))
        .order_by(Playlist.likes_count.desc())
        .limit(20)
    )

    followers = await db.scalar(
        select(func.count())
        .select_from(UserFollow)
        .where(UserFollow.following_id == profile_user_id)
    )
    following = await db.scalar(
        select(func.count())
        .select_from(UserFollow)
        .where(UserFollow.follower_id == profile_user_id)
    )
    is_following = await db.scalar(
        select(UserFollow).where(
            and_(
                UserFollow.follower_id == user_id,
                UserFollow.following_id == profile_user_id,
            )
        )
    )

    return {
        "id": user.user_id,
        "username": user.username,
        "full_name": user.full_name,
        "followers_count": followers or 0,
        "following_count": following or 0,
        "is_following": is_following is not None,
        "playlists": [
            {
                "id": p.id,
                "title": p.title,
                "cover": p.cover,
                "likes_count": p.likes_count or 0,
                "track_count": p.track_count or 0,
            }
            for p in public_playlists.all()
        ],
    }


@router.post("/users/{profile_user_id}/follow")
async def toggle_follow(
    profile_user_id: int,
    user_id: int = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    if profile_user_id == user_id:
        raise HTTPException(status_code=400, detail="Cannot follow yourself")

    existing = await db.scalar(
        select(UserFollow).where(
            and_(
                UserFollow.follower_id == user_id,
                UserFollow.following_id == profile_user_id,
            )
        )
    )
    if existing:
        await db.delete(existing)
        await db.commit()
        return {"status": "unfollowed"}

    db.add(UserFollow(follower_id=user_id, following_id=profile_user_id))
    await db.commit()
    return {"status": "followed"}


@router.get("/users/{profile_user_id}/activity")
async def get_user_activity(
    profile_user_id: int,
    user_id: int = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    _ = user_id
    public_playlists = await db.scalars(
        select(Playlist)
        .where(and_(Playlist.user_id == profile_user_id, Playlist.is_public == True))
        .order_by(Playlist.created_at.desc())
        .limit(10)
    )
    return {
        "recent_playlists": [
            {"id": p.id, "title": p.title, "cover": p.cover, "created_at": p.created_at}
            for p in public_playlists.all()
        ]
    }


@router.post("/playlists/{playlist_id}/collaborators")
async def invite_collaborator(
    playlist_id: int,
    body: CollaboratorInvite,
    user_id: int = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    playlist = await db.scalar(select(Playlist).where(Playlist.id == playlist_id))
    if not playlist:
        raise HTTPException(status_code=404, detail="Playlist not found")
    if playlist.user_id != user_id:
        raise HTTPException(status_code=403, detail="Only owner can invite")

    existing = await db.scalar(
        select(PlaylistCollaborator).where(
            and_(
                PlaylistCollaborator.playlist_id == playlist_id,
                PlaylistCollaborator.user_id == body.user_id,
            )
        )
    )
    if existing:
        return {"status": "already_collaborator"}

    db.add(
        PlaylistCollaborator(
            playlist_id=playlist_id,
            user_id=body.user_id,
            role="editor",
        )
    )
    await db.commit()
    return {"status": "invited", "invite_link": f"/playlist/{playlist_id}?collab={body.user_id}"}


@router.get("/playlists/{playlist_id}/collaborators")
async def list_collaborators(
    playlist_id: int,
    user_id: int = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    playlist = await db.scalar(select(Playlist).where(Playlist.id == playlist_id))
    if not playlist:
        raise HTTPException(status_code=404, detail="Playlist not found")

    collabs = await db.scalars(
        select(PlaylistCollaborator).where(
            PlaylistCollaborator.playlist_id == playlist_id
        )
    )
    return {
        "owner_id": playlist.user_id,
        "collaborators": [
            {"user_id": c.user_id, "role": c.role, "invited_at": c.invited_at}
            for c in collabs.all()
        ],
    }


@router.post("/share/card")
async def generate_share_card(
    body: ShareCardRequest,
    user_id: int = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    _ = user_id
    base_url = "https://nikkme.online"

    if body.track_id:
        track = await db.scalar(
            select(Track).where(Track.source_id == body.track_id)
        )
        title = track.title if track else "Track"
        artist = track.artist if track else "Artist"
        cover = (
            track.cover_big
            or f"https://img.youtube.com/vi/{body.track_id}/mqdefault.jpg"
            if track
            else f"https://img.youtube.com/vi/{body.track_id}/mqdefault.jpg"
        )
        return {
            "type": "track",
            "title": title,
            "subtitle": artist,
            "cover": cover,
            "url": f"{base_url}/track/{body.track_id}",
            "telegram_share_text": f"🎵 {title} — {artist}\n{base_url}/track/{body.track_id}",
        }

    if body.playlist_id:
        playlist = await db.scalar(
            select(Playlist).where(Playlist.id == body.playlist_id)
        )
        if not playlist:
            raise HTTPException(status_code=404, detail="Playlist not found")
        return {
            "type": "playlist",
            "title": playlist.title,
            "subtitle": playlist.description or "",
            "cover": playlist.cover,
            "url": f"{base_url}/playlist/{body.playlist_id}",
            "telegram_share_text": f"📜 {playlist.title}\n{base_url}/playlist/{body.playlist_id}",
        }

    raise HTTPException(status_code=400, detail="track_id or playlist_id required")
