import json
import logging
from typing import Any, Optional
from urllib.parse import parse_qsl

from fastapi import APIRouter, Depends, Header, HTTPException
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from api.deps import get_current_user
from api.routes.schemas import UserSettingsUpdate
from common.database import get_db
from common.models import User

logger = logging.getLogger(__name__)

router = APIRouter(tags=["User"])

_ALLOWED_UI_LANGS = frozenset({"en", "uk", "de"})


def _normalize_stored_language(code: Optional[str]) -> str:
    if not code:
        return "en"
    if code == "ru":
        return "uk"
    return code if code in _ALLOWED_UI_LANGS else "en"


def _profile_from_telegram_init_data(init_data: str) -> dict[str, Any]:
    """Поле user з initData (HMAC уже перевірено в get_current_user)."""
    try:
        parsed = dict(parse_qsl(init_data, keep_blank_values=True))
        raw = parsed.get("user")
        if not raw:
            return {}
        data = json.loads(raw)
        return data if isinstance(data, dict) else {}
    except (json.JSONDecodeError, TypeError, ValueError):
        return {}


async def _get_or_create_user(
    user_id: int,
    db: AsyncSession,
    telegram_data: Optional[str],
) -> User:
    user = await db.scalar(select(User).where(User.user_id == user_id))
    if user:
        return user
    username = None
    full_name = None
    if telegram_data and "=" in telegram_data:
        prof = _profile_from_telegram_init_data(telegram_data)
        if prof:
            username = prof.get("username")
            fn = (prof.get("first_name") or "").strip()
            ln = (prof.get("last_name") or "").strip()
            full_name = f"{fn} {ln}".strip() or None
    user = User(
        user_id=user_id,
        username=username,
        full_name=full_name,
        language="en",
        mode="light",
    )
    db.add(user)
    try:
        await db.commit()
        await db.refresh(user)
    except Exception:
        await db.rollback()
        user = await db.scalar(select(User).where(User.user_id == user_id))
        if user:
            return user
        raise

    return user


@router.get("/user/me")
async def get_my_profile(
    user_id: int = Depends(get_current_user),
    telegram_data: Optional[str] = Header(None, alias="X-Telegram-Data"),
    db: AsyncSession = Depends(get_db),
):
    user = await _get_or_create_user(user_id, db, telegram_data)
    if (user.language or "") == "ru":
        user.language = "uk"
        try:
            await db.commit()
            await db.refresh(user)
        except Exception:
            await db.rollback()
    return {
        "id": user.user_id,
        "username": user.username,
        "language": _normalize_stored_language(user.language),
        "tier": user.tier,
        "silent_mode": user.silent_mode if hasattr(user, "silent_mode") else False,
        "music_preferences": user.music_preferences or {},
        "onboarding_completed": bool(getattr(user, "onboarding_completed", False)),
        "filter_explicit": bool(getattr(user, "filter_explicit", False)),
    }


@router.patch("/user/settings")
async def update_user_settings(
    body: UserSettingsUpdate,
    user_id: int = Depends(get_current_user),
    telegram_data: Optional[str] = Header(None, alias="X-Telegram-Data"),
    db: AsyncSession = Depends(get_db),
):
    user = await _get_or_create_user(user_id, db, telegram_data)

    if body.language is not None:
        user.language = _normalize_stored_language(body.language)
    if body.silent_mode is not None:
        user.silent_mode = body.silent_mode
    if body.music_preferences is not None:
        user.music_preferences = body.music_preferences
    if body.onboarding_completed is not None:
        user.onboarding_completed = body.onboarding_completed
    if body.filter_explicit is not None:
        user.filter_explicit = body.filter_explicit

    try:
        await db.commit()
        await db.refresh(user)
    except Exception:
        logger.exception("Failed to persist user settings")
        raise HTTPException(status_code=500, detail="Database update failed")

    return {
        "status": "ok",
        "language": user.language,
        "silent_mode": user.silent_mode,
        "music_preferences": user.music_preferences or {},
        "onboarding_completed": bool(user.onboarding_completed),
        "filter_explicit": bool(user.filter_explicit),
    }
