import logging
from typing import Optional

from fastapi import APIRouter, Depends, Query

from api.deps import get_current_user
from api.services.lyrics_fetch import fetch_lyrics

logger = logging.getLogger(__name__)

router = APIRouter(tags=["Lyrics"])


@router.get("/lyrics/{track_id}")
async def get_lyrics(
    track_id: str,
    title: str = Query(...),
    artist: str = Query(...),
    duration: Optional[int] = Query(None),
    album: Optional[str] = Query(None),
    _user_id: int = Depends(get_current_user),
):
    try:
        return await fetch_lyrics(
            track_id=track_id,
            title=title,
            artist=artist,
            duration=duration,
            album=album,
        )
    except Exception as e:
        logger.warning("Lyrics fetch failed for %s: %s", track_id, e)
        return {"track_id": track_id, "lyrics": None, "synced": False, "source": None}
