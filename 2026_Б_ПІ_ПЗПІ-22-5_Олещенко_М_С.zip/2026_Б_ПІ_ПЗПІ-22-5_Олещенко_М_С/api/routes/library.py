import asyncio
import json
import re
import uuid
from typing import List, Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import JSONResponse
from sqlalchemy import and_, delete, select, update
from sqlalchemy.ext.asyncio import AsyncSession

from api.deps import get_current_user
from api.routes.schemas import ImportPlaylistRequest, RemoveTracksRequest
from common.database import get_db
from common.models import Playlist, PlaylistTrack, Track
from common.redis_client import redis_client
from common.schemas import PlaylistResponse, TrackSearchResult

router = APIRouter(tags=["Library"])


@router.get("/library/playlists")
async def get_my_playlists(
    user_id: int = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    query = (
        select(Playlist)
        .where(Playlist.user_id == user_id)
        .order_by(Playlist.is_pinned.desc(), Playlist.created_at.desc())
    )
    result = await db.execute(query)
    playlists = result.scalars().all()
    return [
        {
            "id": p.id,
            "title": p.title,
            "description": p.description,
            "cover": p.cover,
            "pinned": p.is_pinned,
            "type": "Плейліст",
        }
        for p in playlists
    ]


@router.get("/library/playlists/{playlist_id}")
async def get_playlist_details(
    playlist_id: int,
    user_id: int = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    playlist = await db.scalar(select(Playlist).where(Playlist.id == playlist_id))
    if not playlist:
        raise HTTPException(status_code=404, detail="Playlist not found")
    is_owner = playlist.user_id == user_id
    return {
        "id": playlist.id,
        "title": playlist.title,
        "description": playlist.description,
        "cover": playlist.cover,
        "is_owner": is_owner,
        "owner_id": playlist.user_id,
    }


@router.get(
    "/library/playlists/{playlist_id}/tracks",
    response_model=List[TrackSearchResult],
)
async def get_playlist_tracks(
    playlist_id: int,
    user_id: int = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    playlist = await db.scalar(select(Playlist).where(Playlist.id == playlist_id))
    if not playlist:
        raise HTTPException(status_code=404, detail="Playlist not found")

    query = (
        select(Track)
        .join(PlaylistTrack, PlaylistTrack.track_source_id == Track.source_id)
        .where(PlaylistTrack.playlist_id == playlist_id)
        .order_by(PlaylistTrack.position.asc(), PlaylistTrack.added_at.desc())
    )
    result = await db.execute(query)
    tracks = result.scalars().all()
    return [
        {
            "id": t.source_id,
            "title": t.title,
            "artist": t.artist,
            "duration": t.duration or 0,
            "url": t.source_url,
            "cover": (
                t.cover_small
                if (hasattr(t, "cover_small") and t.cover_small)
                else f"https://img.youtube.com/vi/{t.source_id}/mqdefault.jpg"
            ),
            "cover_big": (
                t.cover_big
                if (hasattr(t, "cover_big") and t.cover_big)
                else f"https://img.youtube.com/vi/{t.source_id}/maxresdefault.jpg"
            ),
            "source": "r2" if t.r2_url else "youtube",
        }
        for t in tracks
    ]


@router.put("/library/playlists/{playlist_id}")
async def update_playlist(
    playlist_id: int,
    title: str = Query(None),
    description: str = Query(None),
    user_id: int = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    playlist = await db.scalar(
        select(Playlist).where(
            and_(Playlist.id == playlist_id, Playlist.user_id == user_id)
        )
    )
    if not playlist:
        raise HTTPException(status_code=403, detail="Not owner or not found")
    if title:
        playlist.title = title
    if description is not None:
        playlist.description = description
    await db.commit()
    return {
        "status": "updated",
        "playlist": {"title": playlist.title, "description": playlist.description},
    }


@router.delete("/library/playlists/{playlist_id}")
async def delete_playlist(
    playlist_id: int,
    user_id: int = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    playlist = await db.scalar(
        select(Playlist).where(
            and_(Playlist.id == playlist_id, Playlist.user_id == user_id)
        )
    )
    if not playlist:
        raise HTTPException(status_code=403, detail="Not owner or not found")
    await db.execute(
        delete(PlaylistTrack).where(PlaylistTrack.playlist_id == playlist_id)
    )
    await db.delete(playlist)
    await db.commit()
    return {"status": "deleted"}


@router.post("/library/playlists/{playlist_id}/duplicate")
async def duplicate_playlist(
    playlist_id: int,
    user_id: int = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    original = await db.scalar(select(Playlist).where(Playlist.id == playlist_id))
    if not original:
        raise HTTPException(status_code=404, detail="Playlist not found")

    new_pl = Playlist(
        user_id=user_id,
        title=f"{original.title} (Copy)",
        description=original.description,
        cover=original.cover,
    )
    db.add(new_pl)
    await db.commit()
    await db.refresh(new_pl)

    tracks = await db.scalars(
        select(PlaylistTrack).where(PlaylistTrack.playlist_id == playlist_id)
    )
    for t in tracks:
        db.add(
            PlaylistTrack(playlist_id=new_pl.id, track_source_id=t.track_source_id)
        )
    await db.commit()
    return {"status": "duplicated", "id": new_pl.id, "title": new_pl.title}


@router.post("/library/playlists", response_model=PlaylistResponse)
async def create_playlist(
    title: str,
    description: Optional[str] = None,
    is_public: bool = False,
    user_id: int = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    new_playlist = Playlist(
        user_id=user_id,
        title=title,
        description=description,
        is_public=is_public,
        track_count=0,
        likes_count=0,
    )
    db.add(new_playlist)
    await db.commit()
    await db.refresh(new_playlist)
    return new_playlist


@router.post("/library/playlists/{playlist_id}/add")
async def add_track_to_playlist(
    playlist_id: int,
    track_id: str = Query(..., description="YouTube ID треку"),
    user_id: int = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    playlist = await db.scalar(
        select(Playlist).where(
            and_(Playlist.id == playlist_id, Playlist.user_id == user_id)
        )
    )
    if not playlist:
        raise HTTPException(status_code=404, detail="Playlist not found")

    exists = await db.scalar(
        select(PlaylistTrack).where(
            and_(
                PlaylistTrack.playlist_id == playlist_id,
                PlaylistTrack.track_source_id == track_id,
            )
        )
    )
    if exists:
        return {"status": "exists", "message": "Track already in playlist"}

    db.add(PlaylistTrack(playlist_id=playlist_id, track_source_id=track_id))
    if not playlist.cover or "picsum" in playlist.cover:
        playlist.cover = f"https://img.youtube.com/vi/{track_id}/mqdefault.jpg"

    await db.execute(
        update(Playlist)
        .where(Playlist.id == playlist_id)
        .values(track_count=Playlist.track_count + 1)
    )
    await db.commit()
    return {"status": "added"}


@router.post("/library/playlists/{playlist_id}/remove-tracks")
async def remove_tracks_from_playlist(
    playlist_id: int,
    data: RemoveTracksRequest,
    user_id: int = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    playlist = await db.scalar(
        select(Playlist).where(
            and_(Playlist.id == playlist_id, Playlist.user_id == user_id)
        )
    )
    if not playlist:
        raise HTTPException(status_code=403, detail="Not owner or playlist not found")

    if data.track_ids:
        await db.execute(
            delete(PlaylistTrack).where(
                and_(
                    PlaylistTrack.playlist_id == playlist_id,
                    PlaylistTrack.track_source_id.in_(data.track_ids),
                )
            )
        )
        count_removed = len(data.track_ids)
        new_count = (
            (playlist.track_count - count_removed)
            if playlist.track_count >= count_removed
            else 0
        )
        await db.execute(
            update(Playlist)
            .where(Playlist.id == playlist_id)
            .values(track_count=new_count)
        )
        await db.commit()

    return {"status": "ok", "deleted_count": len(data.track_ids)}


@router.post("/library/playlists/{playlist_id}/send-to-chat")
async def send_playlist_to_chat(
    playlist_id: int,
    user_id: int = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    playlist = await db.scalar(
        select(Playlist).where(
            and_(Playlist.id == playlist_id, Playlist.user_id == user_id)
        )
    )
    if not playlist:
        raise HTTPException(status_code=404, detail="Playlist not found")

    query = (
        select(Track)
        .join(PlaylistTrack, PlaylistTrack.track_source_id == Track.source_id)
        .where(PlaylistTrack.playlist_id == playlist_id)
        .order_by(PlaylistTrack.position.asc())
    )
    result = await db.execute(query)
    tracks = result.scalars().all()
    if not tracks:
        return {"status": "empty", "message": "Playlist is empty"}

    count = 0
    for t in tracks:
        task_data = {
            "user_id": user_id,
            "track_id": t.source_id,
            "title": t.title,
            "artist": t.artist,
            "file_id": t.telegram_file_id,
            "r2_url": t.r2_url,
            "disable_notification": True,
        }
        await redis_client.redis.lpush("tg_send_queue", json.dumps(task_data))
        count += 1
    return {"status": "queued", "count": count, "playlist": playlist.title}


def _extract_youtube_playlist_id(url: str) -> Optional[str]:
    patterns = [
        r"list=([a-zA-Z0-9_-]+)",
        r"youtube\.com/playlist\?list=([a-zA-Z0-9_-]+)",
    ]
    for pat in patterns:
        m = re.search(pat, url)
        if m:
            return m.group(1)
    if url.startswith("PL") and len(url) > 10:
        return url
    return None


@router.post("/library/playlists/import")
async def import_playlist_from_url(
    body: ImportPlaylistRequest,
    user_id: int = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    playlist_id = _extract_youtube_playlist_id(body.url.strip())
    if not playlist_id:
        raise HTTPException(status_code=400, detail="Invalid YouTube playlist URL")

    request_id = str(uuid.uuid4())
    task = {
        "request_id": request_id,
        "action": "fetch_playlist",
        "payload": playlist_id,
    }
    await redis_client.redis.lpush("metadata_queue", json.dumps(task))

    for _ in range(30):
        raw = await redis_client.redis.get(f"meta_res:{request_id}")
        if raw:
            break
        await asyncio.sleep(2)

    raw = await redis_client.redis.get(f"meta_res:{request_id}")
    if not raw:
        return JSONResponse(
            status_code=202,
            content={
                "status": "processing",
                "request_id": request_id,
                "poll_path": f"/api/metadata/result/{request_id}",
            },
        )

    data = json.loads(raw)
    if isinstance(data, dict) and "items" in data:
        pl_data = data
    else:
        pl_data = {"items": data if isinstance(data, list) else [], "title": body.title or "Imported"}

    title = body.title or pl_data.get("title") or "Imported Playlist"
    cover = pl_data.get("cover")
    items = pl_data.get("items") or []

    playlist = Playlist(
        user_id=user_id,
        title=title,
        description="Imported from YouTube",
        cover=cover,
        is_public=False,
        track_count=len(items),
    )
    db.add(playlist)
    await db.flush()

    for idx, item in enumerate(items):
        tid = item.get("id")
        if not tid:
            continue
        existing = await db.scalar(select(Track).where(Track.source_id == tid))
        if not existing:
            db.add(
                Track(
                    source_id=tid,
                    title=item.get("title", "Unknown"),
                    artist=item.get("artist", "Unknown"),
                    duration=item.get("duration") or 0,
                    source_url=f"https://www.youtube.com/watch?v={tid}",
                    telegram_file_id="pending",
                    cover_small=item.get("cover"),
                )
            )
        db.add(
            PlaylistTrack(
                playlist_id=playlist.id,
                track_source_id=tid,
                position=idx,
            )
        )

    await db.commit()
    return {
        "status": "ok",
        "playlist": {
            "id": playlist.id,
            "title": playlist.title,
            "cover": playlist.cover,
            "track_count": len(items),
        },
    }
