import asyncio
import logging
import os
import uuid
from typing import List

from fastapi import APIRouter, Depends, File, HTTPException, Query, UploadFile
from shazamio import Shazam

from api.deps import get_search_user_id
from api.errors import raise_safe_500
from api.services.youtube_search import search_youtube
from common.config import settings
from common.redis_client import redis_client
from common.schemas import TrackSearchResult

logger = logging.getLogger(__name__)

# Дозволені Content-Type завантаження; порожній header не відхиляємо (клієнти без типу).
RECOGNIZE_ALLOWED_MEDIA_TYPES = frozenset(
    {
        "audio/webm",
        "video/webm",
        "audio/wav",
        "audio/x-wav",
        "audio/mpeg",
        "audio/mp3",
        "audio/mp4",
        "video/mp4",
        "application/octet-stream",
    }
)

router = APIRouter(tags=["Search"])


@router.get("/search", response_model=List[TrackSearchResult])
async def api_search_tracks(
    query: str = Query(..., min_length=2),
    page: int = Query(1, ge=1),
    limit: int = Query(10, le=50),
    _user_id: int = Depends(get_search_user_id),
):
    return await search_youtube(query, limit, page)


@router.post("/recognize")
async def recognize_song(
    file: UploadFile = File(...),
    user_id: int = Depends(get_search_user_id),
):
    rl_per_min = getattr(settings, "RECOGNIZE_RATE_LIMIT_PER_MINUTE", 10) or 0
    if rl_per_min > 0:
        rk = f"rl:recognize:{user_id}"
        n = await redis_client.redis.incr(rk)
        if n == 1:
            await redis_client.redis.expire(rk, 60)
        if n > rl_per_min:
            raise HTTPException(
                status_code=429, detail="Recognition rate limit exceeded"
            )

    max_bytes = getattr(settings, "RECOGNIZE_MAX_BYTES", 10 * 1024 * 1024)
    timeout_sec = getattr(settings, "RECOGNIZE_TIMEOUT_SEC", 60.0)

    ct = (file.content_type or "").split(";")[0].strip().lower()
    if ct and ct not in RECOGNIZE_ALLOWED_MEDIA_TYPES:
        raise HTTPException(status_code=415, detail="Unsupported media type")

    temp_filename = f"downloads/shazam_{uuid.uuid4()}.webm"
    if not os.path.exists("downloads"):
        os.makedirs("downloads")

    try:
        total = 0
        with open(temp_filename, "wb") as buffer:
            while True:
                chunk = await file.read(1024 * 1024)
                if not chunk:
                    break
                total += len(chunk)
                if total > max_bytes:
                    raise HTTPException(status_code=413, detail="Upload too large")
                buffer.write(chunk)

        shazam = Shazam()
        try:
            out = await asyncio.wait_for(
                shazam.recognize(temp_filename), timeout=timeout_sec
            )
        except asyncio.TimeoutError:
            raise HTTPException(status_code=504, detail="Recognition timed out")

        if os.path.exists(temp_filename):
            os.remove(temp_filename)

        track_info = out.get("track")
        if not track_info:
            return {"track": None, "message": "No match found"}

        search_query = f"{track_info.get('subtitle')} {track_info.get('title')}"
        logger.info("Shazam match, searching YouTube: %s", search_query)

        results = await search_youtube(search_query, limit=1)
        if not results:
            return {"track": None, "message": "Track found in Shazam but not on YouTube"}

        found_track = results[0]
        return {
            "track": {
                "source_id": found_track["id"],
                "id": found_track["id"],
                "title": found_track["title"],
                "artist": found_track["artist"],
                "cover": found_track["cover"],
                "duration": found_track["duration"],
            }
        }

    except HTTPException:
        if os.path.exists(temp_filename):
            try:
                os.remove(temp_filename)
            except OSError:
                pass
        raise
    except Exception:
        if os.path.exists(temp_filename):
            try:
                os.remove(temp_filename)
            except OSError:
                pass
        raise_safe_500("recognition_failed")
