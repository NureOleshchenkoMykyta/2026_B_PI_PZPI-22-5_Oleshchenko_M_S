import logging

from fastapi import APIRouter, HTTPException
from sqlalchemy import text

from common.database import AsyncSessionLocal
from common.redis_client import redis_client

logger = logging.getLogger(__name__)

router = APIRouter(tags=["System"])


@router.get("/health")
async def health():
    """Liveness: process is up (no dependency checks)."""
    return {"status": "ok"}


@router.get("/ready")
async def ready():
    """Readiness: PostgreSQL and Redis must respond."""
    checks = {}
    try:
        async with AsyncSessionLocal() as db:
            await db.execute(text("SELECT 1"))
        checks["database"] = "ok"
    except Exception as e:
        logger.warning("ready check database failed: %s", e)
        checks["database"] = str(e)

    try:
        await redis_client.redis.ping()
        checks["redis"] = "ok"
    except Exception as e:
        logger.warning("ready check redis failed: %s", e)
        checks["redis"] = str(e)

    if checks.get("database") != "ok" or checks.get("redis") != "ok":
        raise HTTPException(status_code=503, detail=checks)
    return {"status": "ready", **checks}


@router.get("/")
async def root():
    return {"message": "Hydra API is running"}
