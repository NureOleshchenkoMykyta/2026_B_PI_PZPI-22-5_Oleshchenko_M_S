import json
import logging
import uuid
from datetime import datetime, timedelta, timezone
from typing import Any

from fastapi import APIRouter, Depends
from fastapi.responses import JSONResponse
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from api.deps import get_current_user
from common.database import get_db
from common.models import CachedContent, Track
from common.redis_client import redis_client

logger = logging.getLogger(__name__)

router = APIRouter(tags=["Metadata"])

META_JOB_PREFIX = "meta_job:"
META_JOB_TTL = 3600


async def _register_metadata_job(request_id: str, job: dict) -> None:
    await redis_client.redis.set(
        f"{META_JOB_PREFIX}{request_id}", json.dumps(job), ex=META_JOB_TTL
    )


async def get_content_with_status(source_id: str, db: AsyncSession):
    cached = await db.scalar(
        select(CachedContent).where(CachedContent.source_id == source_id)
    )
    if not cached:
        return None

    items = cached.items_data
    if not items:
        return {"items": []}

    track_items = items
    albums = []
    similar_artists = []
    if cached.type == 'artist' and isinstance(items, dict):
        track_items = items.get('tracks', [])
        albums = items.get('albums', [])
        similar_artists = items.get('similar_artists', [])

    track_ids = [t["id"] for t in track_items if t.get("id")]
    existing_tracks_result = await db.execute(
        select(Track).where(Track.source_id.in_(track_ids))
    )
    existing_map = {t.source_id: t for t in existing_tracks_result.scalars().all()}

    final_items = []
    for item in track_items:
        t_id = item.get("id")
        db_track = existing_map.get(t_id)
        track_obj = item.copy()
        track_obj["source"] = "youtube"

        if db_track:
            if db_track.r2_key or db_track.r2_url:
                track_obj["status"] = "ready"
                track_obj["source"] = "r2"
                if db_track.cover_big:
                    track_obj["cover"] = db_track.cover_big
            else:
                track_obj["status"] = "processing"
        else:
            track_obj["status"] = "new"

        final_items.append(track_obj)

    result = {
        "id": cached.source_id,
        "title": cached.title,
        "artist": cached.artist,
        "description": cached.description,
        "cover": cached.cover,
        "type": cached.type,
        "items": final_items,
    }
    if cached.type == 'artist':
        result["albums"] = albums
        result["similar_artists"] = similar_artists
    return result


@router.get("/metadata/result/{request_id}")
async def metadata_result(
    request_id: str,
    _user_id: int = Depends(get_current_user),
):
    raw = await redis_client.redis.get(f"meta_res:{request_id}")
    if not raw:
        return {"status": "pending", "request_id": request_id}

    job_raw = await redis_client.redis.get(f"{META_JOB_PREFIX}{request_id}")
    job: dict[str, Any] = json.loads(job_raw) if job_raw else {}
    payload = json.loads(raw)

    kind = job.get("kind")
    if kind == "genre":
        cat = job.get("category_key", "")
        return {
            "status": "ready",
            "request_id": request_id,
            "id": cat,
            "title": cat,
            "items": payload,
            "source": "worker",
        }

    if not job_raw:
        if isinstance(payload, list):
            return {
                "status": "ready",
                "request_id": request_id,
                "items": payload,
                "source": "worker",
            }
        if isinstance(payload, dict):
            return {"status": "ready", "request_id": request_id, **payload}

    if isinstance(payload, dict) and "items" in payload:
        return {"status": "ready", "request_id": request_id, **payload}

    return {"status": "ready", "request_id": request_id, "data": payload}


@router.get("/genre/{category_key}")
async def get_genre_tracks(
    category_key: str,
    _user_id: int = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    cached = await db.scalar(
        select(CachedContent).where(CachedContent.source_id == category_key)
    )

    if cached and cached.updated_at:
        last_update = cached.updated_at
        if last_update.tzinfo is None:
            last_update = last_update.replace(tzinfo=timezone.utc)
        now = datetime.now(timezone.utc)
        if (now - last_update) < timedelta(hours=12):
            items = cached.items_data if cached.items_data else []
            return {
                "id": category_key,
                "title": cached.title or category_key,
                "items": items,
                "source": "cache_db",
            }

    request_id = str(uuid.uuid4())
    await _register_metadata_job(
        request_id, {"kind": "genre", "category_key": category_key}
    )
    task = {
        "request_id": request_id,
        "action": "fetch_genre",
        "payload": category_key,
    }
    logger.info("Queued genre fetch: %s request_id=%s", category_key, request_id)
    await redis_client.redis.lpush("metadata_queue", json.dumps(task))

    return JSONResponse(
        status_code=202,
        content={
            "status": "accepted",
            "request_id": request_id,
            "poll_path": f"/api/metadata/result/{request_id}",
            "retry_after": 2,
        },
    )


@router.get("/album/{album_id}")
async def get_album_details(
    album_id: str,
    _user_id: int = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    data = await get_content_with_status(album_id, db)
    if data:
        logger.info("Album cache hit: %s", album_id)
        return data

    request_id = str(uuid.uuid4())
    await _register_metadata_job(request_id, {"kind": "album", "album_id": album_id})
    task = {
        "request_id": request_id,
        "action": "fetch_album",
        "payload": album_id,
    }
    await redis_client.redis.lpush("metadata_queue", json.dumps(task))
    logger.info("Queued album fetch: %s request_id=%s", album_id, request_id)

    return JSONResponse(
        status_code=202,
        content={
            "status": "accepted",
            "request_id": request_id,
            "poll_path": f"/api/metadata/result/{request_id}",
            "retry_after": 2,
        },
    )


@router.get("/artist/{artist_id}")
async def get_artist_details(
    artist_id: str,
    _user_id: int = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    data = await get_content_with_status(artist_id, db)
    if data and data.get("type") == "artist":
        logger.info("Artist cache hit: %s", artist_id)
        return data

    request_id = str(uuid.uuid4())
    await _register_metadata_job(
        request_id, {"kind": "artist", "artist_id": artist_id}
    )
    task = {
        "request_id": request_id,
        "action": "fetch_artist",
        "payload": artist_id,
    }
    await redis_client.redis.lpush("metadata_queue", json.dumps(task))
    logger.info("Queued artist fetch: %s request_id=%s", artist_id, request_id)

    return JSONResponse(
        status_code=202,
        content={
            "status": "accepted",
            "request_id": request_id,
            "poll_path": f"/api/metadata/result/{request_id}",
            "retry_after": 2,
        },
    )


@router.get("/playlist_info/{playlist_id}")
async def get_playlist_details_api(
    playlist_id: str,
    _user_id: int = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    data = await get_content_with_status(playlist_id, db)
    if data:
        return data

    request_id = str(uuid.uuid4())
    await _register_metadata_job(
        request_id, {"kind": "playlist", "playlist_id": playlist_id}
    )
    task = {
        "request_id": request_id,
        "action": "fetch_playlist",
        "payload": playlist_id,
    }
    await redis_client.redis.lpush("metadata_queue", json.dumps(task))
    logger.info(
        "Queued playlist fetch: %s request_id=%s", playlist_id, request_id
    )

    return JSONResponse(
        status_code=202,
        content={
            "status": "accepted",
            "request_id": request_id,
            "poll_path": f"/api/metadata/result/{request_id}",
            "retry_after": 2,
        },
    )
