"""Persistent track lyrics storage

Revision ID: 002_track_lyrics
"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa

revision: str = "002_track_lyrics"
down_revision: Union[str, None] = "001_feature_roadmap"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.create_table(
        "track_lyrics",
        sa.Column("source_id", sa.String(255), primary_key=True),
        sa.Column("title", sa.String(255), nullable=True),
        sa.Column("artist", sa.String(255), nullable=True),
        sa.Column("lyrics", sa.Text(), nullable=False),
        sa.Column("synced", sa.Boolean(), server_default=sa.text("false")),
        sa.Column("source", sa.String(64), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
    )
    op.execute(
        "CREATE INDEX IF NOT EXISTS idx_track_lyrics_title_trgm "
        "ON track_lyrics USING gin (title gin_trgm_ops)"
    )
    op.execute(
        "CREATE INDEX IF NOT EXISTS idx_track_lyrics_artist_trgm "
        "ON track_lyrics USING gin (artist gin_trgm_ops)"
    )


def downgrade() -> None:
    op.drop_table("track_lyrics")
