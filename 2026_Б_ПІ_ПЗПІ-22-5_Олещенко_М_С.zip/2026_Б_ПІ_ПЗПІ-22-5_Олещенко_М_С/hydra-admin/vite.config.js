import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

const apiTarget = process.env.VITE_DEV_PROXY_TARGET || 'http://127.0.0.1:8005'

export default defineConfig({
  plugins: [react()],
  server: {
    host: true,
    port: parseInt(process.env.VITE_PORT || '5174', 10),
    proxy: {
      '/api': {
        target: apiTarget,
        changeOrigin: false,
      },
    },
  },
  preview: {
    host: '0.0.0.0',
    port: parseInt(process.env.VITE_PREVIEW_PORT || '8080', 10),
    allowedHosts: [
      'localhost',
      '.localhost',
      '127.0.0.1',
      'admin.nikkme.online',
      '.admin.nikkme.online',
    ],
    proxy: {
      '/api': {
        target: apiTarget,
        changeOrigin: false,
      },
    },
  },
})
