export const STORAGE_KEY = 'hydra_admin_key'
export const POLL_MS = 4000

function authHeaders(adminKey) {
  const headers = {}
  if (adminKey) headers['X-Admin-Key'] = adminKey
  return headers
}

async function adminFetch(adminKey, path, options = {}) {
  const res = await fetch(path, {
    ...options,
    headers: {
      ...authHeaders(adminKey),
      ...(options.body ? { 'Content-Type': 'application/json' } : {}),
      ...options.headers,
    },
  })
  if (res.status === 401) {
    const err = new Error('unauthorized')
    err.code = 401
    throw err
  }
  if (!res.ok) {
    const t = await res.text()
    throw new Error(t || res.statusText)
  }
  if (res.status === 204) return null
  return res.json()
}

export async function fetchDashboard(adminKey, verbose = false) {
  const q = verbose ? '?verbose=1' : ''
  return adminFetch(adminKey, `/api/admin/dashboard${q}`)
}

export async function fetchSettings(adminKey) {
  return adminFetch(adminKey, '/api/admin/settings')
}

export async function fetchCaches(adminKey) {
  return adminFetch(adminKey, '/api/admin/caches')
}

export async function pruneGhostConsumers(adminKey, dryRun, minIdleMs = 600000) {
  return adminFetch(
    adminKey,
    `/api/admin/redis/prune-ghost-consumers?min_idle_ms=${minIdleMs}&dry_run=${dryRun}`,
    { method: 'POST' },
  )
}

export async function patchGoogleAccount(adminKey, accountId, body) {
  return adminFetch(adminKey, `/api/admin/google-accounts/${accountId}`, {
    method: 'PATCH',
    body: JSON.stringify(body),
  })
}

export async function patchNetworkNode(adminKey, workerId, body) {
  return adminFetch(adminKey, `/api/admin/network-nodes/${workerId}`, {
    method: 'PATCH',
    body: JSON.stringify(body),
  })
}

export async function refreshCharts(adminKey) {
  return adminFetch(adminKey, '/api/admin/jobs/refresh-charts', { method: 'POST' })
}

export async function refreshExplore(adminKey, langs) {
  return adminFetch(adminKey, '/api/admin/jobs/refresh-explore', {
    method: 'POST',
    body: JSON.stringify({ langs }),
  })
}

export async function invalidateExploreCache(adminKey, langs = []) {
  const q = langs.length ? `?${langs.map((l) => `langs=${encodeURIComponent(l)}`).join('&')}` : ''
  return adminFetch(adminKey, `/api/admin/jobs/invalidate-explore-cache${q}`, {
    method: 'POST',
  })
}

export async function clearQueue(adminKey, queue, dryRun) {
  return adminFetch(adminKey, '/api/admin/queues/clear', {
    method: 'POST',
    body: JSON.stringify({ queue, dry_run: dryRun }),
  })
}

export function getAdminKey() {
  return sessionStorage.getItem(STORAGE_KEY) || ''
}
