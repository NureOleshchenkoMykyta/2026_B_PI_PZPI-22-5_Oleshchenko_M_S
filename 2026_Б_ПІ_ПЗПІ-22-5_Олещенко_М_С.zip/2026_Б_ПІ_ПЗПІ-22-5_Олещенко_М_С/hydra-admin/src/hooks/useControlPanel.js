import { useCallback, useEffect, useState } from 'react'
import {
  fetchSettings,
  fetchCaches,
  fetchDashboard,
  patchGoogleAccount,
  patchNetworkNode,
  refreshCharts,
  refreshExplore,
  invalidateExploreCache,
  clearQueue,
  pruneGhostConsumers,
} from '../api/adminApi.js'

export function useControlPanel(adminKey) {
  const [settings, setSettings] = useState(null)
  const [caches, setCaches] = useState(null)
  const [accounts, setAccounts] = useState([])
  const [nodes, setNodes] = useState([])
  const [queues, setQueues] = useState({})
  const [loading, setLoading] = useState(true)
  const [err, setErr] = useState(null)
  const [msg, setMsg] = useState(null)

  const load = useCallback(async () => {
    setErr(null)
    try {
      const [s, c, d] = await Promise.all([
        fetchSettings(adminKey),
        fetchCaches(adminKey),
        fetchDashboard(adminKey, false),
      ])
      setSettings(s)
      setCaches(c)
      setAccounts(d.google_accounts || [])
      setNodes(d.network_nodes || [])
      setQueues(d.queues || {})
    } catch (e) {
      if (e.code !== 401) setErr(e.message || String(e))
    } finally {
      setLoading(false)
    }
  }, [adminKey])

  useEffect(() => {
    load()
  }, [load])

  const runAction = async (label, fn) => {
    setMsg(null)
    try {
      const result = await fn()
      setMsg(`${label}: OK`)
      await load()
      return result
    } catch (e) {
      setMsg(`${label}: ${e.message || String(e)}`)
      throw e
    }
  }

  return {
    settings,
    caches,
    accounts,
    nodes,
    queues,
    loading,
    err,
    msg,
    setMsg,
    reload: load,
    updateAccount: (id, body) =>
      runAction('Акаунт оновлено', () => patchGoogleAccount(adminKey, id, body)),
    updateNode: (workerId, body) =>
      runAction('Вузол оновлено', () => patchNetworkNode(adminKey, workerId, body)),
    triggerCharts: () => runAction('Charts', () => refreshCharts(adminKey)),
    triggerExplore: (langs) => runAction('Explore', () => refreshExplore(adminKey, langs)),
    invalidateExplore: (langs) =>
      runAction('Кеш explore', () => invalidateExploreCache(adminKey, langs)),
    clearListQueue: (queue, dryRun) =>
      runAction(dryRun ? 'Перевірка черги' : 'Очищення черги', () =>
        clearQueue(adminKey, queue, dryRun),
      ),
    pruneGhosts: async (minIdleMs, dryRunFirst = true) => {
      if (dryRunFirst) {
        const preview = await pruneGhostConsumers(adminKey, true, minIdleMs)
        const ok = window.confirm(
          `Знайдено ${preview.matched} consumer(s) (idle ≥ ${preview.min_idle_ms} мс). Видалити?`,
        )
        if (!ok) {
          setMsg(`Скасовано. Знайдено: ${preview.matched}.`)
          return preview
        }
      }
      return runAction('Prune ghosts', () =>
        pruneGhostConsumers(adminKey, false, minIdleMs),
      )
    },
  }
}
