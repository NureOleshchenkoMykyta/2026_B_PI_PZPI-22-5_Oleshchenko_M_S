import { useCallback, useEffect, useState } from 'react'
import {
  fetchDashboard,
  pruneGhostConsumers,
  POLL_MS,
  STORAGE_KEY,
} from '../api/adminApi.js'

export function useDashboard() {
  const [keyInput, setKeyInput] = useState(() => sessionStorage.getItem(STORAGE_KEY) || '')
  const [adminKey, setAdminKey] = useState(() => sessionStorage.getItem(STORAGE_KEY) || '')
  const [needLogin, setNeedLogin] = useState(false)
  const [data, setData] = useState(null)
  const [err, setErr] = useState(null)
  const [loading, setLoading] = useState(true)
  const [verbose, setVerbose] = useState(false)
  const [actionMsg, setActionMsg] = useState(null)

  const load = useCallback(async () => {
    setErr(null)
    try {
      const d = await fetchDashboard(adminKey, verbose)
      setData(d)
      setNeedLogin(false)
    } catch (e) {
      if (e.code === 401) {
        setNeedLogin(true)
        setData(null)
      } else {
        setErr(e.message || String(e))
      }
    } finally {
      setLoading(false)
    }
  }, [adminKey, verbose])

  useEffect(() => {
    load()
  }, [load])

  useEffect(() => {
    if (needLogin) return undefined
    const id = setInterval(load, POLL_MS)
    return () => clearInterval(id)
  }, [load, needLogin])

  const onSaveKey = (e) => {
    e.preventDefault()
    sessionStorage.setItem(STORAGE_KEY, keyInput.trim())
    setAdminKey(keyInput.trim())
    setLoading(true)
    setNeedLogin(false)
  }

  const onLogout = () => {
    sessionStorage.removeItem(STORAGE_KEY)
    setAdminKey('')
    setKeyInput('')
    setNeedLogin(true)
    setData(null)
  }

  const onRefresh = () => {
    setLoading(true)
    load()
  }

  const onToggleVerbose = (checked) => {
    setVerbose(checked)
    setLoading(true)
  }

  const onPruneGhosts = async (minIdleMs = 600000) => {
    setActionMsg(null)
    try {
      const preview = await pruneGhostConsumers(adminKey, true, minIdleMs)
      const ok = window.confirm(
        `Перевірка Redis: знайдено ${preview.matched} consumer(s) без pending з idle ≥ ${preview.min_idle_ms} мс. Видалити їх з групи?`,
      )
      if (!ok) {
        setActionMsg(`Скасовано. Тестовий підрахунок: ${preview.matched}.`)
        return
      }
      const done = await pruneGhostConsumers(adminKey, false, minIdleMs)
      setActionMsg(`Видалено записів: ${done.removed} з ${done.matched}.`)
      load()
    } catch (e) {
      setActionMsg(e.message || String(e))
    }
  }

  return {
    adminKey,
    keyInput,
    setKeyInput,
    needLogin,
    data,
    err,
    loading,
    verbose,
    onToggleVerbose,
    actionMsg,
    setActionMsg,
    onSaveKey,
    onLogout,
    onRefresh,
    onPruneGhosts,
    reload: load,
  }
}
