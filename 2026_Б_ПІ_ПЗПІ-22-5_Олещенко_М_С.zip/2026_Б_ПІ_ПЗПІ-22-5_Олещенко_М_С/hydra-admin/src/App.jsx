import { BrowserRouter, Routes, Route } from 'react-router-dom'
import LoginPanel from './components/auth/LoginPanel.jsx'
import AdminLayout from './components/layout/AdminLayout.jsx'
import DashboardPage from './pages/DashboardPage.jsx'
import ControlPage from './pages/ControlPage.jsx'
import { useDashboard } from './hooks/useDashboard.js'

function AppRoutes() {
  const d = useDashboard()

  if (d.needLogin) {
    return (
      <LoginPanel
        keyInput={d.keyInput}
        setKeyInput={d.setKeyInput}
        onSaveKey={d.onSaveKey}
      />
    )
  }

  const ready = d.data?.health?.ready

  return (
    <Routes>
      <Route
        element={
          <AdminLayout
            ready={ready}
            timestamp={d.data?.ts}
            loading={d.loading}
            onRefresh={d.onRefresh}
            onLogout={d.onLogout}
            actionMsg={d.actionMsg}
            err={d.err}
          />
        }
      >
        <Route
          index
          element={
            <DashboardPage
              data={d.data}
              verbose={d.verbose}
              onToggleVerbose={d.onToggleVerbose}
            />
          }
        />
        <Route path="control" element={<ControlPage adminKey={d.adminKey} />} />
      </Route>
    </Routes>
  )
}

export default function App() {
  return (
    <BrowserRouter>
      <AppRoutes />
    </BrowserRouter>
  )
}
