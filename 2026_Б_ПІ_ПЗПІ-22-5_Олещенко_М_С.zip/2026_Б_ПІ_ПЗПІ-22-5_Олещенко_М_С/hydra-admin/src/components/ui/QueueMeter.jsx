export default function QueueMeter({ name, value, max }) {
  const num = value == null ? null : Number(value)
  const pct = num == null || max <= 0 ? 0 : Math.min(100, (num / max) * 100)
  let fillClass = 'queue-meter__fill'
  if (pct > 75) fillClass += ' queue-meter__fill--bad'
  else if (pct > 40) fillClass += ' queue-meter__fill--warn'

  return (
    <div className="queue-meter">
      <div className="queue-meter__header">
        <span className="queue-meter__name">{name}</span>
        <span className="queue-meter__value">
          {num == null ? '—' : num.toLocaleString('uk-UA')}
        </span>
      </div>
      <div className="queue-meter__bar">
        <div className={fillClass} style={{ width: `${pct}%` }} />
      </div>
    </div>
  )
}
