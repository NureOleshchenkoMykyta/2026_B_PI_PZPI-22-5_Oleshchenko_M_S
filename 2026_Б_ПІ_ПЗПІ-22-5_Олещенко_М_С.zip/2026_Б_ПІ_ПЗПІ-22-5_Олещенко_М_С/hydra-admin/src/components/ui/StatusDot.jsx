export default function StatusDot({ status, label }) {
  const variant =
    status === 'ok' || status === true ? 'ok' : status === 'warn' ? 'warn' : 'bad'
  return (
    <span className={`status-dot status-dot--${variant}`} role="status">
      {label}
    </span>
  )
}
