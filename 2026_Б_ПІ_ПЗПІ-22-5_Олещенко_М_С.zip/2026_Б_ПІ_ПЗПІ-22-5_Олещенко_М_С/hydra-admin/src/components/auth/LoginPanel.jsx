export default function LoginPanel({ keyInput, setKeyInput, onSaveKey }) {
  return (
    <div className="login-page">
      <div className="login-panel">
        <h1>Hydra</h1>
        <p className="subtitle">
          Ключ з <span className="mono">ADMIN_API_KEY</span> у <span className="mono">.env</span>
        </p>
        <form onSubmit={onSaveKey}>
          <label htmlFor="admin-key">X-Admin-Key</label>
          <input
            id="admin-key"
            type="password"
            autoComplete="off"
            placeholder="порожньо, якщо ключ не задано на API"
            value={keyInput}
            onChange={(e) => setKeyInput(e.target.value)}
          />
          <button type="submit" className="btn btn--primary">
            Увійти
          </button>
        </form>
        <p className="hint">
          Якщо <span className="mono">ADMIN_API_KEY</span> не задано на сервері, залиште поле порожнім і
          натисніть «Увійти».
        </p>
      </div>
    </div>
  )
}
