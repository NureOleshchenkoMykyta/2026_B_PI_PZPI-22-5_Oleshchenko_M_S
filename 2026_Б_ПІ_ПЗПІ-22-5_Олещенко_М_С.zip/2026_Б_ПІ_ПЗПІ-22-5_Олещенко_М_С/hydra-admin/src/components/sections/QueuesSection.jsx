import SectionHeader from '../ui/SectionHeader.jsx'
import QueueMeter from '../ui/QueueMeter.jsx'

export default function QueuesSection({ data }) {
  const queues = data?.queues || {}
  const queueEntries = Object.entries(queues)
  const maxQueue = Math.max(1, ...queueEntries.map(([, v]) => Number(v) || 0))

  return (
    <section id="queues" className="section">
      <SectionHeader
        num="02"
        title="Черги Redis"
        description="Глибина спискових черг та geo fallback stream."
      />

      <div className="panel">
        <h3>Списки</h3>
        {queueEntries.length === 0 ? (
          <div className="empty-state">Немає даних про черги</div>
        ) : (
          <div className="queue-list">
            {queueEntries.map(([name, value]) => (
              <QueueMeter key={name} name={name} value={value} max={maxQueue} />
            ))}
          </div>
        )}
      </div>

      {data?.geo_stream != null && (
        <div className="panel">
          <h3>
            Geo fallback{' '}
            <span className="mono muted" style={{ fontWeight: 400, fontSize: '0.875rem' }}>
              hydra:stream:de
            </span>
          </h3>
          {data.geo_stream.error ? (
            <div className="banner banner--error">{data.geo_stream.error}</div>
          ) : (
            <div className="stat-rows">
              <div className="stat-row">
                <span>Повідомлень</span>
                <span className="stat-row__value">{data.geo_stream.messages ?? '—'}</span>
              </div>
              <div className="stat-row">
                <span>Pending</span>
                <span className="stat-row__value">{data.geo_stream.pending ?? '—'}</span>
              </div>
            </div>
          )}
        </div>
      )}
    </section>
  )
}
