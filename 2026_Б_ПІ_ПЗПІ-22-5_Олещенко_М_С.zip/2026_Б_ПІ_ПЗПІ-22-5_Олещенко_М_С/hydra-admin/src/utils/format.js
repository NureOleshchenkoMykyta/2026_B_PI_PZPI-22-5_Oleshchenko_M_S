export function formatIdle(ms) {
  if (ms == null || ms === '') return '—'
  const s = Math.floor(ms / 1000)
  if (s < 60) return `${s} с`
  const m = Math.floor(s / 60)
  if (m < 60) return `${m} хв`
  const h = Math.floor(m / 60)
  if (h < 48) return `${h} год`
  const d = Math.floor(h / 24)
  return `${d} д`
}

export function formatDate(iso, options = {}) {
  if (!iso) return '—'
  return new Date(iso).toLocaleString('uk-UA', options)
}

export function formatNumber(n) {
  if (n == null || n === '') return '—'
  return Number(n).toLocaleString('uk-UA')
}
