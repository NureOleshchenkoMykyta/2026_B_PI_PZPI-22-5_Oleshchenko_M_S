import os
import asyncio
from sqlalchemy import select, update
from common.models import GoogleAccount
from common.config import settings
from common.database import AsyncSessionLocal

worker_id = os.getenv("WORKER_ID", "unknown")

INTERNAL_COOKIE_PATH = f"/app/cookies_worker_{worker_id}.txt"

async def load_worker_google_session(worker_id_arg: int):
    """Повертає (cookie_content, user_agent) з google_accounts для assigned_worker_id."""
    wid = int(worker_id_arg)
    async with AsyncSessionLocal() as session:
        stmt = (
            select(GoogleAccount)
            .where(
                GoogleAccount.assigned_worker_id == wid,
                GoogleAccount.is_active.is_(True),
            )
        )
        result = await session.execute(stmt)
        account = result.scalar_one_or_none()

        if account:
            print(f"✅ [CookieSync] Знайдено персональний акаунт для Worker {wid}: {account.email}")
            return account.cookie_content, account.user_agent
        print(
            f"⚠️ [CookieSync] Немає активного google_accounts з assigned_worker_id={wid} "
            f"(воркер без Google cookies)."
        )
        return None, None


async def load_cookies_from_db(worker_id_arg: int):
    content, _ua = await load_worker_google_session(worker_id_arg)
    return content

async def save_cookies_to_db(worker_id_arg: int):
    """
    Читає локальний файл куків і оновлює запис у базі даних.
    """
    if not os.path.exists(INTERNAL_COOKIE_PATH):
        print(f"⚠️ [CookieSync] Файл {INTERNAL_COOKIE_PATH} не знайдено, нічого зберігати.")
        return

    print(f"HQ [CookieSync] Зберігаємо свіжі куки в БД для Worker {worker_id_arg}...")
    
    try:
        with open(INTERNAL_COOKIE_PATH, "r", encoding="utf-8") as f:
            new_content = f.read()
    except Exception as e:
        print(f"❌ [CookieSync] Помилка читання файлу: {e}")
        return

    async with AsyncSessionLocal() as session:
        stmt = update(GoogleAccount).where(
            GoogleAccount.assigned_worker_id == int(worker_id_arg)
        ).values(cookie_content=new_content)
        
        await session.execute(stmt)
        await session.commit()
        print(f"✅ [CookieSync] База даних оновлена.")