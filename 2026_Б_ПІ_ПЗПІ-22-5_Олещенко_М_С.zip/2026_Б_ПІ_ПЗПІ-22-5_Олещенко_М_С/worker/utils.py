"""Чисті допоміжні функції воркера — імпорт без сайд-ефектів (Redis, yt-dlp loop)."""

from __future__ import annotations

import os
from typing import Any, Optional

import yt_dlp


def yt_watch_url(video_id: str) -> str:
    return f"https://www.youtube.com/watch?v={video_id}"


def env_truthy(name: str, default: bool = False) -> bool:
    v = (os.getenv(name) or "").strip().lower()
    if not v:
        return default
    return v in ("1", "true", "yes", "on")


def ydl_socket_timeout() -> int:
    try:
        return max(30, int(os.getenv("YTDLP_SOCKET_TIMEOUT", "90")))
    except ValueError:
        return 90


def merge_ytdlp_browser_identity(opts: dict[str, Any], user_agent: Optional[str]) -> None:
    ua = (user_agent or "").strip()
    if ua:
        opts["user_agent"] = ua


def find_downloaded_m4a(download_id: str, download_dir: str) -> Optional[str]:
    """Повертає шлях до готового .m4a після yt-dlp (ім'я за video id потоку)."""
    direct = os.path.join(download_dir, f"{download_id}.m4a")
    if os.path.isfile(direct) and os.path.getsize(direct) > 1024:
        return direct
    try:
        for name in os.listdir(download_dir):
            if not name.startswith(f"{download_id}.") or name.endswith(".part"):
                continue
            if not name.endswith(".m4a"):
                continue
            p = os.path.join(download_dir, name)
            if os.path.isfile(p) and os.path.getsize(p) > 1024:
                return p
    except OSError:
        pass
    return None


def ytdlp_extract_info(url: str, ydl_opts: dict[str, Any]) -> Any:
    """Метадані ролика без завантаження; єдина точка для мокання yt-dlp у тестах."""
    with yt_dlp.YoutubeDL(ydl_opts) as ydl:
        return ydl.extract_info(url, download=False)


def safe_remove(path: Optional[str]) -> None:
    if path and os.path.exists(path):
        try:
            os.remove(path)
        except OSError:
            pass
